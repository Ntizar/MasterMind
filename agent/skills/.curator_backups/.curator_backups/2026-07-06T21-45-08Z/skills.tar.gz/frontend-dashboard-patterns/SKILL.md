---
name: frontend-dashboard-patterns
description: "Patrones completos para dashboards frontend vanilla JS: cliente API robusto, orquestación de carga, error boundaries, tabs con navegación, persistencia, fechas, colores, sparklines, Web Workers y debugging. Todo lo que necesitas para construir dashboards resilientes sin bundler."
version: "1.7.0"
author: Hermes Agent
tags: [frontend, dashboard, patterns, vanilla-js, resilience, geodatos, leaflet, choropleth]
related_skills: []
---

# Frontend Dashboard Patterns — Colección Completa

Patrones reutilizables para dashboards frontend vanilla JS sin bundler. Inspirados en ESIOS Dashboard y Ntizar Aurora.

## Tabla de Contenidos

1. [Cliente API Robusto](#1-cliente-api-robusto) — reintentos, circuit breaker, timeouts
2. [Orquestación de Carga](#2-orquestación-de-carga) — Promise.allSettled, anti-doble-carga, cache fallback
3. [Error Boundaries](#3-error-boundaries) — overlay global, errores por sección, retry, fallback en cascada para APIs externas
4. [Tabs con Navegación](#4-tabs-con-navegación) — hash routing, lazy render, lazy data
5. [Persistencia de Estado](#5-persistencia-de-estado) — localStorage, debounce, versionado
6. [Fechas y Formateo](#6-fechas-y-formateo) — locale ES, rangos, countdowns
7. [Colores y Paletas](#7-colores-y-paletas) — gradients, status colors, CSS vars
8. [Sparklines y Mini Charts](#8-sparklines-y-mini-charts) — SVG inline, Canvas, micro-charts
9. [Web Workers](#9-web-workers) — offload CPU, Comlink, chunked processing
10. [Leaflet Map Patterns](#10-leaflet-map-patterns) — GeoJSON, choropleth, markers, popups, tile layers
11. [Leaflet Layers + Pages Deploy + Shapes](references/leaflet-layers-and-deploy.md) — capas activables, Overpass, GBFS, polígonos OSM, GitHub Pages, shapes completos
12. [Debugging Patterns](#12-debugging-patterns) — console, breakpoints, performance, memory
13. [Taxonomy Hierarchical Filters](references/taxonomy-hierarchical-filters.md) — taxonomía estática + checkboxes jerárquicos + matching padre→descendiente