---
name: gtfs-browser-parser
description: "Parser GTFS completo en navegador: descompresión ZIP en memoria con fflate, detección encoding UTF-8→Windows-1252, tolerancia a ficheros malformados, tipografía europea NeTEx, navegación semanal de servicios."
version: 1.0.0
author: Koldo (aprendido de Ntizar/nap-dashboard)
tags: [gtfs, transit, parser, browser, fflate, zip, nap, transport, spain]
---

# Parser GTFS en Navegador — Patrón nap-dashboard

## Qué es
Parser GTFS que funciona 100% en el navegador sin servidor. Descarga ZIP, descomprime en memoria, parsea CSVs, construye objetos TypeScript.

## Repositorio
- GitHub: https://github.com/Ntizar/nap-dashboard
- Demo: https://ntizar.github.io/nap-dashboard/
- Stack: React + TypeScript + Vite + Leaflet + fflate

## Arquitectura del parser

```
ZIP URL (GTFS feed)
  ↓ fflate.unzipSync()
Raw CSV buffers (UTF-8 → Windows-1252 fallback)
  ↓ CSV line parser (try/catch por fila)
TypeScript interfaces (GtfsStop, GtfsRoute, GtfsTrip, etc.)
  ↓
GtfsData object con filtros por día de semana
```

## Archivos GTFS soportados

**Requeridos:**
- `stops.txt` — Paradas/estaciones
- `routes.txt` — Líneas/rutas
- `trips.txt` — Viajes
- `stop_times.txt` — Horarios (cap 100.000 filas)

**Opcionales:**
- `agency.txt`, `feed_info.txt` — Metadatos
- `calendar.txt`, `calendar_dates.txt` — Servicios
- `shapes.txt` — Geometría rutas
- `frequencies.txt` — Frecuencias
- `transfers.txt`, `pathways.txt`, `levels.txt` — Transferencias
- `fare_attributes.txt`, `fare_rules.txt` — Tarifas
- `attributions.txt` — Atribuciones

## Patrones clave

### Descompresión en memoria
```typescript
import { unzipSync } from 'fflate'
const { [filename]: buffer } = unzipSync(zipData)
```
Sin escribir nada en disco. Todo en RAM.

### Detección de encoding
```typescript
// UTF-8 → fallback Windows-1252 si hay caracteres corruptos (\uFFFD)
const text = new TextDecoder('utf-8', { fatal: false }).decode(buffer)
if (text.includes('\uFFFD')) {
    const text = new TextDecoder('windows-1252').decode(buffer)
}
```

### Tolerancia a ficheros malformados
```typescript
// Cada fila parseada en try/catch
// Filas con errores se cuentan y notifica en pestaña Info
// No rompe el resto del parse
```

### Navegación semanal GTFS
```
calendar.txt → service_id → days_of_week (mon-sun)
calendar_dates.txt → service_id → exception_type (1=added, 2=removed)
  ↓
Filtrar trips por service_id del día seleccionado
  ↓
Filtrar stop_times por trip_id
  ↓
Mostrar solo viajes que circulan ese día
```

### Cap de stop_times
Limitado a 100.000 registros para evitar OOM en feeds grandes.

### Tipos de ruta europeos extendidos (NeTEx 100-1700)
Tren alta velocidad, cercanías, metro, tranvía, funicular, teleférico, ferry, etc.

## Interfaces TypeScript principales

```typescript
interface GtfsStop { stop_id, stop_name, stop_lat, stop_lon, ... }
interface GtfsRoute { route_id, route_short_name, route_type, ... }
interface GtfsTrip { trip_id, route_id, service_id, shape_id, ... }
interface GtfsStopTime { trip_id, stop_id, arrival_time, departure_time, ... }
interface GtfsCalendar { service_id, monday..sunday, start_date, end_date }
interface GtfsCalendarDate { service_id, date, exception_type }
interface GtfsData { agencies, stops, routes, trips, stopTimes, shapes, calendar, ... }
```

## Pitfalls
- **stop_times cap**: 100.000 filas máximo, feeds grandes se truncan
- **Encoding**: feeds españoles a veces usan Windows-1252, no UTF-8
- **Service ID matching**: calendar.txt + calendar_dates.txt deben combinarse para saber qué servicios operan cada día
- **Memory**: todo en RAM, feeds grandes (>50MB ZIP) pueden ser problemáticos en móvil
- **No hay backend**: proxy solo para NAP API key, no para GTFS files

## GTFS Viz — DuckDB WASM (100% client-side)

**Referencia:** gabrielAHN/gtfs-viz (49⭐) — https://github.com/gabrielAHN/gtfs-viz

Alternativa al parser propio: usa DuckDB WASM para query SQL directamente sobre GTFS en el navegador.

### Arquitectura
```
packages/
  duckdb-extension/  ← Extensión DuckDB (C++ nativo + API TS + SQL)
  web/               ← React + Deck.gl + DuckDB WASM
  cli/               ← CLI npm: @gabrielahn/gtfs-viz-cli
```

### CLI
```bash
npm install -g @gabrielahn/gtfs-viz-cli
gtfs-viz import /path/to/feed.zip
gtfs-viz stations --name "Park"
gtfs-viz station "Park Street"
```

### Macros SQL útiles
| Macro | Descripción |
|-------|-------------|
| `get_station_info(id)` | Detalles de estación con conteo pathways/exits |
| `get_station_stops(id)` | Todas las paradas de una estación |
| `get_station_pathways(id)` | Pathways de una estación |
| `get_station_connections(id)` | Conexiones dirigidas con tiempos |
| `get_station_routes(id)` | Rutas más cortas entre partes |

### Cuándo usar cada enfoque
| Criterio | gtfs-browser-parser (propio) | gtfs-viz (DuckDB WASM) |
|----------|------------------------------|------------------------|
| Necesitas editar GTFS | ✅ Sí | ✅ Sí (pathways, stations) |
| Query SQL complejo | ❌ TypeScript filters | ✅ SQL nativo |
| Sin dependencias externas | ✅ fflate + CSV parser | ❌ DuckDB WASM binario |
| Pathfinding entre estaciones | ❌ No | ✅ Sí (traversal times) |
| Exportar GTFS editado | ✅ CSV | ✅ CSV |
| Offline sin internet | ✅ Sí | ❌ Necesita WASM download |

### Pitfalls DuckDB WASM
- Limitaciones de memoria en navegadores con feeds grandes
- Extensión DuckDB nativa (C++) es más rápida que WASM para datasets grandes
- Para edición de GTFS, usar el CLI o la web app, no consultas SQL directas

### Alternativas GTFS
- **WRI-Cities/static-GTFS-manager** (159⭐): Editor web de GTFS con Docker
- **BlinkTagInc/gtfs-to-html** (225⭐): Generación de horarios HTML/PDF desde GTFS
- **WRI-Cities/payanam** (17⭐): Herramienta de mapeo de transporte a GTFS
