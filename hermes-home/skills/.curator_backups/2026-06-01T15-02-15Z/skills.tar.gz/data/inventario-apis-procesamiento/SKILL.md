---
name: inventario-apis-procesamiento
version: "1.0.0"
description: Procedimiento para procesar el catálogo de 10.498+ APIs de API-mega-list en un inventario local estructurado con informes individuales.
tags: [data, APIs, inventory, processing]

---

# Inventario de APIs - Procedimiento de Procesamiento

Procedimiento para procesar el catálogo de 10.498+ APIs de [cporter202/API-mega-list](https://github.com/cporter202/API-mega-list) en un inventario local estructurado.

## Fuente de datos
- **Repositorio**: https://github.com/cporter202/API-mega-list
- **Total APIs**: ~10.498 en 18 categorías
- **Actualización**: diaria
- **Formato**: mayoría son Apify Actors

## Estructura del inventario local (`/tmp/inventario-apis/`)

```
/tmp/inventario-apis/
├── estado.json          # Estado global: totales, progreso, lista procesadas
├── README.md            # Tabla de categorías con progreso
├── <categoria>/
│   ├── README.md        # Resumen de la categoría
│   └── <api-name>/
│       ├── README.md    # Informe detallado en castellano
│       └── datos.json   # Datos estructurados de la API
```

## Categorías (18 total)
| Categoría | APIs | Prioridad |
|---|---|---|
| Automatización | 4.825 | Alta (la más grande) |
| Generación de Leads | 3.452 | Alta |
| Redes Sociales | 3.268 | Media |
| Herramientas Dev | 2.652 | Media |
| Ecommerce | 2.440 | Media |
| IA | 1.208 | Alta (relevante para Koldo) |
| Otras | 1.297 | Baja |
| Agentes IA | 697 | Alta (relevante para Koldo) |
| Integraciones | 890 | Baja |
| Empleo | 848 | Baja |
| Inmobiliarias | 851 | Baja |
| Herramientas SEO | 710 | Baja |
| Noticias | 590 | Baja |
| Viajes | 397 | Baja |
| Servidores MCP | 131 | Alta (relevante para Koldo) |
| Negocios | 2 | Baja |

## Flujo de procesamiento

1. **Leer** `estado.json` para saber qué APIs ya están procesadas
2. **Filtrar** APIs no procesadas (no en `api_procesadas` de estado.json)
3. **Procesar** de 2 a 5 APIs por turno:
   - Crear directorio `api-name-slug/`
   - Generar `README.md` con informe en castellano
   - Generar `datos.json` con estructura estandarizada
4. **Actualizar** `estado.json` con nuevas APIs procesadas
5. **Actualizar** `README.md` de la categoría y global
6. **Commit** con mensaje "Procesamiento de APIs — actualización automática"

## Formato de datos.json

```json
{
  "nombre": "Nombre de la API",
  "url": "https://...",
  "descripcion": "Descripción en castellano",
  "categoria": "agentes-ia",
  "tipo": "Apify Actor",
  "requiere_auth": true/false/null,
  "precio": "free/paid/freemium/null",
  "datos": "tipo de datos que devuelve",
  "casos_uso": ["caso1", "caso2"],
  "notas": [],
  "generado": "YYYY-MM-DD"
}
```

## Progreso actual (2026-05-29)
- **117/10.498** APIs procesadas (1,1%)
- **1 de 16** categorías con progreso (Agentes IA: 17,2%)
- Ritmo: ~10 APIs/hora

## Notas importantes
- Las APIs se nombran con slugs en minúsculas separadas por guiones
- Los nombres con caracteres especiales se normalizan (emojis → texto, espacios → guiones)
- Los sufijos `(Rental)` y `(Tental)` se mantienen en el slug
- Cada commit procesa 2-5 APIs nuevas
- El proceso es gradual: se pueden revisar APIs ya procesadas mientras se continúa
