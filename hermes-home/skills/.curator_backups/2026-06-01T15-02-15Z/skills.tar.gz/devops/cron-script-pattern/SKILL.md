---
name: cron-script-pattern
description: "Patrón para crear cron jobs limpios y rápidos usando no_agent=True con scripts Python. Evita sobrecarga de LLM y mensajes de error feos en la entrega de cron."
version: 1.0.0
author: Koldo
tags: [devops, cron, scripts, automation]

---

# Patrón de Script para Cron Jobs

Al crear cron jobs que necesitan obtener datos y enviar mensajes formateados, preferir usar `no_agent=True` con un script Python sobre prompts impulsados por LLM. Esto evita:
- Sobrecarga de tokens LLM y tiempos de respuesta lentos
- Mensajes de error feos filtrándose en la entrega del cron (la principal queja del usuario)
- Condiciones de carrera y confusión de contexto en el bucle del agente

## Cuándo usar

- **Obtención de datos + salida formateada**: llamadas a APIs → mensaje formateado → entrega automática
- **Monitoreo recurrente**: comprobaciones de Bicimad, espacio en disco, salud de APIs, etc.
- **Salida determinista**: el formato del mensaje es fijo, no se necesita razonamiento
- **Importa la velocidad**: ejecución en subsegundo vs llamadas LLM de varios segundos

## Pattern

### 1. Escribe el script en `/hermes-home/scripts/`

**Importante:** Los scripts deben vivir en `/hermes-home/scripts/` (o subdirectorio). El cron job referencia solo el nombre del archivo sin ruta.

El script debe:
- Obtener datos de APIs
- Formatear la salida como texto limpio/rico en emojis
- **Imprimir en stdout** — Hermes entrega stdout automáticamente como mensaje del cron
- Salir con 0 en éxito, no-zero en fallo (envía alerta de error)
- NO intentar enviar mensajes directamente (sin tokens de bot, sin llamadas API directas)

```python
#!/usr/bin/env python3
"""Patrón limpio de script cron."""

import json
import urllib.request
from datetime import datetime, timezone

def fetch_data():
    """Obtener datos de API externa."""
    url = "https://api.example.com/data"
    req = urllib.request.Request(url)
    req.add_header("User-Agent", "CronScript/1.0")
    with urllib.request.urlopen(req, timeout=10) as response:
        return json.loads(response.read().decode())

def format_message(data):
    """Formatear salida limpia para entrega de cron."""
    return f"📊 Estado: {data['status']}\n🕐 {datetime.now(timezone.utc).strftime('%H:%M')} UTC"

if __name__ == "__main__":
    data = fetch_data()
    print(format_message(data))
```

### 2. Crea el cron job con no_agent=True

```
cronjob action=create
  script: bicimad-alert.py
  no_agent: true
  schedule: "45 5 * * *"
  name: "Alerta Matutina BiciMad"
  deliver: origin
  prompt: "Alerta matutina de BiciMad - verifica la estación 298 y envía mensaje formateado."
```

Campos clave:
- **`no_agent: true`** — omite el LLM, ejecuta el script directamente, entrega stdout tal cual
- **`script`** — **SOLO el nombre del archivo** (ej: `bicimad-alert.py`). El scheduler añade `/persist/hermes-home/scripts/` al campo `script`. Si pasas una ruta relativa como `hermes-home/scripts/bicimad-alert.py`, se convierte en `/persist/hermes-home/scripts/hermes-home/scripts/bicimad-alert.py` — una ruta duplicada que falla con "Script not found".
- **`deliver: origin`** — envía la salida de vuelta al chat/hilo actual
- **`prompt`** — obligatorio incluso con no_agent=True (usado como descripción del job)

### 3. Consideraciones de schedule

- Los schedules de cron usan **UTC** (el servidor funciona en UTC)
- Convierte la hora local del usuario a UTC: Madrid = UTC+1 (invierno) / UTC+2 (verano)
- Ejemplo: 7:45 Madrid (CEST) = 5:45 UTC
- Usa sintaxis cron estándar: `minuto hora día mes día_semana`

## Pitfalls

- **`cronjob action='run'` runs immediately without changing schedule** — use `action='run'` with a `job_id` to trigger a one-off execution. It does NOT modify the job's schedule or repeat count. If you need to change when it runs next, use `action='update'` with the `schedule` parameter. Never use `action='update'` just to trigger a run — that's a different intent.
- **Cron schedule `0 2-4 * * *` means "at 02:00 UTC" (runs once)** — the `2-4` is a range in the hour field, but in the GitHub Stars Learning cron it's configured as `0 2-4 * * *` with `repeat: forever`, which means it runs once at 02:00 UTC daily, NOT every hour between 2 and 4. To run at multiple specific hours, use comma-separated: `0 2,4 * * *`.
- **Script path must be bare filename only** — the scheduler prepends `/persist/hermes-home/scripts/` to the `script` field. Passing `hermes-home/scripts/bicimad-alert.py` produces a doubled path and "Script not found" error. Always use just `bicimad-alert.py`. See `references/bicimad-cron-path-pitfall.md` for details.
- **Script must exit 0** on success — non-zero exit triggers an error alert
- **Script stdout IS the message** — keep it clean, no debug output mixed in
- **No bot tokens needed** — the script should NOT send messages directly; Hermes delivers stdout
- **Scripts run in isolated session** — no chat context, no memory, no skills loaded
- **Script runs via Python** — use `.py` extension; `.sh`/`.bash` runs via bash
- **If script fails, user gets error alert** — handle errors gracefully in script (exit 1 with clear message)
- **caldav + iCloud bug**: `cal.events()` and `cal.search()` may return 0 even when events exist. Verify in iOS Calendar app.
- **External API failures are transient**: PBSC (BiciMad), ESIOS, and other external APIs occasionally timeout or return errors for 1-5 minutes. Scripts MUST include retry logic (3 attempts, 2s delay) to avoid false error alerts from momentary outages.

## Ejemplo: Alerta BiciMad

Ver `/hermes-home/scripts/bicimad-alert.py` para un ejemplo completo y funcional:
- Obtiene datos de la API GBFS (`/customer/gbfs/v2/en/station_status`)
- Formatea mensaje rico en emojis con conteo de bicis/estaciones
- Maneja zona horaria de Madrid automáticamente
- Sale con 0 en éxito, 1 en fallo

## Fallos Transitorios de API

Las APIs externas (PBSC, ESIOS, etc.) ocasionalmente timeout por 1-5 minutos. Ver `references/retry-pattern.md` para el patrón estándar de retry (3 intentos, 2s de delay) que todos los scripts de cron que obtienen datos deben usar.

## ¿Por qué no cron impulsado por LLM?

Los cron jobs impulsados por LLM (`no_agent: false`) producen respuestas feas:
- Las salidas crudas de las llamadas a herramientas se filtran en el mensaje
- RuntimeErrors y stack traces aparecen en la entrega
- Lentos (llamada LLM de varios segundos para una simple obtención de datos)
- Formato impredecible

Cron basado en scripts (`no_agent: true`) es:
- **Rápido** — ejecución en subsegundo
- **Limpio** — solo el mensaje formateado aparece
- **Fiable** — sin alucinación de LLM ni confusión de contexto
- **Determinista** — misma entrada → misma salida cada vez
