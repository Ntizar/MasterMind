# BiciMad Cron Path Pitfall — 2026-05-26

## Problem
When creating `no_agent` cron jobs with a relative `script` path like `hermes-home/scripts/bicimad-alert.py`, the scheduler prepends `/persist/hermes-home/scripts/`, producing:

```
persist/hermes-home/scripts/hermes-home/scripts/bicimad-alert.py
```

Error message: `Script not found: /persist/hermes-home/scripts/hermes-home/scripts/bicimad-alert.py`

## Fix
Use ONLY the bare filename in the `script` field:

```
cronjob action=create
  script: bicimad-alert.py        # bare filename only
  no_agent: true
```

NOT:

```
cronjob action=create
  script: hermes-home/scripts/bicimad-alert.py   # doubled path - fails
  no_agent: true
```

## Context
10 BiciMad cron jobs created on 2026-05-26. First job got transient API error, remaining 9 failed with "Script not found" due to doubled path. All fixed by using bare filename.
