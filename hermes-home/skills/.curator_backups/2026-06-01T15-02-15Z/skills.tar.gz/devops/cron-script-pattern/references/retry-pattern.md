# Retry Pattern for External API Calls

External APIs (PBSC/BiciMad, ESIOS, etc.) occasionally timeout or return errors for 1-5 minutes. Cron scripts MUST include retry logic to avoid false error alerts.

## Pattern

```python
import json
import urllib.request
import time

def fetch_with_retry(url, retries=3, delay=2, timeout=10):
    """Fetch URL with retry on failure."""
    req = urllib.request.Request(url)
    req.add_header("User-Agent", "CronScript/1.0")
    
    for attempt in range(retries):
        try:
            with urllib.request.urlopen(req, timeout=timeout) as response:
                return json.loads(response.read().decode())
        except (urllib.error.URLError, urllib.error.HTTPError, json.JSONDecodeError, OSError) as e:
            if attempt < retries - 1:
                time.sleep(delay)  # Wait before retry
            else:
                raise  # Last attempt failed, propagate error
```

## Usage

```python
if __name__ == "__main__":
    try:
        data = fetch_with_retry("https://api.example.com/data")
        print(format_message(data))
    except Exception as e:
        print(f"❌ ERROR: {e}")
        exit(1)
```

## Parameters
- **retries=3**: Number of attempts before failing
- **delay=2**: Seconds to wait between retries
- **timeout=10**: Seconds to wait for each request

## Why this matters
A momentary API failure (1-2 seconds) should NOT crash a daily cron job. 3 retries with 2s delay covers 99% of transient failures without adding noticeable delay.
