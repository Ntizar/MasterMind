#!/bin/bash
# koldo-autoconfig.sh — Auto-configuración del sistema Koldo
# Se ejecuta diariamente a las 09:00 UTC para sincronizar repo ↔ Hermes

set -e

REPO_DIR="/root/workspace/Koldo"
HERMES_SKILLS="/hermes-home/skills/koldo"
HERMES_SOUL="/hermes-home/SOUL.md"

echo "=== Koldo Autoconfig ($(date -u +%Y-%m-%d\ %H:%M UTC)) ==="

# 1. Sincronizar repo
cd "$REPO_DIR"
git pull origin main 2>/dev/null || echo "⚠ Repo ya actualizado o sin conexión"

# 2. Sincronizar skills al directorio de Hermes (solo los nuevos o modificados)
mkdir -p "$HERMES_SKILLS"
for f in "$REPO_DIR/koldo/"*.md; do
    [ -f "$f" ] || continue
    fname=$(basename "$f")
    # cp -n: no sobrescribir archivos que ya existen en Hermes (preserva los Hermes-only)
    cp -n "$f" "$HERMES_SKILLS/$fname"
done
echo "✓ Skills sincronizados"

# 3. Sincronizar SOUL.md (solo si el repo es más grande que el local)
if [ -f "$REPO_DIR/koldo/SOUL.md" ] && [ -f "$HERMES_SOUL" ]; then
    repo_size=$(wc -c < "$REPO_DIR/koldo/SOUL.md")
    local_size=$(wc -c < "$HERMES_SOUL")
    if [ "$repo_size" -gt "$local_size" ]; then
        cp "$REPO_DIR/koldo/SOUL.md" "$HERMES_SOUL"
        echo "✓ SOUL.md sincronizado ($repo_size bytes)"
    elif [ "$local_size" -gt "$repo_size" ] && [ "$local_size" -gt 1000 ]; then
        # El local es más grande y válido → subir al repo
        cp "$HERMES_SOUL" "$REPO_DIR/koldo/SOUL.md"
        echo "✓ SOUL.md subido al repo ($local_size bytes)"
    else
        echo "✓ SOUL.md ya sincronizado"
    fi
fi

# 4. Backup de memoria: copiar notas recientes del repo como snapshot
# La memoria de Hermes es interna (no en disco), pero las notas del repo
# reflejan el conocimiento actual. Este paso verifica que existan.
if [ -d "$REPO_DIR/notes" ]; then
    note_count=$(find "$REPO_DIR/notes" -name "*.md" 2>/dev/null | wc -l)
    echo "ℹ Notas en repo: $note_count"
fi

# 5. Verificar git auth (sin gh, usar token HTTPS)
if ! git remote -v >/dev/null 2>&1; then
    echo "⚠ Repo no clonado, se necesita configurar"
else
    echo "✓ Repo conectado a GitHub"
fi

echo "✓ Koldo autoconfiguración completa"
