---
name: layered-agent-architecture
version: "1.0.0"
description: >
  Patrón de arquitectura de agentes LLM en capas (L0-pure → L7-app) 
  inspirado en vidpipe. Define cómo estructurar sistemas multi-agente 
  con separación clara: tipos puros, infraestructura, clientes LLM, 
  agentes, assets, pipeline y app. Incluye patrón BaseAgent con 
  getTools()/handleToolCall().
license: MIT
tags: [devops, architecture, multi-layer, agents]

---

# Arquitectura de Agentes en Capas

## Cuándo usar

- Diseñas un sistema multi-agente con separación clara de responsabilidades
- Necesitas organizar un proyecto con múltiples tipos de agentes (video, blog, etc.)
- Quieres que cada agente pueda usar un modelo LLM diferente con coste controlado
- El proyecto crece y necesitas escalabilidad en la arquitectura

## Cuándo NO usar

- Tienes un solo agente simple → la arquitectura en 8 capas es overkill
- El proyecto es pequeño (<500 líneas de código de agente) → estructura plana es suficiente
- No necesitas agentes con herramientas personalizadas → un loop simple de LLM basta

## Visión General

Patrón de arquitectura inspirado en [htekdev/vidpipe](https://github.com/htekdev/vidpipe) (166⭐) que organiza un sistema de agentes LLM en 8 capas con separación de responsabilidades clara.

## Estructura de Capas

```
src/
├── L0-pure/          # Tipos, schemas, utilidades sin dependencias
├── L1-infra/         # Logger, paths, filesystem, config, procesos
├── L2-clients/       # Clientes externos (OpenAI, Copilot SDK, APIs)
├── L3-services/      # Servicios de negocio (LLM provider, video ops, cost tracking)
├── L4-agents/        # Agentes LLM (extienden BaseAgent)
├── L5-assets/        # Modelos de activos (VideoAsset, BlogAsset, ShortVideoAsset...)
├── L6-pipeline/      # Orquestación de pipeline (ETL de agentes)
└── L7-app/           # CLI, SDK, file watchers, commands
```

## Patrón BaseAgent

Cada agente extiende `BaseAgent` e implementa:

```typescript
abstract class BaseAgent {
  protected provider: LLMProvider
  protected session: LLMSession | null = null

  constructor(
    protected agentName: string,
    protected systemPrompt: string,
    provider?: LLMProvider,
    model?: string,
  ) {}

  // Herramientas que este agente expone al LLM
  protected getTools(): ToolWithHandler[] { return [] }

  // Servidores MCP que necesita
  protected getMcpServers(): Record<string, MCPServerConfig> | undefined { return undefined }

  // Handler para ask_user
  protected getUserInputHandler(): UserInputHandler | undefined { return undefined }

  // Timeout para sendAndWait (0 = sin timeout)
  protected getTimeoutMs(): number { return 0 }

  // Dispatch de tool calls
  protected abstract handleToolCall(toolName: string, args: any): Promise<any>

  // Ejecutar el agente
  async run(userMessage: string): Promise<string> {
    // Crea session lazymente, envía mensaje, espera respuesta
  }
}
```

## Flujo de Mensajes

1. `run(userMessage)` crea `LLMSession` lazymente vía provider configurado
2. Mensaje enviado con `sendAndWait()` — bloquea hasta respuesta final
3. LLM invoca herramientas → dispatch a `handleToolCall()`
4. Resultado devuelto al caller
5. Sessions son reutilizables (múltiples `run()` mantienen contexto)

## Patrones Clave

### Tool Registration
- Tools declarados como JSON Schema
- Handlers implementados en el agente concreto
- Logging de eventos de sesión

### Model Per-Agent
- Cada agente puede usar un modelo diferente
- Configuración centralizada en `modelConfig.js`
- Cost tracking por agente

### Asset Pipeline
- Cada agente produce `Asset` objects
- Assets tienen tipos: `VideoAsset`, `BlogAsset`, `ShortVideoAsset`, etc.
- Pipeline conecta agentes vía assets

## Referencias
- [htekdev/vidpipe](https://github.com/htekdev/vidpipe) — Implementación completa
- `src/L4-agents/BaseAgent.ts` — Patrón base
- `src/L5-assets/` — Modelo de activos
- `src/L0-pure/` — Tipos puros
