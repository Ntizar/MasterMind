---
name: nan-deploy
description: "Diagnosticar y corregir problemas de apps desplegadas en NaN.builders — errores 502, cache obsoleta, variables de entorno, triggers de redeploy."
version: 1.0.0
author: Ntizar
tags: [devops, nan, deploy, NaN.builders]
---

# NaN Deployment Troubleshooting

Patterns for diagnosing and fixing issues with apps deployed on NaN.builders.

## Cuándo usar

- Tu app en NaN.builders devuelve 502 Bad Gateway inesperadamente
- Los cambios no se reflejan en el deploy después de hacer push
- El contenedor se reinicia silenciosamente (OOM) o crasha al inicio
- Necesitas diagnosticar problemas de cache, env vars o rendimiento en NaN

## Cuándo NO usar

- Tu app está en otro proveedor (Vercel, Railway, Render) → usa la docs de esa plataforma
- El problema es de código lógico (bugs funcionales) → NaN solo diagnostica infraestructura
- La app no se ha desplegado aún → sigue la guía de deploy estándar primero

## TDZ — 502 Bad Gateway (#1 causa)

**TDZ (Temporal Dead Zone)** causa ~80% de los 502 en NaN. Una `const`/`let` usada antes de su declaración → crash silencioso → Cloudflare 502.

**Patrones TDZ:**
1. Arrow function llamada antes de declaración: `const x = myFunc(); const myFunc = () => {}`
2. Variable usada en objeto literal antes de declaración: `const obj = { a: b.ratio }; const b = computeB();`
3. TDZ anidado: `const a = fn(b);` donde `fn` también es `const` declarada después

**Diagnóstico:** Logs del container NaN → busca `ReferenceError: Cannot access`. Si no hay logs, añade `process.on('uncaughtException')`.

**Prevention:** Ordenar todas las `const` al inicio de la función.

## Vite build falla silenciosamente (parse5)

Si el HTML tiene `<` seguido de espacio y dígito (ej: `< 5%`), parse5 interpreta como tag HTML inválido y el build falla sin error visible en GitHub Actions.

**Solución:** Escapar `<` como `&lt;`. Buscar: `grep -n '< [0-9]' index.html`.

## NaN cachea contenedor Docker

Después de cambios JS/CSS, NaN puede servir versión antigua durante **horas** incluso tras commits trigger.

**Síntomas:** Página 200 pero en blanco total. `verify-nan-deploy.sh` muestra archivos `❌ DESACTUALIZADOS`.

**Soluciones (orden de efectividad):**
1. Cambiar el Dockerfile (añadir comentario) → fuerza rebuild
2. Renombrar repo temporalmente en GitHub
3. Eliminar y recrear el espacio en nan.builders
4. GitHub Pages como fallback

## Scripts y verificación

- `scripts/verify-nan-deploy.sh <base-url> [project-dir]` — Compara hashes MD5 locales vs remotos
- `git commit --allow-empty -m "chore: trigger redeploy" && git push` — Trigger de redeploy

## Debugging checklist

1. `curl https://app.nan.builders/readyz` — ¿credenciales configuradas?
2. `curl https://app.nan.builders/api/endpoint` — ¿API responde?
3. Test local con env vars → si funciona pero remoto no → cache/env/code no deployado
4. Si ambos fallan → bug de código, check TDZ, deps faltantes, syntax

## Server crash silencioso

Container "Running" (uptime crece) pero endpoints devuelven 502 con ~3-4s.

**Fix:** Añadir `process.on('uncaughtException')` y fallback en route handlers:
```javascript
try { data = await buildSummary(fecha, token); }
catch (e) { data = { fecha, error: 'Error temporal' }; }
```

## Infinite recursion → OOM

Función async que se llama recursivamente sin base case → OOM en 4GB RAM hard limit.

**Fix:** Reemplazar recursión con fetch único. Ej: `fetchIndicator(1001, ayer, token)` en vez de `buildSummary(ayer)` dentro de `buildSummary(hoy)`.

## Infraestructura NaN

- Kubernetes cluster, pods Docker aislados, Xeon Gold, 4GB RAM, 20GB disk
- Sin swap, sin `dig`/`nslookup`/`gh`, DNS externo no resuelve desde dentro

## Referencias

- `references/nan-infrastructure.md` — Arquitectura K8s, hardware, networking
- `references/esios-dashboard-pitfalls.md` — Fallos específicos ESIOS Dashboard
- `references/silent-crash-debugging.md` — Crashes silenciosos 502
- `references/static-app-blank-screen.md` — Apps nginx pantalla en blanco
- `references/vite-parse5-html-failure.md` — Vite build parse5 failure
