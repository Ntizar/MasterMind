# ESIOS Dashboard — Debugging & Pitfalls

## Critical Bug: Infinite Recursion in buildSummary

**Symptom**: NaN container killed silently, "no available server"
**Root cause**: `buildSummary(hoy)` called `buildSummary(ayer)` inside its own function body. Each call fetches 31 indicators in 4 batches. The recursive chain never terminated — caused OOM on NaN (4GB RAM, no swap).

**Fix**: Replace recursive call with single `fetchIndicatorSafe(1001, ayer, token)` — only fetches PVPC price for trend calc.

**File**: `src/domains/energy/summary.service.js`

## Critical Bug: TDZ (Temporal Dead Zone) — #1 Cause of NaN 502

**Symptom**: Container "Running" but `/api/esios/summary` returns 502 with ~3-4s response time. Frontend stuck on loading spinner.

**Root cause**: `const` variables accessed before declaration. Arrow functions (`const fn = () => {}`) have NO hoisting.

**Double TDZ pattern** (commit 92eaed4):
```javascript
// BAD: perfEolica calls calcPerformanceRatio before it's defined
const perfEolica = calcPerformanceRatio(eolica, previsionEolica); // TDZ!
const obj = { perf: perfEolica.ratio }; // TDZ!

const calcPerformanceRatio = (a, b) => { ... }; // Declared later
const perfEolica = calcPerformanceRatio(eolica, previsionEolica); // Declared later
```

**Fix**: Declare ALL `const` before ANY usage:
```javascript
// GOOD: calcPerformanceRatio defined FIRST
const calcPerformanceRatio = (a, b) => { ... };
const perfEolica = calcPerformanceRatio(eolica, previsionEolica);
const obj = { perf: perfEolica.ratio };
```

**Prevention**: 
- Order all `const` declarations at the top of the function, before any usage
- Arrow functions (`const fn = () => {}`) are NOT hoisted — must be declared before first call
- When code "worked before and now doesn't", check `git log` for the commit that introduced the TDZ

## Env Var Graceful Degradation

**Pattern**: `env.js` should NEVER `process.exit(1)`. Warn + continue with empty string fallback.

## ESIOS API Quirks

- `time_trunc=hour` makes API SUM values (not average) — divide by 12 for hourly average
- IDs 1-462 and 10035-10049 need `/1000` conversion
- Token in NaN dashboard env vars (not in .env committed to repo)
- Rate limit ~1 req/sec — use batching
- 5-min values: 288 slots/day. Hourly: 24 slots/day with SUM aggregation
