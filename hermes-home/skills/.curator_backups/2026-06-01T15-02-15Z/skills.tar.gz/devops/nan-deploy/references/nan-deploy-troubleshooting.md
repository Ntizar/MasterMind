# NaN Deployment Troubleshooting — Detailed Reference

## Cache-busting for Express

When NaN serves stale HTML, add these headers before `express.static`:

```javascript
app.use((req, res, next) => {
  if (req.path.endsWith('.html') || req.path === '/') {
    res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
  }
  next();
});
app.use(express.static(path.join(__dirname, 'public')));
```

## TDZ (Temporal Dead Zone) errors in large async functions

When a `const` variable is used before its declaration in the same scope block:
- Node.js throws `Cannot access 'X' before initialization`
- In Express, this crashes the process → 502 Bad Gateway in <1s
- **Symptom**: Individual endpoints work, but combined endpoints (like `/summary`) crash
- **Fix**: Ensure all `const` declarations come before any usage. Move dependent calculations before consumers.

Example from esios-dashboard:
```javascript
// WRONG: co2TotalEstimado uses totalGenReal before it's declared
const co2TotalEstimado = (totalGenReal && co2SpecMedia) ? ...; // CRASH
const totalGenReal = (genRenTotal || 0) + (genNoRenTotal || 0);

// CORRECT: declare first, use after
const totalGenReal = (genRenTotal || 0) + (genNoRenTotal || 0);
const co2TotalEstimado = (totalGenReal && co2SpecMedia) ? ...;
```

## Promise.all vs individual try/catch for parallel API calls

When making 30+ parallel API calls, a single failure kills everything:

```javascript
// FRAGILE: one failure kills all
const results = await Promise.all([
  fetchIndicator(1001, date),
  fetchIndicator(1002, date),
  // ... 30 more
]);

// ROBUST: each call isolated
const fetchAll = async (fn, idx) => {
  try { return { ok: true, data: await fn() }; }
  catch (err) { console.error(`Fetch ${idx} failed:`, err.message); return { ok: false, data: [] }; }
};
const resultados = await Promise.all([
  fetchAll(() => fetchIndicator(1001, date), 0),
  fetchAll(() => fetchIndicator(1002, date), 1),
  // ...
]);
const data1 = resultados[0]?.data || [];
const data2 = resultados[1]?.data || [];
```

## NaN-specific notes

- **Build time**: Kaniko builds can take 2-5 minutes
- **Startup**: Node.js needs ~10s to initialize after build
- **Port**: Must match `ENV PORT` in Dockerfile (typically 4000)
- **Logs**: Check NaN dashboard for build/run logs
- **Env vars**: Set in NaN platform UI, not in .env files
- **Auto-deploy**: Triggers on push to `main` branch only
