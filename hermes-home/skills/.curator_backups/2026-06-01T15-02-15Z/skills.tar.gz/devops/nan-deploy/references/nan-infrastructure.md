# NaN.builders — Infraestructura Interna

## Arquitectura

NaN es una plataforma de despliegue de **microVMs/KVM** sobre **Kubernetes**.
Cada "espacio" (space) es un pod K8s con su propio contenedor Docker.

```
┌──────────────────────────────────────┐
│         NaN.builders (Cloud)          │
│                                       │
│  Kubernetes Cluster                   │
│  ┌────────┐ ┌────────┐ ┌────────┐   │
│  │ Pod 1  │ │ Pod 2  │ │ Pod N  │   │
│  │ Docker │ │ Docker │ │ Docker │   │
│  └────────┘ └────────┘ └────────┘   │
│                                       │
│  Kaniko (build sin daemon)            │
│  Cloudflare (CDN + DNS)               │
└──────────────────────────────────────┘
```

## Hardware típico por contenedor (2026-05)

| Recurso | Valor |
|---|---|
| **CPU** | Intel Xeon Gold 5412U (Emerald Rapids) |
| **vCPUs** | 2 |
| **RAM** | 4 GB (sin swap) |
| **Disco raíz** | 20 GB (overlay) |
| **Persistencia** | ~880 GB (`hermes-persist`, ext4, rw,noatime) |
| **OS** | Debian 13 (Trixie) |
| **Kernel** | 6.12.x |

## Networking interno

- **Cluster CIDR**: `10.245.0.0/16`
- **DNS interno**: `10.245.0.10` (CoreDNS K8s)
- **Search domain**: `member-ntizar.svc.cluster.local`
- **K8s API**: `10.245.0.1:443` (HTTPS)
- **DNS externo**: `app.nan.builders` resuelve desde fuera, NO desde dentro del cluster

## Flujo de deploy

1. **Push a `main`** → NaN detecta el cambio
2. **Kaniko build** → construye imagen Docker (2-5 min, sin daemon Docker)
3. **Auto-deploy** → nuevo pod con la imagen
4. **DNS automático** → `https://<nombre>.apps.nan.builders`

## Diagnóstico desde dentro del contenedor

```bash
# Ver infraestructura
cat /etc/os-release && uname -a && nproc && free -h && df -h / && uptime

# Ver software instalado
node --version && python3 --version && docker --version && git --version

# Ver networking
hostname && ip addr show eth0 2>/dev/null && cat /etc/resolv.conf

# Ver servicios K8s expuestos
env | grep -i 'KUBERNETES\|NTIZAR\|PORT' | sort

# Ver almacenamiento
lsblk && mount | grep -E 'vdb|sda|persist'

# Health checks externos
curl -s https://<app>.apps.nan.builders/healthz
curl -s https://<app>.apps.nan.builders/readyz
```

## Limitaciones conocidas

- DNS externo (`app.nan.builders`, `nan.builders`) NO resuelve desde dentro del cluster
- No se puede listar otros pods/servicios sin RBAC de K8s
- No hay `dig` ni `nslookup` por defecto
- No hay `gh` CLI instalado (git auth via token HTTPS)
- No hay swap configurado (OOM si se llena RAM)

## Referencias útiles

- `nan-deploy-troubleshooting.md` — Troubleshooting de deploys (502, cache, TDZ)
- `SKILL.md` — Procedimiento completo de deploy
