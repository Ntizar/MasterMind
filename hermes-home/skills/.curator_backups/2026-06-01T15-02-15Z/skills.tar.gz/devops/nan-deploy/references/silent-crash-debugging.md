# Debugging: Server crash silencioso en NaN

## Session: 2026-05-31

### Problema
Dashboard ESIOS se queda atascado en "Cargando datos energéticos..." en móvil. El endpoint `/api/esios/summary` devuelve 502.

### Diagnóstico paso a paso

1. **Verificar si el container se reinicia**: `curl /healthz` → uptime crece ~30s/check → el container NO se reinicia → crash silencioso del proceso, no OOM
2. **Probar endpoints individuales**: `/api/esios/indicators` (200), `/api/esios/test-token` (200), `/api/esios/weather` (200) → todos funcionan
3. **Probar `/api/esios/summary`**: 502 con ~3-4s → el `buildSummary` crasha durante la ejecución
4. **Probar API ESIOS directamente**: funciona (token válido, respuestas correctas)
5. **Probar buildSummary localmente**: Node.js de esta máquina tiene bug con undici → no se puede probar local
6. **Verificar disk cache**: Eliminado completamente (3 writes + 1 read eliminados de esios.client.js)
7. **Reducir CONCURRENCY**: De 4 → 2 → 1 en buildSummary
8. **Añadir error handlers**: `process.on('uncaughtException')`, `unhandledRejection`, `warning` en server.js
9. **Añadir fallback en route**: Si buildSummary crasha, devolver `{ fecha, series: {}, hourly: {}, error: "..." }`
10. **Verificar frontend**: Modificar data.js para que verifique campo `error` en respuesta y muestre toast

### Causa raíz encontrada

**TDZ doble** en `buildSummary` (summary.service.js):

1. `perfEolica` se usaba en línea 303 pero se declaraba en línea 342
2. `calcPerformanceRatio` (const arrow function) se llamaba en línea 245 pero se declaraba en línea 330

**Fix definitivo:** Mover `calcPerformanceRatio` ANTES de `perfEolica`. Arrow functions `const` NO tienen hoisting.

### Lecciones
- El 502 de Cloudflare NO siempre significa OOM. Puede ser un crash silencioso con container "Running"
- El uptime de /healthz es la clave: si crece, el container no se reinicia → crash silencioso
- Añadir fallbacks en todos los endpoints que llaman a servicios externos
- Siempre añadir `process.on('uncaughtException')` en producción para loguear crashes
- **TDZ es la causa #1 de 502 en NaN**: verificar que TODAS las `const` se declaran antes de ser usadas
- Arrow functions (`const fn = () => {}`) NO tienen hoisting — deben declararse antes del primer uso
- Cuando el código "funcionaba antes y ahora no", revisar git log para encontrar el commit que introdujo el TDZ
