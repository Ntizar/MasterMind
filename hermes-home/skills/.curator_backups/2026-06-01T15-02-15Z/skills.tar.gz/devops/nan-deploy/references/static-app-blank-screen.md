# NaN: Pantalla en blanco con apps estáticas (nginx)

## Patrón: HTML se sirve (200) pero la página está completamente en blanco

A diferencia de los 502 por TDZ en Node.js, las apps estáticas de nginx en NaN pueden servir HTML con 200 y verse en blanco.

### Causas

1. **Puerto de nginx incorrecto** — nginx escucha en un puerto que NaN no mapea al proxy. El contenedor arranca pero el tráfico no llega.
2. **NaN cachea contenedor anterior** — tras un push a GitHub, NaN no reconstruye automáticamente. Sirve archivos JS/CSS antiguos que referencian funciones/objetos que ya no existen → JS crash silencioso → página en blanco.
3. **Elementos HTML duplicados** — IDs duplicados (`loadInput`, `toast`) crean conflictos en el DOM que pueden romper el renderizado.
4. **Service worker cacheando versión vieja** — SW con `CACHE_NAME` antiguo sirve assets cacheados que ya no existen o referencian código roto.

### Diagnóstico

1. **Verificar puerto**: nginx debe escuchar en el puerto configurado en el espacio NaN. Si no se sabe cuál es, escuchar en múltiples puertos (6500 y 8080).
2. **Comparar hashes locales vs remotos**:
   ```bash
   ./scripts/verify-nan-deploy.sh https://PROYECTO-ntizar-ntizar.apps.nan.builders /path/to/proyecto
   ```
3. **Verificar duplicados en HTML**: `grep -c 'id="loadInput"' index.html` debe ser 1.
4. **Verificar consola del navegador** — si hay errores JS, la página se queda en blanco.

### Solución

1. **Trigger redeploy**: `git commit --allow-empty -m "chore: trigger redeploy" && git push`
2. **Si sigue sin reconstruir** (más de 5 min): cambiar Dockerfile:
   ```bash
   echo "# rebuild $(date -u)" >> Dockerfile && git add Dockerfile && git commit -m "chore: force rebuild" && git push
   ```
3. **Si sigue sin reconstruir**: eliminar y recrear el espacio en https://nan.builders
4. **Arreglar duplicados HTML**: eliminar elementos duplicados
5. **Desactivar SW temporalmente**: comentar el registro del service worker para descartar cache
6. **Puerto dual nginx**: escuchar en ambos puertos conocidos:
   ```nginx
   server {
       listen 6500;
       listen 8080;
       ...
   }
   ```

### Casos de estudio

#### FamilyTree (junio 2026)
- **Repo**: github.com/Ntizar/FamilyTree
- **Stack**: nginx:alpine, HTML/CSS/JS vanilla
- **Síntoma**: Pantalla en blanco en `https://7288273982.app.nan.builders`
- **Causas**: Puerto cambiado 3 veces entre 6500 y 8080; elementos `loadInput` y `toast` duplicados; NaN cacheaba contenedor
- **Solución**: nginx dual port + eliminar duplicados + trigger deploy + rebuild manual
- **Estado**: GitHub Pages ✅ funciona

#### Sistema Eléctrico Futuro (junio 2026)
- **Repo**: github.com/Ntizar/SistemaElectricoFuturo
- **Stack**: nginx:alpine, Vue 3 + Plotly, Docker
- **Síntoma**: Pantalla en blanco en `https://sistemaelectricofuturo-ntizar-ntizar.apps.nan.builders/`
- **Causa**: 4 archivos desactualizados en NaN (`nuclear.js`, `simulator.js`, `app.js`, `app.css`). El commit #17 añadió `capacidadNuclearHoraria()` que el JS antiguo no tenía → `ReferenceError` silencioso → Vue no monta.
- **Intentos fallidos**: 4 commits trigger (`--allow-empty` + cambio real), rebuild manual del usuario. Todo ignorado por NaN durante ~20 min.
- **Solución**: Cambiar Dockerfile con timestamp → trigger de rebuild efectivo.
- **Fallback**: GitHub Pages (`ntizar.github.io/SistemaElectricoFuturo/`) siempre funciona.
