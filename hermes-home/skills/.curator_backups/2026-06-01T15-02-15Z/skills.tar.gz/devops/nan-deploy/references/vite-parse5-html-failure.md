# Vite Build Failure: parse5 HTML Parse Error

## Caso de estudio: Sistema Eléctrico Futuro (1 junio 2026)

### Síntomas

- GitHub Pages (`ntizar.github.io/SistemaElectricoFuturo/`) muestra página en blanco
- NaN.builders también sirve versión antigua
- GitHub Actions muestra todos los runs como "completed" (sin fallo visible)
- Los commits se hacen push correctamente a GitHub

### Diagnóstico

1. Verificar archivos remotos vs locales: todos actualizados en GitHub Pages
2. Ejecutar `npx vite build` localmente:
   ```
   error during build:
   [vite:build-html] Unable to parse HTML; parse5 error code invalid-first-character-of-tag-name
   at /path/to/index.html:537:370
   ```
3. Buscar `<` sin escapar en HTML:
   ```bash
   grep -n '< [0-9]' index.html
   # Resultado: 3 ocurrencias de "< 5%" en contenido de texto
   ```

### Causa raíz

Vite usa parse5 para analizar HTML durante el build. El texto `"< 5% del mix"` en contenido HTML hace que parse5 interprete `< 5` como inicio de tag HTML inválido (primer carácter no válido para un tag).

El build falla silenciosamente en GitHub Actions — el job `lint-and-test` puede pasar pero el paso `npm run build` falla, por lo que `pages-build-deployment` nunca se ejecuta.

### Solución

Escapar `<` como `&lt;` en contenido de texto:

```html
<!-- ANTES (roto) -->
<div>El objetivo es llevar la banda al mínimo técnico de respaldo (< 5% del mix).</div>

<!-- DESPUÉS (correcto) -->
<div>El objetivo es llevar la banda al mínimo técnico de respaldo (&lt; 5% del mix).</div>
```

### Prevención

- Al escribir contenido HTML con símbolos de comparación, siempre escapar `<` como `&lt;` y `>` como `&gt;` dentro de contenido de texto
- Nunca dentro de tags HTML (ej: `<div class="x">` está bien)
- Ejecutar `npx vite build` localmente antes de hacer push para detectar estos errores

### Archivos afectados

- `index.html` — 3 ocurrencias de `< 5%` en textos descriptivos de gráficos de mix eléctrico
