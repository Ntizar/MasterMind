---
name: esios-price-forecast
version: "1.0.0"
created: 2026-06-01
description: Herramienta de previsión de precios de luz con análisis estadístico de correlaciones, sensibilidad y escenarios basados en datos históricos ESIOS
---

# ESIOS Price Forecast — Herramienta de previsión de precios

Modelo estadístico para análisis predictivo del precio de la luz basado en datos históricos de ESIOS.

## Arquitectura

### Backend
- **Servicio:** `src/domains/forecast/price-forecast.service.js`
- **Endpoint:** `GET /api/esios/forecast?days=90`
- **Cache:** 6 horas en memoria (cache.get/set)
- **Features extraídas:**
  - Precio (1001): medio, max, min
  - Clima (10388-10390): temperatura, viento, radiación
  - Demanda (1293): media, max, min
  - Renovables (1000, 2038, 2044, 2067): % eólica, solar, hidráulica
  - Mix (2039-2041): nuclear, carbón, CC
  - Compuestas: intensidad solar/eólica, precio/MWh renovable

### Estadística
- **Correlación Pearson** entre cada feature y precio
- **Regresión lineal simple** para coeficientes de impacto
- **Escenarios P10/P50/P90** con ajuste por renovables y TTF
- **Análisis de sensibilidad** clasificando impacto (alto/moderado/bajo/mínimo)

### Frontend
- **HTML:** `#section-prevision` en index.html
- **CSS:** `.forecast-*` en styles.css
- **JS:** `render-forecast.js` con `renderForecastTab()` como entry point
- **Gráfico:** Chart.js con doble eje Y (precio €/MWh vs %/°C)

## Pasos para añadir nueva feature

1. Añadir ID de indicador ESIOS en `buildDayFeatures()` con `fetchIndicator()`
2. Añadir key en `featureKeys` de `calcularCorrelaciones()`
3. Añadir label en `labels` de `renderForecastCorrelations()`
4. Opcional: añadir al gráfico en `renderForecastChart()`

## Pitfalls

- **NaN VM 1vCPU:** El endpoint tarda 30-60s fetching 90 días × 13 indicadores. Cache 6h es obligatorio.
- **No llamar buildSummary() recursivamente** — causa OOM en NaN
- **Limpiar charts anteriores** con `.destroy()` antes de crear nuevos
- **window.charts = {}** para variables globales de charts (NO const/let)
- **`var charts = window.charts = {}`** en data.js — pattern obligatorio

## Datos insuficientes

Si `validos.length < 10`, el endpoint retorna error con `diasDisponibles`. El frontend muestra `showForecastError()`.