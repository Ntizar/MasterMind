---
name: frontend-api-client-errores
description: "Patrón de cliente API robusto con reintentos exponenciales, circuit breaker, timeouts por operación y manejo de errores HTTP. Para dashboards que consumen múltiples endpoints externos."
version: 1.0.0
author: Hermes Agent
tags: [frontend, api-client, error-handling, retry, patterns]
---

# Frontend API Client Robusto

## Descripción

Patrón para crear un cliente HTTP reutilizable que maneja reintentos con backoff exponencial, circuit breaker, timeouts por operación y clasificación de errores HTTP. Diseñado para dashboards que consumen múltiples APIs externas propensas a fallos.

## Cuándo aplicar

- Dashboard que consume múltiples APIs externas (ESIOS, Open-Meteo, etc.)
- APIs con disponibilidad intermitente o timeouts frecuentes
- Cuando un fallo en una API no debería bloquear el resto de la app
- Cuando se necesita visibilidad del estado de salud de cada endpoint

## Cuándo NO aplicar

- App que solo consume un endpoint propio y fiable → fetch nativo basta
- Aplicación con backend que ya maneja retries y circuit breakers internamente
- Cuando el overhead de la librería no justifica la complejidad añadida

---

## 1. Cliente API con reintentos exponenciales

```javascript
class ApiClient {
  constructor(baseURL, options = {}) {
    this.baseURL = baseURL;
    this.defaultTimeout = options.timeout || 10000;
    this.maxRetries = options.maxRetries || 3;
    this.retryDelayMs = options.retryDelayMs || 1000;
    this.circuitBreakerThreshold = options.circuitBreakerThreshold || 5;
    this.circuitBreakerTimeout = options.circuitBreakerTimeout || 60000;

    // Estado del circuit breaker por endpoint
    this.circuits = new Map();
  }

  async request(path, options = {}) {
    const url = this.baseURL + path;
    const timeout = options.timeout || this.defaultTimeout;
    const retries = options.retries ?? this.maxRetries;

    let lastError;
    for (let attempt = 0; attempt <= retries; attempt++) {
      // Verificar circuit breaker
      if (this._isCircuitOpen(path)) {
        throw new Error(`Circuit breaker abierto para ${path}`);
      }

      try {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), timeout);

        const response = await fetch(url, {
          ...options,
          signal: controller.signal,
        });
        clearTimeout(timer);

        // Resetear circuit breaker en éxito
        this._recordSuccess(path);

        if (!response.ok) {
          const error = new Error(`HTTP ${response.status}: ${response.statusText}`);
          error.status = response.status;
          throw error;
        }

        return await response.json();
      } catch (err) {
        lastError = err;

        // No reintentar en errores del cliente (4xx excepto 429)
        if (err.status && err.status >= 400 && err.status < 500 && err.status !== 429) {
          throw err;
        }

        // No reintentar si el request fue abortado
        if (err.name === 'AbortError') {
          throw new Error(`Timeout en ${path}`);
        }

        // Backoff exponencial con jitter
        if (attempt < retries) {
          const delay = this.retryDelayMs * Math.pow(2, attempt) * (0.5 + Math.random());
          await new Promise(r => setTimeout(r, delay));
        }
      }
    }

    this._recordFailure(path);
    throw lastError;
  }
}
```

---

## 2. Circuit Breaker

```javascript
_isCircuitOpen(path) {
  const circuit = this.circuits.get(path);
  if (!circuit) return false;
  if (circuit.failures >= this.circuitBreakerThreshold) {
    const elapsed = Date.now() - circuit.lastFailure;
    if (elapsed < this.circuitBreakerTimeout) return true;
    // Half-open: permitir un intento
    circuit.halfOpen = true;
  }
  return false;
}

_recordSuccess(path) {
  this.circuits.delete(path);
}

_recordFailure(path) {
  const circuit = this.circuits.get(path) || { failures: 0, lastFailure: 0 };
  circuit.failures++;
  circuit.lastFailure = Date.now();
  this.circuits.set(path, circuit);
}
```

**Patrón clave:** Tras N fallos consecutivos, abrir el circuito durante T segundos. Luego permitir un intento de prueba (half-open). Si funciona, cerrar; si falla, reabrir.

---

## 3. Uso del cliente

```javascript
const api = new ApiClient('https://api.esios.ree.es', {
  maxRetries: 3,
  retryDelayMs: 1000,
  circuitBreakerThreshold: 5,
  circuitBreakerTimeout: 60000,
});

// Request con timeout personalizado
const datos = await api.request('/api/estaciones', {
  timeout: 15000,
  headers: { 'Authorization': 'Token token=...' },
});

// Request sin reintentos (error 404 no retry)
const datos = await api.request('/api/estaciones/999', {
  retries: 0,
});
```

---

## 4. Integración con Promise.allSettled

```javascript
async function cargarTodosLosDatos() {
  const tasks = [
    api.request('/api/esios/demanda').then(r => ({ tipo: 'demanda', datos: r })),
    api.request('/api/esios/precios').then(r => ({ tipo: 'precios', datos: r })),
    api.request('/api/open-meteo/clima').then(r => ({ tipo: 'clima', datos: r })),
  ];

  const resultados = await Promise.allSettled(tasks);

  resultados.forEach((r, i) => {
    if (r.status === 'fulfilled') {
      renderizarSeccion(r.value.tipo, r.value.datos);
    } else {
      mostrarErrorSeccion(r.value?.message || 'Error desconocido', i);
    }
  });
}
```

**Patrón:** `Promise.allSettled` permite que un fallo no bloquee el resto. Cada sección se renderiza independientemente.

---

## Puntos clave

1. **Reintentos exponenciales** con jitter para evitar thundering herd
2. **Circuit breaker** por endpoint para no saturar APIs caídas
3. **Timeout por operación** para evitar requests colgados
4. **No reintentar 4xx** (excepto 429 Too Many Requests)
5. **Clasificar errores** por tipo: network, timeout, HTTP status, parsing
6. **Promise.allSettled** para carga paralela con tolerancia a fallos parciales
