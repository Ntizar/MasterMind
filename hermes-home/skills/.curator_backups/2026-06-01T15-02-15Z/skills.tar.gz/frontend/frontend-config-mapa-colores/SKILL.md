---
name: frontend-config-mapa-colores
description: "Patrón de sistema de diseño de colores centralizado con tokens CSS, variables semánticas y modo oscuro. Para dashboards con múltiples componentes visuales que comparten paleta."
version: 1.0.0
author: Hermes Agent
tags: [frontend, design-system, css, colors, theming]
---

# Frontend Config — Mapa de Colores

## Descripción

Patrón para centralizar la paleta de colores de un dashboard en un único archivo de configuración CSS con variables semánticas. Permite modo oscuro, consistencia visual y cambios globales en un solo lugar.

## Cuándo aplicar

- Dashboard con múltiples componentes que comparten colores (gráficos, badges, textos)
- Cuando se necesita modo oscuro o múltiples temas
- Cuando los colores están dispersos en archivos CSS individuales
- Cuando un cambio de color requiere modificar 20+ archivos

## Cuándo NO aplicar

- App con un solo componente y paleta trivial → estilos inline bastan
- Aplicación que usa un framework de UI con sistema de temas integrado (MUI, Ant Design)
- Cuando cada página tiene una paleta completamente independiente

---

## 1. Variables CSS en :root

```css
:root {
  /* --- Colores de fondo --- */
  --color-bg-primary: #0f172a;
  --color-bg-secondary: #1e293b;
  --color-bg-card: #1e293b;
  --color-bg-hover: #334155;

  /* --- Colores de texto --- */
  --color-text-primary: #f1f5f9;
  --color-text-secondary: #94a3b8;
  --color-text-muted: #64748b;

  /* --- Colores semánticos --- */
  --color-success: #22c55e;
  --color-warning: #f59e0b;
  --color-danger: #ef4444;
  --color-info: #3b82f6;

  /* --- Colores de gráfico (paleta fija, no semántica) --- */
  --color-chart-1: #3b82f6;
  --color-chart-2: #8b5cf6;
  --color-chart-3: #06b6d4;
  --color-chart-4: #f59e0b;
  --color-chart-5: #ef4444;
  --color-chart-6: #10b981;
  --color-chart-7: #f97316;
  --color-chart-8: #ec4899;

  /* --- Bordes y sombras --- */
  --color-border: #334155;
  --color-shadow: rgba(0, 0, 0, 0.3);
}
```

**Patrón clave:** Separar colores semánticos (`--color-success`) de colores de gráfico (`--color-chart-1`). Los semánticos cambian con el tema; los de gráfico son fijos para consistencia visual.

---

## 2. Modo oscuro / claro

```css
/* Modo claro (por defecto) */
:root {
  --color-bg-primary: #ffffff;
  --color-bg-secondary: #f8fafc;
  --color-bg-card: #ffffff;
  --color-bg-hover: #f1f5f9;
  --color-text-primary: #0f172a;
  --color-text-secondary: #475569;
  --color-text-muted: #94a3b8;
  --color-border: #e2e8f0;
  --color-shadow: rgba(0, 0, 0, 0.1);
}

/* Modo oscuro */
[data-theme="dark"] {
  --color-bg-primary: #0f172a;
  --color-bg-secondary: #1e293b;
  --color-bg-card: #1e293b;
  --color-bg-hover: #334155;
  --color-text-primary: #f1f5f9;
  --color-text-secondary: #94a3b8;
  --color-text-muted: #64748b;
  --color-border: #334155;
  --color-shadow: rgba(0, 0, 0, 0.3);
}
```

**Patrón:** Usar atributo `[data-theme="dark"]` en `<html>` para cambiar tema. No usar `prefers-color-scheme` directamente si se necesita control manual del usuario.

---

## 3. Uso en componentes

```css
/* Componente genérico */
.card {
  background: var(--color-bg-card);
  border: 1px solid var(--color-border);
  color: var(--color-text-primary);
}

.badge-success {
  background: rgba(34, 197, 94, 0.15);
  color: var(--color-success);
  border: 1px solid rgba(34, 197, 94, 0.3);
}

.badge-warning {
  background: rgba(245, 158, 11, 0.15);
  color: var(--color-warning);
  border: 1px solid rgba(245, 158, 11, 0.3);
}
```

---

## 4. Toggle de tema

```javascript
function toggleTheme() {
  const html = document.documentElement;
  const current = html.getAttribute('data-theme');
  const next = current === 'dark' ? 'light' : 'dark';
  html.setAttribute('data-theme', next);
  localStorage.setItem('theme', next);
}

// Restaurar tema guardado
(function() {
  const saved = localStorage.getItem('theme');
  if (saved) {
    document.documentElement.setAttribute('data-theme', saved);
  } else if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
    document.documentElement.setAttribute('data-theme', 'dark');
  }
})();
```

**Patrón:** Guardar preferencia en localStorage. Respetar `prefers-color-scheme` como valor por defecto.

---

## Puntos clave

1. **Variables semánticas** para colores de UI (fondos, texto, éxito, error)
2. **Variables de gráfico fijas** para mantener consistencia visual entre temas
3. **Atributo `data-theme`** en `<html>` para cambiar tema global
4. **localStorage** para persistir preferencia del usuario
5. **Fallback a `prefers-color-scheme`** como valor por defecto
6. **Un solo archivo** de configuración → cambios globales en un lugar
