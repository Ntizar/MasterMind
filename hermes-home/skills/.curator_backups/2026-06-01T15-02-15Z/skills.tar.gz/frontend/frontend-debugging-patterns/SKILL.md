---
name: frontend-debugging-patterns
description: "Patrones de debugging para aplicaciones frontend con múltiples scripts vanilla JS: scope de variables globales, ciclo de vida de tabs lazy, esquemas de datos, integridad del DOM y orden de carga de scripts."
version: 2.0.0
author: Hermes Agent
tags: [frontend, debugging, vanilla-js, patterns, dashboard]
---

# Frontend Debugging Patterns — Vanilla JS Multi-Script

## Descripción

Guía de patrones de bugs recurrentes en dashboards frontend vanilla JS con múltiples archivos `<script>` cargados secuencialmente. Cada patrón incluye síntoma, causa raíz, solución y cuándo aplicar.

## Cuándo aplicar

- Dashboard HTML con múltiples archivos JS cargados sin bundler
- Errores `ReferenceError` inexplicables entre archivos
- Tabs que no cargan datos o muestran datos incorrectos
- Gráficos que no aparecen sin errores visibles

## Cuándo NO aplicar

- Proyecto con bundler (Vite, Webpack) → usa módulos ES
- Proyecto con framework (React, Vue) → usa sus devtools
- Aplicación SPA con single JS bundle

---

## Patrón 1: Scope de variables entre scripts

**Síntoma:** Un archivo define `const charts = {}` y otro usa `charts.foo` → `ReferenceError: charts is not defined`.

**Causa:** Cada `<script src="...">` crea un scope separado. `const`/`let` son bloque-scoped y NO se exponen en `window`. Solo `var` en scope global se vuelve `window.*`.

**Solución:**

```javascript
// ❌ MALO — otros scripts no lo ven
const charts = {};

// ✅ BUENO — accesible desde todos los scripts siguientes
var charts = window.charts = {};
```

**Cuándo usar:** Cuando múltiples scripts vanilla necesitan compartir estado.

**Cuándo NO usar:** Si puedes migrar a módulos ES (`<script type="module">`), que tienen scope propio y `import`/`export`.

---

## Patrón 2: Tab marcada renderizada antes del fetch lazy

**Síntoma:** Tabs como "Clima" o "Gas" nunca cargan datos. El spinner no aparece pero no hay datos.

**Causa:** `renderTab()` marca `tabRendered.add('clima')` antes del fetch. Luego `cargarDatosTab()` tiene `if (tabRendered.has(tabName)) return;` → retorna sin hacer el fetch.

**Solución:** NO marcar tabs lazy como renderizadas en `renderTab`. Solo marcar cuando el fetch termina:

```javascript
// En renderTab() — NO marcar como renderizado
case 'clima':
case 'gas':
  return; // Dejar que cargarDatosTab() maneje el fetch

// En cargarDatosTab()
if (tabRendered.has(tabName)) return;
tabRendered.add(tabName); // Marcar ANTES del fetch para evitar doble carga

fetch('/api/esios/weather')
  .then(r => r.json())
  .then(data => {
    renderClima(data);
  });
```

**Cuándo usar:** Cuando las tabs cargan datos de forma asíncrona tras el render inicial.

**Cuándo NO usar:** Si los datos ya están en el HTML inicial (SSR), no necesitas lazy-loading.

---

## Patrón 3: Esquema de datos incorrecto en el renderer

**Síntoma:** `renderClima(summary)` se llama pero `summary` no tiene `temperatura`, `viento`, etc. → datos vacíos.

**Causa:** `renderTab('clima', summary)` pasa datos de ESIOS pero `renderClima` espera datos de Open-Meteo. Son esquemas diferentes.

**Solución:** Las tabs con datos externos deben:

1. No recibir datos en `renderTab` (solo `return`)
2. Hacer su propio fetch en `cargarDatosTab`
3. Pasar los datos correctos al renderer

```javascript
// renderTab: tabs externas no reciben datos
case 'clima':
  return; // Fetch lazy

// cargarDatosTab: fetch independiente
case 'clima':
  fetch('/api/open-meteo')
    .then(r => r.json())
    .then(data => {
      renderClima(data); // data tiene el esquema correcto
    });
```

**Cuándo usar:** Cuando diferentes endpoints devuelven esquemas de datos distintos.

**Cuándo NO usar:** Si un endpoint unificado devuelve todos los datos con un esquema coherente.

---

## Patrón 4: Canvas no existe en el DOM

**Síntoma:** `renderDemanda` se llama pero no muestra nada.

**Verificación:**

```bash
curl -s "https://tu-app/" | grep "chartDemanda"
# Debe devolver: <canvas id="chartDemanda"></canvas>
```

**Solución:** Si el canvas no existe, el HTML está roto o el ID no coincide con lo que espera el renderer.

**Cuándo usar:** Cuando un renderer de gráficos no produce salida visual.

**Cuándo NO usar:** Si el canvas existe pero el gráfico se ve vacío → el problema es de datos, no de DOM.

---

## Patrón 5: Nombre de función inconsistente

**Síntoma:** `renderTab('interconexiones')` llama a `renderIntercon()` pero la función se llama `renderInterconMap()`.

**Solución:** Verificar que los nombres coincidan:

```bash
curl -s "https://tu-app/js/render-*.js" | grep "function render"
```

**Cuándo usar:** Cuando un renderer no se ejecuta y no hay errores en consola.

**Cuándo NO usar:** Si usas TypeScript o linting → el compilador detecta estos errores.

---

## Checklist de Debugging

Cuando una tab no carga datos, verificar en orden:

1. **¿Existe la función de render?** Verificar nombre en archivos JS
2. **¿Se llama con los datos correctos?** Comparar esquema esperado vs real
3. **¿El canvas existe en el HTML?** Verificar IDs coincidentes
4. **¿`charts` es accesible globalmente?** `var charts = window.charts = {}`
5. **¿`tabRendered` no bloquea el fetch?** Verificar lógica de lazy-loading
6. **¿El endpoint devuelve datos?** `curl -s "https://tu-app/api/..." | head -100`
7. **¿Hay errores en la consola?** Revisar DevTools Network + Console

---

## Orden de Carga de Scripts

El orden importa porque `var` en un script es global para los siguientes:

```
config.js → state.js → utils.js → api.js → ui.js → data.js → render.js → render-heatmap.js → render-charts.js → render-clima-gas.js → render-zoom.js → render-balance.js → render-intercon-map.js
```

Si un archivo necesita `charts` de `data.js`, debe cargarse DESPUÉS de `data.js`.

**Mejor práctica:** Si el orden se vuelve complejo, migrar a módulos ES con `import`/`export` y un bundler.
