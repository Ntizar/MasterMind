---
name: frontend-error-boundaries
description: "Patrón de error boundaries para dashboards frontend — overlay global, errores por sección, retry automático, timeout en servidor y mensajes diferenciados por tipo de error."
version: 2.0.0
author: Hermes Agent
tags: [frontend, error-handling, dashboard, resilience, patterns]
---

# Frontend Error Boundaries

## Descripción

Patrón de resiliencia para dashboards frontend que consumen múltiples APIs externas. Abarca capa cliente (overlay global, errores por sección, retry) y capa servidor (timeout wrapper, respuesta 504 clara).

## Cuándo aplicar

- Dashboard con múltiples tabs/secciones que cargan datos de forma independiente
- Cualquier aplicación que consuma APIs externas propensas a timeouts o caídas
- Cuando los errores actuales son genéricos ("error desconocido") o crashan la app
- Cuando un fallo en una sección no debería afectar a las demás

## Cuándo NO aplicar

- App de una sola página con un único endpoint → el error global basta
- App donde cada sección es independiente y no necesita retry → no hay valor añadido
- Aplicaciones con backend que ya maneja timeouts y retries internos

---

## 1. HTML: Contenedores de error por sección

Cada sección del dashboard necesita un contenedor para mensajes de error locales:

```html
<div class="tab-section" id="section-mi-seccion">
  <div class="render-error" id="error-mi-seccion"></div>
  <!-- contenido existente -->
</div>
```

**Patrón:** Un contenedor de error por sección, oculto por defecto (`display: none`).

---

## 2. HTML: Overlay global de error

```html
<div id="globalErrorOverlay" class="global-error-overlay">
  <div class="global-error-box">
    <h3>⚠️ Error de conexión</h3>
    <p id="globalErrorText">Mensaje de error...</p>
    <button id="globalErrorRetry">Reintentar</button>
  </div>
</div>
```

**Patrón:** Un solo overlay cubre toda la pantalla cuando el fallo es general.

---

## 3. CSS: Estilos de error

```css
.render-error {
  display: none;
  background: rgba(239,68,68,0.08);
  border: 1px solid rgba(239,68,68,0.2);
  border-radius: 8px;
  padding: 12px 16px;
  margin: 12px 0;
  color: #dc2626;
  font-size: 0.875rem;
}

.global-error-overlay {
  display: none;
  position: fixed;
  top: 0; left: 0; right: 0; bottom: 0;
  background: rgba(15,23,42,0.6);
  backdrop-filter: blur(4px);
  z-index: 10000;
  justify-content: center;
  align-items: center;
}
.global-error-overlay.show { display: flex; }
```

---

## 4. JavaScript: Funciones de gestión

```javascript
function showGlobalError(message) {
  const overlay = document.getElementById('globalErrorOverlay');
  const text = document.getElementById('globalErrorText');
  if (overlay && text) {
    text.textContent = message;
    overlay.classList.add('show');
  }
}

function hideGlobalError() {
  const overlay = document.getElementById('globalErrorOverlay');
  if (overlay) overlay.classList.remove('show');
}

function showTabError(tabName, message) {
  const errorEl = document.getElementById('error-' + tabName);
  if (errorEl) {
    errorEl.innerHTML = `<strong>⚠️ ${message}</strong>`;
    errorEl.style.display = 'block';
    setTimeout(() => { errorEl.style.display = 'none'; }, 8000);
  }
}

function clearTabError(tabName) {
  const errorEl = document.getElementById('error-' + tabName);
  if (errorEl) {
    errorEl.style.display = 'none';
    errorEl.innerHTML = '';
  }
}
```

---

## 5. Integración en carga de datos

```javascript
async function cargarDatos() {
  // Anti-doble-carga
  if (Date.now() - lastLoadTimestamp < 3000) return;
  lastLoadTimestamp = Date.now();

  hideGlobalError();
  showLoading(true);

  try {
    const results = await Promise.allSettled(promises);

    let errors = [];
    results.forEach((r, i) => {
      if (r.status === 'rejected') errors.push(r.reason?.message);
    });

    if (todosOk) {
      renderizar();
    } else if (algunosOk) {
      renderizarParcial();
      errors.forEach(e => showTabError(seccion, e));
    } else {
      const has404 = errors.some(e => e.includes('404'));
      const has5xx = errors.some(e => e.match(/\b5\d\d\b/));
      const hasNetwork = errors.some(e =>
        e.includes('Failed to fetch') || e.includes('NetworkError')
      );

      if (has404) showToast('No hay datos para esta fecha', 'warning');
      else if (has5xx) showGlobalError('Servidor no responde');
      else if (hasNetwork) showGlobalError('Error de conexión');
      else showGlobalError('Error inesperado');
    }
  } catch (err) {
    if (err.name === 'AbortError') return;
    showGlobalError('Error: ' + err.message);
  } finally {
    showLoading(false);
  }
}
```

**Patrón clave:** `Promise.allSettled` permite que un fallo no bloquee el resto. Clasificar errores por tipo → mensajes diferenciados.

---

## 6. Wrapper seguro para renderizado

```javascript
function safeRender(fn, name) {
  return function(...args) {
    try {
      return fn(...args);
    } catch (err) {
      console.error(`[safeRender:${name}] Error:`, err);
      const activeSection = document.querySelector('.tab-section.active');
      if (activeSection) {
        const errorEl = activeSection.querySelector('.render-error');
        if (errorEl) {
          errorEl.innerHTML = `⚠️ <strong>Error en ${name}:</strong> ${err.message}`;
          errorEl.style.display = 'block';
        }
      }
      if (charts[name]) { charts[name].destroy(); charts[name] = null; }
    }
  };
}
```

**Patrón:** Envolver cada función de renderizado para que un error en la visualización no rompa el resto.

---

## 7. Servidor: Timeout wrapper

```javascript
function withTimeout(handler, ms = 30000) {
  return async (req, res) => {
    let timedOut = false;
    const timeout = setTimeout(() => {
      timedOut = true;
      res.status(504).json({ error: 'Tiempo de espera agotado' });
    }, ms);
    try {
      await handler(req, res);
    } finally {
      if (!timedOut) clearTimeout(timeout);
    }
  };
}
```

---

## Puntos clave

1. **Error global** solo cuando NO se puede cargar nada (network, 5xx)
2. **Error por sección** cuando falla un endpoint secundario
3. **No crashar la app** — siempre mostrar mensaje en UI
4. **Auto-hide** de errores inline después de 8 segundos
5. **Anti-doble-carga** — mínimo 3s entre requests
6. **Timeout en servidor** — nunca dejar requests colgados
7. **Clasificar errores** — 404, 502, 503, network, timeout → mensajes distintos
8. **Limpiar errores** al cambiar de tab o al reintentar

## Referencias

- `references/error-boundaries-esios.md` — caso de estudio completo del dashboard ESIOS
