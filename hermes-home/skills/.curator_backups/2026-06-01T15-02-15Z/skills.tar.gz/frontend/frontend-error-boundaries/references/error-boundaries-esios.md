# Caso de estudio: ESIOS Dashboard — Error Boundaries

## Contexto
Dashboard energético que consume API ESIOS/REE. Problemas: API lenta sin timeout, errores genéricos, sin feedback visual, requests colgados.

## Cambios implementados
- **data.js**: showGlobalError, showTabError, clearTabError, anti-doble-carga (3s), clasificación 404/5xx/network
- **ui.js**: tabs limpian errores al cambiar
- **render-charts.js**: safeRender con cleanup de chart
- **index.html**: 9 contenedores .render-error + overlay global
- **styles.css**: .render-error, .global-error-overlay, .skeleton, fadeInUp
- **server.js**: withTimeout() wrapper, 25s para summary, respuesta 504

## Patrón de clasificación
404 → "No hay datos" (toast warning)
5xx → "Servidor no responde" (error global)
Network → "Error de conexión" (error global)
Timeout → "Tiempo agotado" (error global)