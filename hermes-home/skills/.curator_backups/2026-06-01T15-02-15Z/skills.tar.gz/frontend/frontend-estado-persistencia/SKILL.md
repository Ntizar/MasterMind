---
name: frontend-estado-persistencia
description: "Patrón de persistencia de estado en localStorage con serialización, validación, expiración y recuperación ante corrupción. Para dashboards que deben mantener el estado entre recargas."
version: 1.0.0
author: Hermes Agent
tags: [frontend, state-management, persistence, localStorage, patterns]
---

# Frontend Estado — Persistencia

## Descripción

Patrón para persistir el estado de una aplicación frontend en `localStorage` con serialización segura, validación de integridad, expiración automática y recuperación ante datos corruptos.

## Cuándo aplicar

- Dashboard que debe mantener la configuración entre recargas (fecha, filtros, tema)
- Aplicación que pierde datos del formulario si el usuario recarga la página
- Cuando se necesita recuperar el estado tras un crash del navegador
- Cuando el usuario cambia de pestaña y vuelve a la app

## Cuándo NO aplicar

- Datos sensibles (contraseñas, tokens) → usar sessionStorage o cookies seguras
- Datos muy grandes (>5MB) → usar IndexedDB
- Datos en tiempo real que deben ser siempre frescos → no persistir
- App que no necesita mantener estado entre sesiones

---

## 1. Clase PersistStore

```javascript
class PersistStore {
  constructor(key, options = {}) {
    this.key = key;
    this.maxAgeMs = options.maxAgeMs || 24 * 3600 * 1000; // 24h por defecto
    this.maxSizeBytes = options.maxSizeBytes || 4 * 1024 * 1024; // 4MB
    this.defaultState = options.defaultState || {};
  }

  // Leer y validar datos
  load() {
    try {
      const raw = localStorage.getItem(this.key);
      if (!raw) return { ...this.defaultState, _timestamp: Date.now() };

      const parsed = JSON.parse(raw);

      // Validar estructura mínima
      if (!parsed || typeof parsed !== 'object') {
        this.clear();
        return { ...this.defaultState, _timestamp: Date.now() };
      }

      // Validar expiración
      if (parsed._timestamp && (Date.now() - parsed._timestamp > this.maxAgeMs)) {
        this.clear();
        return { ...this.defaultState, _timestamp: Date.now() };
      }

      return parsed;
    } catch (e) {
      // Datos corruptos → limpiar y empezar de cero
      console.warn(`[PersistStore] Datos corruptos en ${this.key}:`, e);
      this.clear();
      return { ...this.defaultState, _timestamp: Date.now() };
    }
  }

  // Guardar con control de tamaño
  save(state) {
    try {
      const payload = { ...state, _timestamp: Date.now() };
      const serialized = JSON.stringify(payload);

      if (serialized.length > this.maxSizeBytes) {
        console.warn(`[PersistStore] Datos demasiado grandes (${serialized.length} bytes). Truncando...`);
        // Truncar arrays si exceden tamaño
        state = this._truncateIfNeeded(state);
      }

      localStorage.setItem(this.key, JSON.stringify({ ...state, _timestamp: Date.now() }));
      return true;
    } catch (e) {
      if (e.name === 'QuotaExceededError') {
        console.error('[PersistStore] localStorage lleno. Eliminando datos antiguos.');
        this.clear();
      }
      return false;
    }
  }

  // Limpiar datos
  clear() {
    try {
      localStorage.removeItem(this.key);
    } catch (e) {
      // Ignorar errores de limpieza
    }
  }

  // Truncar arrays si exceden el tamaño
  _truncateIfNeeded(state) {
    const truncated = { ...state };
    for (const key of Object.keys(truncated)) {
      if (Array.isArray(truncated[key]) && truncated[key].length > 500) {
        truncated[key] = truncated[key].slice(0, 500);
      }
    }
    return truncated;
  }
}
```

---

## 2. Uso: Persistir configuración de dashboard

```javascript
// Instancia única
const configStore = new PersistStore('dashboard_config', {
  maxAgeMs: 7 * 24 * 3600 * 1000, // 7 días
  defaultState: {
    fecha: new Date().toISOString().split('T')[0],
    tema: 'dark',
    tabsVisibles: ['demanda', 'precios'],
  },
});

// Cargar configuración
let config = configStore.load();

// Actualizar y guardar
function actualizarFecha(nuevaFecha) {
  config.fecha = nuevaFecha;
  configStore.save(config);
}

// Restaurar al iniciar
document.addEventListener('DOMContentLoaded', () => {
  config = configStore.load();
  aplicarTema(config.tema);
  seleccionarFecha(config.fecha);
});
```

---

## 3. Persistir datos de simulación

```javascript
const dataStore = new PersistStore('simulacion_data', {
  maxAgeMs: 24 * 3600 * 1000, // 24h
  maxSizeBytes: 3 * 1024 * 1024, // 3MB
  defaultState: {},
});

function guardarSimulacion(params, resultados) {
  // Solo guardar un subconjunto representativo
  const snapshot = {
    params: params,
    resultados: resultados.slice(0, 168), // primeras 168h (1 semana)
  };
  dataStore.save(snapshot);
}

function cargarSimulacion() {
  const snapshot = dataStore.load();
  if (!snapshot || !snapshot.resultados) return null;
  return snapshot;
}
```

**Patrón:** Nunca guardar datos completos. Solo un subconjunto representativo para no exceder el límite de localStorage.

---

## 4. Sincronización con sessionStorage

```javascript
class HybridStore {
  constructor(key, options) {
    this.persistent = new PersistStore(key, options);
    this.session = sessionStorage;
    this.sessionKey = `temp_${key}`;
  }

  // Guardar en sessionStorage (temporal) y localStorage (persistente)
  save(state) {
    // SessionStorage: datos temporales entre pestañas
    this.session.setItem(this.sessionKey, JSON.stringify(state));

    // localStorage: datos persistentes
    this.persistent.save(state);
  }

  // Cargar: primero sessionStorage, fallback a localStorage
  load() {
    const sessionRaw = this.session.getItem(this.sessionKey);
    if (sessionRaw) {
      try {
        return JSON.parse(sessionRaw);
      } catch (e) {
        // Fallback a localStorage
      }
    }
    return this.persistent.load();
  }
}
```

**Patrón:** Usar sessionStorage como capa temporal (entre pestañas) y localStorage como capa persistente (entre sesiones).

---

## Puntos clave

1. **Validar estructura** al leer → datos corruptos se limpian automáticamente
2. **Validar expiración** → datos antiguos no se usan
3. **Control de tamaño** → truncar arrays si exceden el límite
4. **Manejar QuotaExceededError** → limpiar datos y notificar al usuario
5. **Subconjunto representativo** → nunca guardar datos completos
6. **Timestamp de creación** → para validar antigüedad de los datos
