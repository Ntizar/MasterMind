---
name: frontend-fechas-timezone-local
description: "Patrón de manejo de fechas con zonas horarias, conversión UTC→local y formateo consistente. Para dashboards con datos temporales de múltiples fuentes."
version: 1.0.0
author: Hermes Agent
tags: [frontend, dates, timezone, i18n, patterns]
---

# Frontend Fechas — Timezone y Localización

## Descripción

Patrón para manejar fechas de forma consistente en aplicaciones frontend: conversión UTC→local, formateo con zonas horarias, y normalización de inputs de fecha. Evita bugs comunes de desfase horario y horarios de verano.

## Cuándo aplicar

- Dashboard que muestra datos temporales de múltiples APIs (ESIOS, Open-Meteo, etc.)
- Cuando los datos vienen en UTC pero deben mostrarse en hora local
- Cuando hay inputs de fecha que deben normalizarse a medianoche local
- Aplicación multi-zona horaria o con usuarios en diferentes regiones

## Cuándo NO aplicar

- Datos que deben mostrarse siempre en UTC (logs de sistema, auditoría)
- Aplicación interna de una sola zona horaria con datos ya en local
- Cuando se usa un framework que maneja fechas internamente (Day.js, date-fns con plugins)

---

## 1. Normalización de fecha a medianoche local

**Problema común:** `new Date('2024-01-15')` se interpreta como UTC medianoche, que en Madrid es 01:00 CET. El día mostrado es incorrecto.

```javascript
function fechaALocal(fechaStr) {
  // ❌ MALO: '2024-01-15' → UTC 00:00 → en Madrid es 01:00 del 15, pero si es verano son las 00:00
  return new Date(fechaStr);

  // ✅ BUENO: interpretar como fecha local (medianoche hora local)
  const [year, month, day] = fechaStr.split('-').map(Number);
  return new Date(year, month - 1, day);
}

function fechaDesdeLocal(date) {
  // Convertir fecha local a string ISO sin perder la zona
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}
```

**Patrón clave:** Usar constructores de fecha con argumentos separados (`new Date(year, month, day)`) para evitar ambigüedad UTC/local.

---

## 2. Conversión UTC→Local para display

```javascript
function utcALocalDisplay(utcTimestamp, formato) {
  // Timestamp de API en UTC → mostrar en hora local
  const date = new Date(utcTimestamp);

  // Verificar que la fecha es válida
  if (isNaN(date.getTime())) return 'Fecha inválida';

  // Formatear con zona horaria del navegador
  return date.toLocaleString('es-ES', {
    year: 'numeric',
    month: formato === 'fecha' ? 'short' : '2-digit',
    day: '2-digit',
    hour: formato !== 'fecha' ? '2-digit' : undefined,
    minute: formato !== 'fecha' ? '2-digit' : undefined,
    hour12: false,
  });
}

// Ejemplo: '2024-01-15T14:30:00Z' → '15/01/2024, 15:30' (en Madrid)
```

---

## 3. Detección de zona horaria

```javascript
function obtenerZonaHoraria() {
  return Intl.DateTimeFormat().resolvedOptions().timeZone;
}

// Ejemplo: 'Europe/Madrid', 'America/Buenos_Aires', 'America/Mexico_City'
const zona = obtenerZonaHoraria();

// Verificar si el navegador soporta DST
function verificarDST(date) {
  const enero = new Date(date.getFullYear(), 0, 1).getTimezoneOffset();
  const julio = new Date(date.getFullYear(), 6, 1).getTimezoneOffset();
  return enero !== julio; // true si el sistema observa horario de verano
}
```

---

## 4. Generación de rango de fechas

```javascript
function generarRangoFechas(fechaInicio, fechaFin, paso = 'day') {
  const fechas = [];
  const current = new Date(fechaInicio);
  const end = new Date(fechaFin);

  while (current <= end) {
    fechas.push(fechaDesdeLocal(current));
    switch (paso) {
      case 'day':
        current.setDate(current.getDate() + 1);
        break;
      case 'week':
        current.setDate(current.getDate() + 7);
        break;
      case 'month':
        current.setMonth(current.getMonth() + 1);
        break;
    }
  }
  return fechas;
}

// Ejemplo: ['2024-01-01', '2024-01-02', ..., '2024-01-31']
```

---

## 5. Input de fecha con validación

```javascript
function validarFechaInput(valor) {
  // Aceptar formatos: YYYY-MM-DD, DD/MM/YYYY, DD-MM-YYYY
  let parsed;

  if (/^\d{4}-\d{2}-\d{2}$/.test(valor)) {
    parsed = fechaALocal(valor);
  } else if (/^\d{2}[\/-]\d{2}[\/-]\d{4}$/.test(valor)) {
    const [d, m, y] = valor.split(/[\/-]/).map(Number);
    parsed = new Date(y, m - 1, d);
  } else {
    return null;
  }

  if (isNaN(parsed.getTime())) return null;

  // Verificar que no sea una fecha futura
  const hoy = new Date();
  hoy.setHours(0, 0, 0, 0);
  if (parsed > hoy) return null;

  return fechaDesdeLocal(parsed);
}
```

---

## Puntos clave

1. **Nunca usar `new Date('YYYY-MM-DD')`** → se interpreta como UTC, causando desfase
2. **Usar `new Date(year, month, day)`** → interpreta como hora local
3. **`toLocaleString('es-ES')`** → formatea con zona horaria del navegador automáticamente
4. **DST** → JavaScript maneja automáticamente horario de verano/solar
5. **Validar fechas** → siempre verificar `isNaN(date.getTime())` tras parsear
6. **Zona horaria detectable** → usar `Intl.DateTimeFormat().resolvedOptions().timeZone`
