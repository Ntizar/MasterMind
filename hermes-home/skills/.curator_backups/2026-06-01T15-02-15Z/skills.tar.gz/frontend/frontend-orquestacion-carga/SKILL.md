---
name: frontend-orquestacion-carga
description: "Patrón de orquestación de carga paralela con Promise.allSettled, anti-doble-carga, estados de loading por sección y fallback a datos cacheados."
version: 1.0.0
author: Hermes Agent
tags: [frontend, async, data-loading, patterns, dashboard]
---

# Frontend Orquestación de Carga

## Descripción

Patrón para orquestar la carga de datos de múltiples endpoints en paralelo, con gestión de estados de loading por sección, anti-doble-carga y fallback a datos cacheados.

## Cuándo aplicar

- Dashboard con múltiples tabs que cargan datos de diferentes APIs
- Cuando se necesita mostrar datos parciales mientras otras secciones cargan
- Cuando los usuarios hacen clic repetidamente en "cargar" y se generan requests duplicados
- Cuando se necesita mostrar datos cacheados mientras se actualizan

## Cuándo NO aplicar

- App con un solo endpoint → no hay orquestación que gestionar
- Datos que deben cargarse secuencialmente (dependencias entre endpoints)
- Cuando cada sección es completamente independiente y no necesita estado global de carga

---

## 1. Orquestador de carga paralela

```javascript
class DataOrchestrator {
  constructor() {
    this.loadTimestamp = 0;
    this.minIntervalMs = 3000; // Anti-doble-carga
    this.loadingStates = new Map();
    this.cache = new Map();
  }

  // Verificar anti-doble-carga
  puedeCargar() {
    return (Date.now() - this.loadTimestamp) >= this.minIntervalMs;
  }

  // Marcar inicio de carga
  iniciarCarga(seccion) {
    this.loadingStates.set(seccion, true);
    this.notificarCambio(seccion, 'loading');
  }

  // Marcar fin de carga
  finalizarCarga(seccion, exito, datos) {
    this.loadingStates.set(seccion, exito ? 'loaded' : 'error');
    if (exito && datos) {
      this.cache.set(seccion, { datos, timestamp: Date.now() });
    }
    this.notificarCambio(seccion, exito ? 'loaded' : 'error', datos);
  }

  // Cargar múltiples secciones en paralelo
  async cargarTodas(secciones) {
    if (!this.puedeCargar()) return false;
    this.loadTimestamp = Date.now();

    // Iniciar loading de todas las secciones
    secciones.forEach(s => this.iniciarCarga(s));

    // Crear promesas para cada sección
    const promesas = secciones.map(seccion =>
      this._cargarSeccion(seccion)
        .then(datos => ({ seccion, exito: true, datos }))
        .catch(error => ({ seccion, exito: false, error }))
    );

    // Esperar todas (ninguna falla bloquea a las demás)
    const resultados = await Promise.allSettled(promesas);

    // Procesar resultados
    let errores = [];
    resultados.forEach(r => {
      if (r.status === 'fulfilled') {
        this.finalizarCarga(r.value.seccion, r.value.exito, r.value.datos);
      } else {
        errores.push(r.reason);
        this.finalizarCarga(r.reason?.seccion || 'unknown', false);
      }
    });

    return errores.length === 0;
  }

  // Cargar una sección individual (sobrescribible)
  async _cargarSeccion(seccion) {
    throw new Error('Método _cargarSeccion debe ser implementado');
  }

  // Obtener datos cacheados
  obtenerCache(seccion) {
    const entry = this.cache.get(seccion);
    return entry ? entry.datos : null;
  }

  // Estado de loading de una sección
  estaCargando(seccion) {
    return this.loadingStates.get(seccion) === true;
  }

  // Notificar cambios a la UI (callback personalizado)
  notificarCambio(seccion, estado, datos) {
    // Implementar según framework: emit event, update state, etc.
  }
}
```

---

## 2. Implementación concreta

```javascript
class DashboardOrchestrator extends DataOrchestrator {
  constructor(apiClient) {
    super();
    this.api = apiClient;
  }

  async _cargarSeccion(seccion) {
    switch (seccion) {
      case 'demanda':
        return await this.api.request('/api/esios/demanda');
      case 'precios':
        return await this.api.request('/api/esios/precios');
      case 'clima':
        return await this.api.request('/api/open-meteo/clima');
      case 'gas':
        return await this.api.request('/api/esios/gas');
      default:
        throw new Error(`Sección desconocida: ${seccion}`);
    }
  }
}

// Uso
const orchestrator = new DashboardOrchestrator(apiClient);

// Cargar todas las secciones
const ok = await orchestrator.cargarTodas(['demanda', 'precios', 'clima', 'gas']);

// Verificar estado de una sección
if (orchestrator.estaCargando('demanda')) {
  mostrarSpinner('demanda');
}

// Obtener datos cacheados para fallback
const demandaCache = orchestrator.obtenerCache('demanda');
```

---

## 3. Fallback a datos cacheados

```javascript
async function cargarConFallback(seccion) {
  // 1. Mostrar datos cacheados inmediatamente (si existen)
  const cache = orchestrator.obtenerCache(seccion);
  if (cache) {
    renderizarSeccion(seccion, cache, { desdeCache: true });
  }

  // 2. Cargar datos frescos en background
  try {
    const datos = await orchestrator._cargarSeccion(seccion);
    renderizarSeccion(seccion, datos, { desdeCache: false });
  } catch (err) {
    // Si falla, mantener datos cacheados
    if (cache) {
      mostrarNota(`Datos actualizados: ${err.message}`);
    } else {
      mostrarError(seccion, err.message);
    }
  }
}
```

**Patrón clave:** Mostrar datos cacheados inmediatamente + actualizar en background. El usuario ve algo útil mientras se actualiza.

---

## 4. Integración con UI

```javascript
// HTML: contenedores con estados
<div class="tab-section" id="section-demanda">
  <div class="loading-spinner" id="spinner-demanda" style="display:none;">⏳ Cargando...</div>
  <div class="render-error" id="error-demanda"></div>
  <div class="chart-container" id="chart-demanda"></div>
</div>

// JS: actualizar UI según estado
function actualizarUI(seccion, estado, datos) {
  const spinner = document.getElementById(`spinner-${seccion}`);
  const error = document.getElementById(`error-${seccion}`);

  if (estado === 'loading') {
    spinner.style.display = 'block';
    error.style.display = 'none';
  } else if (estado === 'loaded') {
    spinner.style.display = 'none';
    error.style.display = 'none';
    renderizarGrafico(seccion, datos);
  } else if (estado === 'error') {
    spinner.style.display = 'none';
    error.style.display = 'block';
    error.textContent = 'Error al cargar datos';
  }
}
```

---

## Puntos clave

1. **Anti-doble-carga** → mínimo 3s entre cargas completas
2. **Promise.allSettled** → un fallo no bloquea el resto
3. **Estados por sección** → cada tab tiene su propio loading/error
4. **Fallback a cache** → mostrar datos viejos mientras se actualiza
5. **Orquestador reutilizable** → extensible para nuevas secciones
6. **Carga en background** → los datos cacheados se muestran inmediatamente
