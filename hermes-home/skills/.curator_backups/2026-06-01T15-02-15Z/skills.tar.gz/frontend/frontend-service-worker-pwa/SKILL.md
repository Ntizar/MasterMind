---
name: frontend-service-worker-pwa
description: "Patrón para añadir Service Worker y soporte offline (PWA) a SPAs — caché de assets, persistencia de datos en localStorage, indicadores de estado online/offline."
version: 2.0.0
author: Hermes Agent
tags: [frontend, service-worker, PWA, offline, patterns]
---

# Frontend Service Worker & PWA Pattern

## Descripción

Patrón para añadir soporte offline a aplicaciones frontend. Incluye caché de assets, persistencia de datos en localStorage, indicadores de estado online/offline y estrategias de actualización.

## Cuándo aplicar

- Aplicación que debe funcionar sin conexión o con conexión intermitente
- Dashboard que consume datos de APIs externas propensas a caídas
- Aplicación que se usa frecuentemente en entornos con mala conectividad
- Cuando se necesita que la app cargue instantáneamente al volver

## Cuándo NO aplicar

- Aplicación que requiere datos siempre actualizados en tiempo real
- App con datos sensibles que no deben almacenarse localmente
- Aplicación con volumen de datos que exceda el límite de localStorage (~5MB)
- Cuando el overhead de mantenimiento del SW no justifica el beneficio

---

## Estructura de archivos

```
sw.js                    → Service Worker con caché de assets
index.html               → Registro del SW + indicadores de estado
js/app.js                → Funciones guardar/cargar datos + listeners online/offline
css/app.css              → Estilos para badges de estado
```

---

## sw.js — Estrategia de caché

### Install
Cachear todos los assets estáticos:

```javascript
const CACHE_NAME = 'app-v1';
const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/css/app.css',
  '/js/app.js',
  '/js/charts.js',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).addAll(STATIC_ASSETS)
  );
});
```

### Activate
Limpiar cachés antiguas y reclamar clientes:

```javascript
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then(names =>
      Promise.all(
        names.filter(n => n !== CACHE_NAME)
             .map(n => caches.delete(n))
      )
    ).then(() => self.clients.claim())
  );
});
```

### Fetch
Estrategia mixta según tipo de recurso:

```javascript
self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);

  // Assets estáticos: cache-first con actualización en segundo plano
  if (STATIC_ASSETS.includes(url.pathname)) {
    event.respondWith(
      caches.match(event.request).then(cached => {
        const fetchPromise = fetch(event.request)
          .then(response => {
            if (response.ok) {
              const clone = response.clone();
              caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
            }
            return response;
          });
        return cached || fetchPromise;
      })
    );
    return;
  }

  // API y navegación: network-first con fallback a caché
  event.respondWith(
    fetch(event.request)
      .catch(() => caches.match(event.request))
  );
});
```

**Patrón clave:** Assets estáticos → cache-first (carga rápida). APIs → network-first (datos frescos con fallback).

---

## Persistencia de datos

### Guardar datos localmente

```javascript
function guardarDatosLocal() {
  try {
    // Solo guardar un subconjunto representativo
    const snapshot = {
      params: params,
      resultados: resultados.slice(0, 168), // primeras 168h
      timestamp: Date.now()
    };
    localStorage.setItem('app_snapshot', JSON.stringify(snapshot));
    mostrarBadge('💾 Datos guardados localmente');
  } catch (e) {
    console.warn('localStorage lleno:', e);
  }
}
```

**Patrón:** Nunca guardar datos completos. Solo un subconjunto representativo para no exceder ~5MB.

### Cargar datos desde localStorage

```javascript
function cargarDatosLocal() {
  try {
    const raw = localStorage.getItem('app_snapshot');
    if (!raw) return false;
    const snapshot = JSON.parse(raw);
    if (Date.now() - snapshot.timestamp > 24 * 3600 * 1000) return false; // >24h
    // Restaurar params y resultados
    Object.assign(params, snapshot.params);
    Object.assign(resultados, snapshot.resultados);
    return true;
  } catch (e) {
    console.warn('Error cargando datos locales:', e);
    return false;
  }
}
```

**Patrón:** Validar antigüedad antes de restaurar. Datos de hace más de 24h no son útiles.

---

## Indicadores de estado

### Badge de conexión

```javascript
function actualizarEstadoConexion() {
  const badge = document.getElementById('connectionBadge');
  if (badge) {
    const online = navigator.onLine;
    badge.className = online ? 'badge-online' : 'badge-offline';
    badge.textContent = online ? 'En línea' : 'Sin conexión';
  }
}

window.addEventListener('online', actualizarEstadoConexion);
window.addEventListener('offline', actualizarEstadoConexion);
```

### Badge de datos guardados

```javascript
function mostrarBadge(mensaje) {
  const badge = document.getElementById('savedBadge');
  if (badge) {
    badge.textContent = mensaje;
    badge.style.display = 'block';
    setTimeout(() => { badge.style.display = 'none'; }, 3000);
  }
}
```

---

## Registro del Service Worker

```javascript
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('/sw.js')
    .then((reg) => {
      console.log('[APP] SW registrado:', reg.scope);
      guardarDatosLocal();
    })
    .catch((err) => {
      console.warn('[APP] SW no registrado:', err);
    });
}
```

---

## Pitfalls

- `self.skipWaiting()` y `self.clients.claim()` son necesarios para activación inmediata
- El SW solo funciona en HTTPS o localhost
- Tras cambiar sw.js, forzar recarga con Shift+Recargar (el SW cachea la versión anterior)
- localStorage tiene límite de ~5MB — nunca guardar datos completos
- El SW no se registra si el navegador lo bloquea (privacidad, modo incógnito)
- Los errores del SW no aparecen en la consola del main thread → usar DevTools Application tab
