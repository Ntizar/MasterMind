---
name: frontend-sparklines-plotly
description: "Patrón de sparklines (mini gráficos inline) con Plotly.js para mostrar tendencias temporales en celdas de tabla o badges. Optimizado para rendimiento con datos reducidos."
version: 1.0.0
author: Hermes Agent
tags: [frontend, charts, plotly, sparklines, performance]
---

# Frontend Sparklines con Plotly

## Descripción

Patrón para crear mini gráficos inline (sparklines) con Plotly.js que muestran tendencias temporales en espacios reducidos: celdas de tabla, badges, tarjetas resumen. Optimizado para rendimiento con datos reducidos y renderizado eficiente.

## Cuándo aplicar

- Tabla con muchas filas donde cada fila necesita mostrar una tendencia
- Dashboard con tarjetas resumen que muestran evolución temporal
- Cuando se necesita mostrar múltiples mini-gráficos sin saturar el viewport
- Cuando los datos ya están disponibles y no requieren interacción

## Cuándo NO aplicar

- Datos que requieren zoom, hover detallado o interacción → usar gráfico completo
- Cuando hay más de 50 sparklines en pantalla → usar lazy-loading
- Cuando los datos no son temporales → usar iconos o barras simples
- Cuando el rendimiento es crítico y los datos son muy grandes (>1000 puntos)

---

## 1. Sparkline básico con Plotly

```javascript
function crearSparkline(containerId, datos, opciones = {}) {
  const {
    color = '#3b82f6',
    ancho = 120,
    alto = 30,
    relleno = false,
    sinEjes = true,
  } = opciones;

  const trace = {
    x: datos.map((_, i) => i),
    y: datos,
    type: 'scatter',
    mode: relleno ? 'lines+markers' : 'lines',
    line: { color, width: 1.5 },
    fill: relleno ? 'tozeroy' : 'none',
    fillcolor: color + '20', // 12% opacidad
    hoverinfo: 'skip', // Sin hover para rendimiento
    showlegend: false,
  };

  const layout = {
    width: ancho,
    height: alto,
    margin: { l: 0, r: 0, t: 0, b: 0, pad: 2 },
    xaxis: sinEjes ? { showgrid: false, showticklabels: false, showline: false } : undefined,
    yaxis: sinEjes ? { showgrid: false, showticklabels: false, showline: false } : undefined,
    paper_bgcolor: 'rgba(0,0,0,0)',
    plot_bgcolor: 'rgba(0,0,0,0)',
  };

  Plotly.newPlot(containerId, [trace], layout, {
    responsive: true,
    displayModeBar: false,
  });
}
```

---

## 2. Reducción de datos para sparklines

```javascript
function reducirDatos(datos, maxPuntos = 50) {
  // Si hay pocos datos, devolverlos tal cual
  if (datos.length <= maxPuntos) return datos;

  // Reducir usando sampling uniforme
  const ratio = Math.ceil(datos.length / maxPuntos);
  const reducidos = [];

  for (let i = 0; i < datos.length; i += ratio) {
    // Promediar los puntos del grupo
    const grupo = datos.slice(i, i + ratio);
    const promedio = grupo.reduce((a, b) => a + b, 0) / grupo.length;
    reducidos.push(promedio);
  }

  // Asegurar último punto
  if (reducidos[reducidos.length - 1] !== datos[datos.length - 1]) {
    reducidos.push(datos[datos.length - 1]);
  }

  return reducidos;
}

// Uso: 8760 puntos → ~50 puntos para sparkline
const datosReducidos = reducirDatos(datosHorarios, 50);
crearSparkline('sparkline-demanda', datosReducidos);
```

**Patrón clave:** Reducir datos antes de renderizar. Un sparkline con 8760 puntos es más lento y menos legible que uno con 50.

---

## 3. Sparkline en celda de tabla

```javascript
function renderizarTablaConSparklines(tablaId, filas) {
  const tbody = document.querySelector(`#${tablaId} tbody`);

  filas.forEach((fila, i) => {
    const tr = document.createElement('tr');

    // Columna de datos
    const tdNombre = document.createElement('td');
    tdNombre.textContent = fila.nombre;
    tr.appendChild(tdNombre);

    // Columna de valor
    const tdValor = document.createElement('td');
    tdValor.textContent = fila.valorActual;
    tr.appendChild(tdValor);

    // Columna de sparkline
    const tdSpark = document.createElement('td');
    tdSpark.innerHTML = `<div id="spark-${i}" style="width:120px;height:30px;"></div>`;
    tr.appendChild(tdSpark);

    tbody.appendChild(tr);

    // Renderizar sparkline después de insertar en DOM
    const datosReducidos = reducirDatos(fila.tendencia, 50);
    crearSparkline(`spark-${i}`, datosReducidos, {
      color: fila.tendencia[fila.tendencia.length - 1] > fila.tendencia[0]
        ? '#22c55e' // Subiendo → verde
        : '#ef4444', // Bajando → rojo
    });
  });
}
```

---

## 4. Destrucción de sparklines para limpieza

```javascript
function destruirSparkline(containerId) {
  const container = document.getElementById(containerId);
  if (container && container.gd) {
    Plotly.purge(containerId); // Liberar memoria del canvas
  }
}

// Usar al cambiar de tab o al desmontar componente
function cambiarTab(tabName) {
  // Destruir sparklines de la tab anterior
  document.querySelectorAll('.tab-section:not(.active) .sparkline-container div')
    .forEach(el => Plotly.purge(el.id));
}
```

**Patrón clave:** Llamar `Plotly.purge()` al destruir un sparkline para liberar memoria. Sin esto, los canvas se acumulan y ralentizan la app.

---

## 5. Sparkline con valor actual destacado

```javascript
function crearSparklineConValor(containerId, datos, opciones = {}) {
  const { color = '#3b82f6', ancho = 120, alto = 30 } = opciones;

  const ultimoValor = datos[datos.length - 1];

  // Trace del sparkline
  const traceSpark = {
    x: datos.map((_, i) => i),
    y: datos,
    type: 'scatter',
    mode: 'lines',
    line: { color, width: 1.5 },
    hoverinfo: 'skip',
    showlegend: false,
  };

  // Trace del punto actual (punto más grande al final)
  const traceDot = {
    x: [datos.length - 1],
    y: [ultimoValor],
    type: 'scatter',
    mode: 'markers',
    marker: { color, size: 6 },
    hoverinfo: 'skip',
    showlegend: false,
  };

  const layout = {
    width: ancho,
    height: alto,
    margin: { l: 0, r: 0, t: 0, b: 0, pad: 2 },
    xaxis: { showgrid: false, showticklabels: false, showline: false },
    yaxis: { showgrid: false, showticklabels: false, showline: false },
    paper_bgcolor: 'rgba(0,0,0,0)',
    plot_bgcolor: 'rgba(0,0,0,0)',
    shapes: [{
      type: 'line',
      x0: 0, x1: 1,
      xref: 'paper',
      y0: ultimoValor, y1: ultimoValor,
      line: { color, width: 1, dash: 'dot' },
    }],
  };

  Plotly.newPlot(containerId, [traceSpark, traceDot], layout, {
    responsive: true,
    displayModeBar: false,
  });
}
```

---

## Puntos clave

1. **Reducir datos antes de renderizar** → 50 puntos máximo por sparkline
2. **Sin hover, sin ejes, sin leyenda** → rendimiento máximo
3. **Destruir con `Plotly.purge()`** → liberar memoria al cambiar de tab
4. **Color condicional** → verde si sube, rojo si baja
5. **Punto final destacado** → marcador más grande en el último valor
6. **Lazy-load** → no renderizar sparklines de tabs ocultas hasta que se activen
