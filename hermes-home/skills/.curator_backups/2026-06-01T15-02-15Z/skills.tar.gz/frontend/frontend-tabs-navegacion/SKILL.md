---
name: frontend-tabs-navegacion
description: "Patrón de tabs con navegación por hash, lazy-loading de contenido, estado persistente y deep-linking. Para dashboards con múltiples secciones que cargan datos de forma independiente."
version: 1.0.0
author: Hermes Agent
tags: [frontend, navigation, tabs, lazy-load, patterns]
---

# Frontend Tabs — Navegación

## Descripción

Patrón para implementar un sistema de tabs con navegación por hash (`#demanda`), lazy-loading de contenido, persistencia de estado y deep-linking. Permite compartir URLs directas a secciones específicas y cargar datos solo cuando la tab se activa.

## Cuándo aplicar

- Dashboard con múltiples tabs/secciones que cargan datos de forma independiente
- Cuando se necesita compartir una URL directa a una sección específica
- Cuando las tabs cargan datos pesados y no se quieren cargar todas a la vez
- Cuando el usuario puede marcar una tab favorita y volver a ella

## Cuándo NO aplicar

- App con una sola página → no hay necesidad de tabs
- Cuando todas las secciones se cargan simultáneamente → usar acordeón o scroll
- Cuando la navegación es simple (solo 2-3 opciones) → usar botones o menú lateral

---

## 1. Estructura HTML

```html
<nav class="tab-nav" role="tablist">
  <button class="tab-btn active" data-tab="demanda" role="tab" aria-selected="true">
    Demanda
  </button>
  <button class="tab-btn" data-tab="precios" role="tab" aria-selected="false">
    Precios
  </button>
  <button class="tab-btn" data-tab="clima" role="tab" aria-selected="false">
    Clima
  </button>
  <button class="tab-btn" data-tab="gas" role="tab" aria-selected="false">
    Gas
  </button>
</nav>

<div class="tab-panels">
  <div class="tab-panel active" id="panel-demanda" role="tabpanel">
    <div class="loading-spinner" id="spinner-demanda" style="display:none;">⏳ Cargando...</div>
    <div class="render-error" id="error-demanda"></div>
    <div class="chart-container" id="chart-demanda"></div>
  </div>
  <div class="tab-panel" id="panel-precios" role="tabpanel" hidden>
    <div class="loading-spinner" id="spinner-precios" style="display:none;">⏳ Cargando...</div>
    <div class="render-error" id="error-precios"></div>
    <div class="chart-container" id="chart-precios"></div>
  </div>
  <div class="tab-panel" id="panel-clima" role="tabpanel" hidden>
    <div class="loading-spinner" id="spinner-clima" style="display:none;">⏳ Cargando...</div>
    <div class="render-error" id="error-clima"></div>
    <div class="chart-container" id="chart-clima"></div>
  </div>
  <div class="tab-panel" id="panel-gas" role="tabpanel" hidden>
    <div class="loading-spinner" id="spinner-gas" style="display:none;">⏳ Cargando...</div>
    <div class="render-error" id="error-gas"></div>
    <div class="chart-container" id="chart-gas"></div>
  </div>
</div>
```

---

## 2. Controlador de tabs

```javascript
class TabController {
  constructor(options = {}) {
    this.tabs = new Map();
    this.currentTab = null;
    this.loadedTabs = new Set();
    this.persistState = options.persistState !== false;
    this.hashEnabled = options.hashEnabled !== false;

    this._cargarEstado();
    this._inicializarEventos();
  }

  // Registrar una tab
  registrarTab(tabName, cargarDatos) {
    this.tabs.set(tabName, {
      btn: document.querySelector(`[data-tab="${tabName}"]`),
      panel: document.getElementById(`panel-${tabName}`),
      cargarDatos,
    });
  }

  // Activar una tab
  activarTab(tabName) {
    if (this.currentTab === tabName) return;

    // Desactivar tab actual
    if (this.currentTab) {
      this._desactivarTab(this.currentTab);
    }

    // Activar nueva tab
    const tab = this.tabs.get(tabName);
    if (!tab) return;

    tab.btn.classList.add('active');
    tab.btn.setAttribute('aria-selected', 'true');
    tab.panel.classList.add('active');
    tab.panel.hidden = false;

    this.currentTab = tabName;

    // Actualizar hash
    if (this.hashEnabled) {
      history.pushState(null, '', `#${tabName}`);
    }

    // Persistir estado
    if (this.persistState) {
      localStorage.setItem('activeTab', tabName);
    }

    // Lazy-load: cargar datos solo si no se han cargado
    if (!this.loadedTabs.has(tabName)) {
      this._cargarDatosLazy(tabName);
    }
  }

  // Cargar datos lazy
  async _cargarDatosLazy(tabName) {
    const tab = this.tabs.get(tabName);
    if (!tab || !tab.cargarDatos) return;

    // Mostrar spinner
    const spinner = document.getElementById(`spinner-${tabName}`);
    if (spinner) spinner.style.display = 'block';

    try {
      await tab.cargarDatos();
      this.loadedTabs.add(tabName);
    } catch (err) {
      const errorEl = document.getElementById(`error-${tabName}`);
      if (errorEl) {
        errorEl.style.display = 'block';
        errorEl.textContent = `Error al cargar: ${err.message}`;
      }
    } finally {
      if (spinner) spinner.style.display = 'none';
    }
  }

  _desactivarTab(tabName) {
    const tab = this.tabs.get(tabName);
    if (!tab) return;
    tab.btn.classList.remove('active');
    tab.btn.setAttribute('aria-selected', 'false');
    tab.panel.classList.remove('active');
    tab.panel.hidden = true;
  }

  _inicializarEventos() {
    // Click en tabs
    document.querySelectorAll('.tab-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        this.activarTab(btn.dataset.tab);
      });
    });

    // Navegación por hash
    window.addEventListener('hashchange', () => {
      const tabName = location.hash.slice(1);
      if (tabName && this.tabs.has(tabName)) {
        this.activarTab(tabName);
      }
    });

    // Navegación con teclado (ArrowLeft/ArrowRight)
    document.querySelector('.tab-nav').addEventListener('keydown', (e) => {
      const tabs = Array.from(document.querySelectorAll('.tab-btn'));
      const currentIndex = tabs.findIndex(t => t.classList.contains('active'));

      let nextIndex;
      if (e.key === 'ArrowRight') {
        nextIndex = (currentIndex + 1) % tabs.length;
      } else if (e.key === 'ArrowLeft') {
        nextIndex = (currentIndex - 1 + tabs.length) % tabs.length;
      }

      if (nextIndex !== undefined) {
        e.preventDefault();
        tabs[nextIndex].focus();
        this.activarTab(tabs[nextIndex].dataset.tab);
      }
    });
  }

  _cargarEstado() {
    // Restaurar tab del hash o localStorage
    const hashTab = location.hash.slice(1);
    const savedTab = localStorage.getItem('activeTab');
    const defaultTab = Array.from(this.tabs.keys())[0];

    if (hashTab && this.tabs.has(hashTab)) {
      this.activarTab(hashTab);
    } else if (savedTab && this.tabs.has(savedTab)) {
      this.activarTab(savedTab);
    } else if (defaultTab) {
      this.activarTab(defaultTab);
    }
  }
}
```

---

## 3. Uso

```javascript
// Inicializar
const tabs = new TabController({
  persistState: true,
  hashEnabled: true,
});

// Registrar tabs con sus cargadores
tabs.registrarTab('demanda', async () => {
  const datos = await api.request('/api/esios/demanda');
  renderizarDemanda(datos);
});

tabs.registrarTab('precios', async () => {
  const datos = await api.request('/api/esios/precios');
  renderizarPrecios(datos);
});

tabs.registrarTab('clima', async () => {
  const datos = await api.request('/api/open-meteo/clima');
  renderizarClima(datos);
});

tabs.registrarTab('gas', async () => {
  const datos = await api.request('/api/esios/gas');
  renderizarGas(datos);
});
```

---

## Puntos clave

1. **Hash navigation** → `#demanda` permite compartir URLs directas
2. **Lazy-loading** → datos solo se cargan cuando la tab se activa
3. **Persistencia** → recordar última tab activa en localStorage
4. **Accesibilidad** → `role="tab"`, `aria-selected`, navegación con teclado
5. **Estado de loading** → spinner por sección, error por sección
6. **Set de tabs cargadas** → no recargar datos si la tab ya fue visitada
