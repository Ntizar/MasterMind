---
name: web-workers-comlink
description: "Patrón de Web Workers con Comlink para cálculos pesados sin bloquear la UI. Incluye spatial hashing, precomputación y cache. Aplicado en solmad (terrazas con sol en Madrid)."
version: 1.0.0
author: Koldo (auto-generated from Ntizar solmad exploration)
tags: [frontend, web-workers, comlink, performance, solar-calculation, spatial-indexing, precomputation]
---

# Web Workers + Comlink — Cálculos Pesados sin Bloquear UI

Patrón de usar Web Workers con Comlink para offload cálculos intensivos al hilo de background, manteniendo la UI fluida.

**Fuente:** [Ntizar/solmad](https://github.com/Ntizar/solmad) — Buscador de terrazas con sol en Madrid

## Cuándo usar

- Cálculos que requieren loops grandes (ray-casting, simulaciones, procesamiento de datos)
- Operaciones que podrían bloquear el hilo principal > 16ms (1 frame a 60fps)
- Cuando necesitas múltiples workers coordinados
- Cuando los resultados pueden precomputarse y cachearse

## Cuándo NO usar

- Cálculos simples o ligeros (< 1ms de ejecución) → el overhead de crear el worker no compensa
- Operaciones que necesitan comunicación frecuente con el main thread → la serialización/transferencia de datos consume más que el beneficio
- Cuando el código debe compartir estado mutable entre worker y main thread sin serialización → usar `postMessage` directo o refactorizar
- Aplicaciones que no soportan Web Workers (navegadores muy antiguos, entornos sin soporte para `Worker`)

## Arquitectura Básica

### 1. Worker con Comlink

```typescript
// src/workers/shadows.worker.ts
import * as Comlink from 'comlink';

class ShadowCalculator {
  // Spatial hashing grid para ray-casting eficiente
  private grid = new Map<string, Seg[]>();
  private cell = 60; // metros

  build(buildings: BuildingPoly[], originLng: number, originLat: number) {
    // Indexar edificios en grid espacial
    for (const b of buildings) {
      // Para cada arista del edificio, indexar en las celdas que toca
    }
  }

  calculateShadows(terraces: Terraza[], sunAzimuth: number, sunAltitude: number): SunState {
    // Para cada terraza, lanzar rayos en dirección del sol
    // Usar spatial index para evitar Set de todos los edificios
    // Retornar: tieneSol, sombraParcial, sinSol
  }
}

Comlink.expose(ShadowCalculator);
```

### 2. Uso desde el Main Thread

```typescript
// src/lib/shadows.ts
import * as Comlink from 'comlink';
import ShadowWorker from './workers/shadows.worker?worker';

export class ShadowService {
  private worker: Comlink.Remote<ShadowCalculator>;

  constructor() {
    this.worker = Comlink.wrap<Comlink.Remote<ShadowCalculator>>(new ShadowWorker());
  }

  async calculateShadows(buildings: BuildingPoly[], terraces: Terraza[], sunState: SunState) {
    // Llamada async al worker — NO bloquea UI
    return await this.worker.calculateShadows(terraces, sunState.azimuthDeg, sunState.altitudeDeg);
  }

  async dispose() {
    await this.worker[Comlink.release]();
  }
}
```

### 3. Vite Config para Workers

```typescript
// vite.config.ts
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  build: {
    rollupOptions: {
      output: {
        manualChunks: {
          worker: ['./src/workers/shadows.worker.ts'],
        },
      },
    },
  },
});
```

## Patrón Avanzado: Precomputación + Cache

### Precomputación en Build Time

```javascript
// scripts/precompute-sun.mjs
// Calcular posición solar para cada minuto del año
// Guardar en data/solar-day.json
// Se ejecuta en CI/CD, no en runtime
```

### Cache con GitHub API

```typescript
// src/lib/sunCache.ts
// Cache solar en data/sun-cache.json
// API endpoint /api/sun-cache para escribir desde Vercel edge
// Los aportes van a rama review antes de merge
```

### Spatial Hashing para Ray-Casting

```typescript
class SegIndex {
  cell = 60; // metros
  grid = new Map<string, Seg[]>();
  visitToken = 0; // evitar Set allocation

  indexSeg(s: Seg) {
    // Indexar segmento en todas las celdas que toca
    const cx = Math.floor(minX / this.cell);
    const cy = Math.floor(minY / this.cell);
    // 3x3 cells around current position
  }

  forEachAlongRay(ox, oy, dx, dy, len, fn) {
    // Iterar segmentos a lo largo del rayo
    // Usar visitToken en vez de Set para evitar allocation
    const token = ++this.visitToken;
    // ...
  }
}
```

## Optimizaciones Clave

### 1. visitToken vs Set
```typescript
// ❌ Lento: allocation por frame
const visited = new Set();
if (visited.has(seg)) continue;
visited.add(seg);

// ✅ Rápido: counter global
this.visitToken++;
const token = this.visitToken;
if (seg.tag === token) continue;
seg.tag = token;
```

### 2. Spatial Grid vs Brute Force
```typescript
// ❌ Brute force: O(n) por ray
for (const building of allBuildings) {
  if (rayIntersects(building, ray)) { ... }
}

// ✅ Spatial grid: O(k) donde k << n
const cell = grid.get(cx + ',' + cy);
for (const seg of cell) { ... }
```

### 3. Batch Calculations
```typescript
// Procesar terrazas en batches de 100
const BATCH_SIZE = 100;
for (let i = 0; i < terraces.length; i += BATCH_SIZE) {
  const batch = terraces.slice(i, i + BATCH_SIZE);
  await worker.processBatch(batch);
}
```

## ⚠️ Pitfalls

- **Comlink no serializa funciones:** solo datos. Si necesitas callbacks, usar postMessage directo
- **Transferir arrays grandes:** usar `Comlink.transfer()` con ArrayBuffer para evitar copia
- **Worker lifecycle:** remember to call `Comlink.release()` cuando no se necesite
- **Debugging:** los errores en workers no aparecen en console.log del main thread. Usar `worker.onerror`
- **Vite + Workers:** usar `?worker` suffix para import dinámico. Para web workers estándar, usar `new Worker()`
- **Memory leaks:** si el worker mantiene referencias a objetos grandes, liberarlos explícitamente

## Variantes

### Web Workers sin Comlink
```javascript
// Main thread
const worker = new Worker('./calc.worker.js');
worker.postMessage({ type: 'calculate', data: buildings });
worker.onmessage = (e) => { render(e.data); };

// Worker
self.onmessage = (e) => {
  const result = calculate(e.data.data);
  self.postMessage(result);
};
```

### SharedWorker para múltiples tabs
- Útil cuando varias páginas comparten el mismo cálculo
- El worker persiste entre tabs

### OffscreenCanvas + Worker
- Para rendering pesado en canvas
- Transferir OffscreenCanvas al worker

## Referencias

- [Comlink docs](https://github.com/GoogleChromeLabs/comlink)
- [Web Workers API](https://developer.mozilla.org/en-US/docs/Web/API/Web_Workers_API)
- [solmad shadows.worker.ts](https://github.com/Ntizar/solmad/blob/main/src/workers/shadows.worker.ts)
