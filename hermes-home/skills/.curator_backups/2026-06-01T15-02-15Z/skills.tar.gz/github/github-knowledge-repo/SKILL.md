---
name: github-knowledge-repo
description: "Manage a personal GitHub repo as an agent's persistent knowledge base — sync notes, skills, memory, config, and scripts between the local filesystem and version control."
version: 1.0.0
author: Hermes Agent
tags: [github, knowledge-repo, notes, backup]

---

# GitHub Knowledge Repo

Use this skill when the user has a personal GitHub repository that serves as their agent's persistent knowledge base — storing notes, skills, memory backups, configuration, and automation scripts.

## When to use

- User references a personal repo used for agent knowledge (notes, skills, memory backup)
- User wants to sync local knowledge to/from a GitHub repo
- User wants to backup memory, skills, or session notes to version control
- User wants to restore knowledge from a repo after a reset

## Standard repo structure

Most knowledge repos follow this pattern:

```
Repo/
├── README.md              ← System documentation
├── koldo/ or skills/      ← Personal SKILL.md files
├── notes/                 ← Session notes (YYYY-MM-DD-title.md)
│   └── proyectos/         ← Active project tracking
├── memory/                ← Memory backups
├── config/                ← Configuration files
├── scripts/               ← Automation scripts
└── .deploy/               ← Deployment configs (optional)
```

## Setup checklist

1. **Clone the repo** into the user's workspace (e.g., `/root/workspace/<repo-name>`)
2. **Verify GitHub auth** — check `gh auth status` or token in `/hermes-home/.env`
3. **Install skills** — copy personal skill files to `/hermes-home/skills/<name>/`
4. **Configure external_dirs** — add repo path to `config.yaml` under `skills.external_dirs`
5. **Set up cron sync** — schedule regular git pull to keep repo in sync
6. **Create SOUL.md** — define agent identity, rules, and behavior

## Sync workflow

### Push (local → remote)
```bash
cd /root/workspace/<repo-name>
git add -A
git commit -m "description of changes"
git push origin main
```

### Pull (remote → local)
```bash
cd /root/workspace/<repo-name>
git pull origin main
```

### Auto-sync via cron
- Schedule: `0 9 * * *` (daily at 09:00 UTC)
- Action: git pull + copy skills + verify auth
- See `scripts/koldo-autoconfig.sh` for a reference implementation

## Rules

1. **Never delete files from the repo** — only create new files or modify files you created
2. **Date-stamp notes** — use `YYYY-MM-DD-title.md` format in `notes/`
3. **Active projects** go in `notes/proyectos/`
4. **Skills** go in `koldo/` (or equivalent) directory
5. **Scripts** go in `scripts/`
6. **After complex tasks** (5+ tool calls), ask: does this deserve a skill, a note, or memory?

## Skill File Structure

Each skill file in the knowledge base follows a consistent format:
```
skills/{category}/{repo-name}.md
```

Categories: `ia`, `herramientas`, `audio`, `data`, `frontend`, `gis`, `devops`

See `references/github-api-exploration-patterns.md` for the API patterns used during exploration.
See `references/github-api-helpers.md` for reliable helper functions: token discovery, curl-based API wrapper, starred repo fetching, repo categorization heuristics, and file structure conventions.
See `references/session-7-repo-learnings.md` for condensed knowledge from explored repos: markitdown, mlx-vlm, nango, postgres-mcp, gaze-tracking.
See `references/autonomous-learning-session.md` for cron-driven autonomous learning session patterns: parent-only API calls, subagent delegation templates, anti-patterns, and push strategy.

## Autonomous Learning Workflow

When tasked with exploring GitHub repos (starred repos, trending repos, user-curated lists) and extracting knowledge for the knowledge base:

### Phase 1: Planning
1. Fetch the full list of repos to explore (GitHub API: `GET /users/{user}/starred?per_page=100&sort=updated`)
2. Create/update `learning-plan.md` with repos grouped by category (IA, backend, frontend, DevOps, etc.)
3. Prioritize repos by relevance and star count
4. Create `INDEX.md` if it doesn't exist

### Phase 2: Parallel Exploration (30-min sessions)
1. Select 3-5 high-priority repos per session
2. Use the GitHub API to fetch READMEs and key source files:
   - `GET /repos/{owner}/{repo}/readme` → base64 decode for content
   - `GET /repos/{owner}/{repo}/contents/{path}` → fetch specific files
   - `GET /repos/{owner}/{repo}/git/trees/main?recursive=1` → list repo structure
3. Extract: purpose, architecture, key patterns, reusable snippets, integration instructions
4. Write structured skill files to `skills/{category}/{repo-name}.md`

### Phase 3: Skill File Format
Each skill file MUST follow this template:
```
# {Repo Name}

- **URL:** https://github.com/{owner}/{repo}
- **Categoría:** {Category}
- **¿Qué hace?:** {detailed description}
- **Casos de uso:** {list of practical use cases}
- **Snippets útiles:** {copy-paste ready code examples}
- **Cómo integrarlo en proyectos:** {step-by-step integration guide}
- **Fecha de aprendizaje:** {YYYY-MM-DD}
- **Stars:** {star count}
- **Licencia:** {license}
```

### Phase 4: Commit & Push (GitHub REST API — Blobs → Tree → Commit → Ref)

When `gh` CLI is unavailable, use the GitHub REST API to push files. Reference implementation: `scripts/koldo-autoconfig.sh` or the curl-based blob/tree/commit/ref pattern.

Key rules:
- Always use full 40-char SHA for ref updates (GitHub returns HTTP 422 for truncated SHAs)
- Token from `.env` (GITHUB_TOKEN=) or `/root/.git-credentials`
- For empty repos: use `git clone` + local commit + push instead of API

### Phase 5: Update INDEX.md (curl PUT pattern)

Python's `urllib.request` can return 404 on PUT to `/contents/`. Use `curl` via `subprocess` instead. Reference: `scripts/koldo-autoconfig.sh`.

### Pitfalls
- **Subagents timeout on GitHub API** — 3+ subagents hitting the GitHub API in parallel reliably hit the 600s timeout. The parent agent MUST handle all GitHub API calls directly via `execute_code` with inline `subprocess.run()`. Subagents should ONLY write files locally.
- **Rate limiting**: 60 req/hour unauthenticated, 5000/hour with token. Use token from `.env` or `/root/.git-credentials`.
- **Large repos**: Don't clone — use the API to fetch only README + key files.
- **SHA truncation**: Always use full 40-char SHA for ref updates (GitHub returns HTTP 422 for truncated SHAs).
- **Python urllib 404 on PUT**: Use `curl` via `subprocess.run()` instead for PUT operations.
- **Empty repo creation**: If the repo doesn't exist, use `git clone` + local commit + push instead of API.

## Pitfalls

- **Token expiry**: Verify auth periodically with `curl -s -H "Authorization: token $GITHUB_TOKEN" https://api.github.com/user`
- **gh not installed**: Fall back to `git` + `curl` with token from `.env`
- **Private repos**: The GitHub public API can't see private repos. Use the token directly for API calls
- **Duplicate local clones**: Always verify only ONE local clone exists in the workspace. If you find two, compare and delete the orphan. Never work on both simultaneously.

## When NOT to Use

- Working with a personal note-taking app (Obsidian, Notion) — use that instead of a git repo
- Need real-time collaboration with non-technical team members — GitHub isn't the right tool for this
- The knowledge base is very small (<10 files) — local files or agent memory are sufficient

## Related

- `github-auth` — GitHub authentication setup
- `github-repo-management` — Clone, create, fork repos
- `hermes-agent` — Configuring Hermes Agent itself