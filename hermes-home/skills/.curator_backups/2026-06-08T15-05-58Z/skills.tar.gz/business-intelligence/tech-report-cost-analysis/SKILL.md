---
name: tech-report-cost-analysis
description: "Estimar costes de entrenamiento de modelos desde especificaciones técnicas de informes y whitepapers — cálculo de coste de hardware, computación y operación a partir de datos de infraestructura públicos."
version: 1.0.0
author: Koldo
tags: [cost-analysis, whitepaper, technical-report, GPU, training-cost, estimation]
---

# Tech Report — Estimación de Costes desde Especificaciones Técnicas

## Cuándo usarlo

- Un informe técnico / whitepaper describe un modelo pero **no declara su coste**
- Hay datos de infraestructura: número y tipo de GPUs, fases de entrenamiento, tokens, duración
- El usuario pregunta "¿cuánto ha costado?" o "¿es viable replicarlo?"
- Se necesita comparar costes entre modelos o evaluar viabilidad económica

## Datos necesarios

Extraer del informe:

| Dato | Dónde encontrarlo |
|------|------------------|
| Número de GPUs | Tabla de especificaciones de entrenamiento |
| Tipo de GPU | Sección de cluster / infraestructura (H100, A100, GB200, etc.) |
| Fases de entrenamiento | Training recipe (pre-training, mid-training, RL, SFT) |
| Tokens por fase | Tabla de training specs |
| Duración / horas (si disponible) | Sección de training o cluster |
| Goodput / MFU | Sección de cluster (eficiencia real) |
| Modelos iterados (si varios) | Sección de ablación (v1→v2→v3...) |

## Fórmulas de estimación

### Coste de hardware (CAPEX)

```
Coste_hardware = GPUs × Precio_GPU_unitario × Factor_infraestructura
```

Precios de referencia de GPUs (2024-2026):

| GPU | Precio lista (USD) | Con infraestructura (×1.5-2) |
|-----|-------------------|------------------------------|
| H100 SXM | ~$30,000 | ~$50,000 |
| GB200 NVL72 | ~$30,000 | ~$50,000 |
| A100 80GB | ~$15,000 | ~$25,000 |
| B200 | ~$35,000 | ~$55,000 |

**Factor de infraestructura** (networking, cooling, datacenter): ×1.5 a ×2 sobre precio de lista.

### Coste operativo de entrenamiento (OPEX)

```
Coste_entrenamiento = GPUs × Horas_entrenamiento × Coste_GPU_hora
```

Costes de referencia por hora GPU (cloud/on-prem operativo):

| GPU | On-prem (electricidad + operación) | Cloud (Azure/AWS/GCP) |
|-----|-------------------------------------|-----------------------|
| H100 | $1-2/hora | $3-5/hora |
| GB200 | $1.5-3/hora | $4-7/hora |
| A100 80GB | $0.5-1/hora | $1.5-3/hora |

### Estimación desde tokens

```
Horas_estimadas = Tokens_totales / (GPUs × Throughput_GPU_tokens_hora)
```

Throughput aproximado por GPU:
- H100 con modelo 35B MoE: ~5,000-10,000 tokens/segundo/GPU
- GB200 con modelo 35B MoE: ~8,000-15,000 tokens/segundo/GPU

### Coste total

```
Coste_total = Coste_hardware + Coste_entrenamiento + Coste_datos + Coste_ingenieria
```

Donde:
- **Coste_datos** = recolección, procesamiento, limpieza, deduplicación (10-30% del coste de entrenamiento)
- **Coste_ingeniería** = equipos de investigadores + ingenieros (muy variable, $2-10M/mes para equipos grandes)

## Ejemplo: MAI-Thinking-1 (Microsoft, 2026)

### Datos del informe
- **GPU:** 8,192 GB200 NVL72
- **Goodput:** ~90%
- **Fase 1 (pre-training):** 30T tokens, 8,192 GPUs
- **Fase 2 (mid-training 1):** 3.4T tokens, 8,192 GPUs
- **Fase 3 (mid-training 2):** 150B tokens, 4,096 GPUs
- **RL Climb:** 3 especialistas (STEM, Coding, Helpfulness/Safety)
- **Iteraciones:** v2 → v3 → v4 → v5 (4 versiones de arquitectura)

### Cálculo

**Hardware:**
8,192 × $30,000 × 1.6 = ~$393M (cluster completo)

*Pero Microsoft ya tenía el datacenter. El coste real es marginal (electricidad + operación).*

**Coste de entrenamiento estimado:**
- Pre-training (~60 días a 8,192 GPUs): 8,192 × 60 × 24 × $1.5 = ~$17.7M
- Mid-training (~15 días a 8,192 + 4,096): ~$3M
- RL Climb (~30 días): ~$5M
- Ablaciones e iteraciones: ~$10-20M
- **Total operativo: ~$35-50M**

**Estimación final: $50-100M** incluyendo equipo de ingeniería, datos y operación.

## Pitfalls

- **No asumir que el informe declara el coste** — la mayoría de las empresas no lo hacen
- **GB200 ≠ H100** — tienen diferentes costes y rendimiento
- **Goodput importa** — 90% goodput significa que el 10% del tiempo del cluster no produce progreso
- **Las iteraciones importan** — el modelo final es el resultado de muchas ejecuciones, no una sola
- **Los datos cuestan** — recopilar y procesar datos de calidad (30T tokens) puede igualar el coste de entrenamiento
- **Azure/Microsoft usa precios internos** — no se aplican tarifas cloud públicas para ellos
- **La estimación es un rango, no un número exacto** — siempre dar un intervalo ($50-100M, no $72.3M)

## Referencias
- `references/mai-thinking-1-cost.md` — Estimación detallada del coste de MAI-Thinking-1
