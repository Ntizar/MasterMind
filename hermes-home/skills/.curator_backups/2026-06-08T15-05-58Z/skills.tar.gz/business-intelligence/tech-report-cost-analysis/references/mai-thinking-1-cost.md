# MAI-Thinking-1 — Estimación de Coste Detallada

## Fuente
Informe técnico: "MAI-Thinking-1: Building a Hill-Climbing Machine" (Microsoft AI, junio 2026)
109 páginas. No declara coste explícitamente.

## Datos técnicos extraídos

### Hardware
- **GPU:** GB200 NVL72 clusters
- **Máximo concurrente:** 8,192 GPUs
- **Goodput:** ~90% (10% dedicado a tolerancia de fallos)
- **Infraestructura propia:** YOLO framework (in-house)

### Fases de entrenamiento (Tabla 6 del informe)

| Fase | Tokens | Contexto | GPUs |
|------|--------|----------|------|
| Pre-training | 30T | 16,384 | 8,192 |
| Mid-training 1 | 3.4T | 65,536 | 8,192 |
| Mid-training 2 | 150B | 262,144 | 4,096 |

### Iteraciones de arquitectura

| Versión | Active/Total | GPUs usadas |
|---------|-------------|-------------|
| v2 | 23B/600B | 4,096 |
| v3 | 23B/600B | 4,096 |
| v4 | 23B/611B | 4,096 |
| v5 (MAI-Base-1) | 35B/1T | 8,192 |

### RL Climb
- STEM Climb (5.5M samples, 550k pairs difíciles)
- Agentic Climb (4.87M PRs → 2.08M ambientes → 265k validados)
- Helpfulness & Safety Climb
- Consolidación en modelo único

### Modelo final
- 35B activos / ~1T total (MoE)
- 256K contexto
- 30T tokens pre-training + 3.55T mid-training
- SWE-Bench Pro 52.8%, AIME 2025 97.0%, AIME 2026 94.5%, LiveCodeBench v6 87.7%

## Cálculo de costes

### Hardware (CAPEX)
8,192 × $30,000 × 1.6 = **~$393M** (cluster completo con networking, cooling, datacenter)

*Microsoft ya tenía la infraestructura Azure. Este coste es marginal para ellos.*

### Entrenamiento (OPEX)
- Pre-training (~60 días a 8,192 GPUs × $1.5/hora): ~$17.7M
- Mid-training 1 (~10 días a 8,192 GPUs): ~$3M
- Mid-training 2 (~5 días a 4,096 GPUs): ~$0.7M
- RL Climb (~30 días): ~$5M
- Ablaciones e iteraciones (v2→v5): ~$10-20M
- **Total operativo: ~$35-50M**

### Datos
- 30T tokens limpios, sin distilar, sin datasets open-source
- Recogidos y procesados internamente
- Deduplicación múltiple (exact, fuzzy, templated, semantic)
- **Estimado: $5-15M**

### Equipo de ingeniería
- Docenas de ingenieros de sistemas, investigadores, especialistas RL
- Meses de desarrollo de YOLO framework, control planes, schedulers
- **Estimado: $10-35M**

## Estimación final

**$50-100M**

- Límite inferior: $50M (solo entrenamiento + datos, sin overhead corporativo)
- Límite superior: $100M (incluyendo equipo, datos, operaciones y overhead)
- **Comparativa:**
  - DeepSeek V3: ~$5.6M (arquitectura más eficiente)
  - Microsoft MAI-Thinking-1: ~$50-100M
  - OpenAI o1: ~$100M+ (estimaciones)
