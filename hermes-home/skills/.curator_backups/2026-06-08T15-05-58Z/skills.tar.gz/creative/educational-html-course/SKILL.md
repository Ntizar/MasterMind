---
name: educational-html-course
description: Generar cursos educativos completos en HTML interactivo — desde primaria hasta universidad. Incluye diseño unificado, tono por etapa, ejercicios interactivos con canvas, navegación entre capítulos. SOLO modo claro.
tags: [creative, education, html, interactive, math]
---

# Curso Educativo HTML Interactivo

## Trigger

Cuando el usuario pide crear un curso, tutorial, o material educativo en HTML con múltiples niveles/niveles de dificultad.

## Reglas de atribución (IMPORTANTE — preferencia del usuario)

- **NUNCA** usar "Koldo", "Aurora", "Aurora Design System" ni ningún nombre de agente/herramienta en el HTML
- **NUNCA** incluir modo oscuro — el usuario SOLO quiere modo claro
- **NUNCA** incluir CDN de Aurora ni `class="nz"` en el body
- **Atribución correcta:** `Hecho con ❤️ por <a href="https://github.com/Ntizar">David Antizar</a>`
- El autor es SIEMPRE David Antizar. No se menciona al agente ni al framework

## Estructura del proyecto

```
/root/workspace/<proyecto>/
├── MEGA-PLAN.md       ← Plan maestro (crear primero, blueprint de todas las sesiones)
├── INDEX.html         ← Página principal con navegación (SOLO sesiones públicas, NO auditoría)
├── s01-tema.html      ← Sesión 1
├── s02-tema.html      ← Sesión 2
└── sNN-auditoria.html ← Auditoría interna (NO enlazar desde INDEX)
```

## Diseño visual unificado

### Paleta (SOLO modo claro)
- Azul principal: `#2563eb`
- Naranja secundario: `#f97316`
- Fondo: `#ffffff` con gradiente suave `linear-gradient(135deg, #f0f9ff 0%, #fff7ed 100%)`
- Texto: `#1e293b`
- Éxito: `#10b981`, Error: `#ef4444`
- Glass effect: `backdrop-filter: blur(10px)` con bordes semitransparentes

### NO usar
- ❌ Aurora CDN (`cdn.jsdelivr.net/npm/@ntizar/aurora`)
- ❌ `class="nz"` en el body
- ❌ Modo oscuro toggle
- ❌ Referencias a Koldo, el agente, o cualquier herramienta

### Cajas de contenido
- 📘 Teoría: fondo azul claro, borde izquierdo azul
- 📝 Ejemplo: fondo naranja claro, borde izquierdo naranja
- ✅ Problema resuelto: fondo verde claro, paso a paso numerado
- ⚠️ Warning: fondo rojo claro
- 💡 Dato curioso: fondo púrpura claro

## Estructura de cada capítulo

```
├── 📘 Teoría (explicación clara, analogías, lenguaje adaptado a la edad)
├── 📝 Ejemplos resueltos (3+ mínimo, paso a paso con explicación de CADA paso)
├── 🧮 Problemas propuestos (5+, con solución oculta y explicación completa)
├── 🎮 Ejercicios interactivos (canvas/JS, sliders, drag & drop)
├── 📊 Gráficos interactivos (animaciones, visualizaciones en tiempo real)
└── 📋 Resumen (fórmulas clave, checklist "Hoy he aprendido...")
```

## Tono por etapa formativa

| Etapa | Edad | Tono | Frase típica |
|-------|------|------|-------------|
| 1º-2º Primaria | 6-8 | Lúdico, animales, superhéroes, frases cortas | "¡Vamos a jugar con los números! 🎉" |
| 3º-4º Primaria | 8-10 | Detectives, exploradores, retos | "¡Vamos a descubrir cómo funciona! 🔍" |
| 5º-6º Primaria | 10-12 | Ingenieros, investigadores, datos reales | "¿Te atreves con un reto más difícil? 💪" |
| 1º-2º ESO | 12-14 | Profesor joven y cercano, ejemplos modernos | "Aquí es donde las cosas se ponen interesantes..." |
| 3º-4º ESO | 14-16 | Riguroso pero accesible, aplicaciones reales | "Esto es lo que usan los ingenieros..." |
| Bachiller | 16-18 | Universitario pedagógico, contexto histórico | "Este concepto es fundamental en..." |
| 1º Carrera | 18-20 | Académico con intuición, demostraciones | "La intuición detrás de esto es..." |

## JavaScript interactivo

- Vanilla JS (sin frameworks)
- Canvas API para gráficos y animaciones
- Sliders, botones, drag & drop simple
- Funciones auto-contenidas
- Sin dependencias externas (todo vanilla)

## Navegación

- Sidebar con todos los capítulos
- Botones anterior/siguiente entre capítulos
- Progress bar del curso
- **NO** incluir modo oscuro/claro toggle

## Footer

```html
Hecho con ❤️ por <a href="https://github.com/Ntizar">David Antizar</a>
```

## Cron jobs para generación

Cuando el curso tiene múltiples sesiones, usar cron jobs espaciados cada 6h para no saturar la salida:

```javascript
// Patrón de creación de cron
cronjob(action='create', name='Math S01 — 1º Primaria', 
  prompt='...', schedule='2026-06-08T12:00:00')
```

Cada cron job debe:
1. Cargar el MEGA-PLAN.md primero para conocer la estructura
2. Generar un único HTML autocontenido
3. NO superar 2000 líneas por HTML

## Pitfalls

- **NO** usar "x" para multiplicar en primaria, usar "×" o "·"
- **NO** superar 2000 líneas por HTML (riesgo de truncamiento)
- **NO** usar frameworks JS externos (solo vanilla)
- **NO** incluir modo oscuro — el usuario lo rechazó explícitamente
- **NO** mencionar Koldo, Aurora, ni ningún agente/herramienta en el HTML
- **NO** enlazar la auditoría desde el INDEX público
- **NO** olvidar responsive (mobile-first, sidebar colapsable)
- **NO** usar jerga sin explicarla en niveles bajos
- Los canvas deben ser visualmente atractivos para la edad objetivo
- En primaria: números grandes y coloreados, emojis abundantes
- En bachiller/carrera: rigor matemático pero siempre con intuición primero