# Currículo de Matemáticas — Primaria a 1º Carrera

## S01 — 1º Primaria (6-7 años)
1. Contar del 0 al 100
2. Sumar hasta 20
3. Restar hasta 20
4. Figuras básicas (círculo, cuadrado, triángulo, rectángulo)
5. Medidas básicas (grande/pequeño, largo/corto)
6. Secuencias y patrones

## S02 — 2º Primaria (7-8 años)
1. Sumas con llevadas
2. Restas con llevadas
3. Introducción a la multiplicación
4. Tablas de multiplicar (2, 5, 10)
5. Medidas de longitud y peso
6. El dinero (euros y céntimos)

## S03 — 3º Primaria (8-9 años)
1. Multiplicación a dos cifras
2. División exacta y con resto
3. Fracciones intro (mitades, tercios, cuartos)
4. Comparar y ordenar fracciones
5. Perímetro
6. Introducción a la estadística (tablas, gráficos de barras)

## S04 — 4º Primaria (9-10 años)
1. Fracciones equivalentes
2. Sumar y restar fracciones
3. Multiplicar y dividir fracciones
4. Decimales (décimas, centésimas, milésimas)
5. Porcentajes
6. Áreas de figuras (rectángulo, triángulo, paralelogramo)

## S05 — 5º Primaria (10-11 años)
1. Proporcionalidad directa
2. Regla de tres (directa e inversa)
3. Razones y proporciones (escalas, mapas)
4. Estadística descriptiva (media, mediana, moda)
5. Probabilidad básica
6. Repaso general

## S06 — 6º Primaria (11-12 años)
1. Números negativos (recta numérica)
2. Operaciones con negativos (regla de signos)
3. Potencias y raíces
4. Introducción a ecuaciones (despejar x)
5. Ángulos y triángulos (suma = 180°)
6. Preparación ESO

## S07 — 1º ESO (12-13 años)
1. Números enteros (Z)
2. Potencias con exponente entero
3. Raíces cuadradas
4. Introducción al álgebra (expresiones, términos semejantes)
5. Ecuaciones de primer grado
6. Proporcionalidad y porcentajes avanzados

## S08 — 2º-3º ESO (13-15 años)
1. Ecuaciones de segundo grado (fórmula cuadrática, discriminante)
2. Sistemas de ecuaciones (sustitución, igualación, reducción)
3. Funciones: concepto y representación
4. Función lineal y cuadrática
5. Introducción a la trigonometría (seno, coseno, tangente)
6. Estadística y probabilidad

## S09 — Bachiller (16-17 años)
1. Límites y continuidad
2. Derivadas: concepto y reglas
3. Aplicaciones de derivadas (máximos, mínimos)
4. Integrales: concepto (área bajo la curva)
5. Técnicas de integración (sustitución, partes)
6. Probabilidad avanzada (distribución normal, Bayes)

## S10 — 1º Carrera (18-20 años)
1. Límites en R² y R³
2. Derivadas parciales y gradiente
3. Integrales múltiples
4. Álgebra lineal: espacios vectoriales
5. Transformaciones lineales (autovalores, autovectores)
6. EDOs elementales (separables, lineales, 2º orden)