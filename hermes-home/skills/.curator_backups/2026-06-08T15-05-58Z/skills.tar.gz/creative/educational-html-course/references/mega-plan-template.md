# Plantilla de MEGA-PLAN para cursos educativos HTML

## Estructura del documento

```
# 🎓 MEGA PLAN — [Nombre del Curso]

> Documento maestro de referencia para las N sesiones.
> Todas las sesiones deben seguir ESTE plan.

## 📋 ESTRUCTURA GENERAL

### N sesiones en total

| # | Sesión | Curso/Nivel | Contenido estimado | Tono |
|---|--------|-------------|-------------------|------|
| 1 | S01 | ... | ... | ... |

## 🎨 DISEÑO VISUAL UNIFICADO

### Paleta de colores (SOLO modo claro)
- Azul principal: #2563eb
- Naranja secundario: #f97316
- Fondo: #ffffff con gradiente suave
- Texto: #1e293b

### NO usar
- Aurora CDN
- Modo oscuro
- Referencias a agentes/herramientas

### Elementos visuales comunes
- Cajas de teoría, ejemplo, problema, warning, dato curioso

## 📐 ESTRUCTURA DE CADA CAPÍTULO

```
├── 📘 Teoría
├── 📝 Ejemplos resueltos (3+)
├── 🧮 Problemas propuestos (5+)
├── 🎮 Ejercicios interactivos
├── 📊 Gráficos interactivos
└── 📋 Resumen
```

## 🗣️ TONO POR ETAPA FORMATIVA

| Etapa | Edad | Tono |
|-------|------|------|

## 📚 CONTENIDO DETALLADO POR SESIÓN

### S01 — [Nombre]
**Objetivo:** ...
1. **Tema 1** — descripción, interactivo
2. **Tema 2** — ...

## ✅ CHECKLIST DE CALIDAD

- [ ] Teoría clara y adaptada al nivel
- [ ] Mínimo 3 ejemplos por concepto
- [ ] Mínimo 5 problemas con solución
- [ ] Mínimo 2 ejercicios interactivos
- [ ] Mínimo 2 gráficos interactivos
- [ ] Resumen de fórmulas al final
- [ ] Navegación entre capítulos
- [ ] Responsive en móvil
- [ ] Sin errores de JavaScript
- [ ] Todo en castellano
- [ ] Atribución correcta: David Antizar
- [ ] Sin referencias a agentes/herramientas
- [ ] Sin modo oscuro