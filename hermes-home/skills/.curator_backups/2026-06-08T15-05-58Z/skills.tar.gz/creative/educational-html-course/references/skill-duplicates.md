# STEM Math Skills — Duplicados Detectados

## Problema

Los skills de matemáticas STEM existen en DUPLICADO:
- `/hermes-home/skills/stem/math/math-*/SKILL.md` (estructura de directorio)
- `/hermes-home/skills/stem/math/math-*.md` (archivos planos)

Esto causa `Ambiguous skill name` error al hacer `skill_view(name)` con el nombre corto.

## Skills afectados (todos los del directorio stem/math/)

- math-advanced
- math-basics
- math-calculo-diferencial
- math-calculo-integral
- math-ecuaciones
- math-estadistica-probabilidad
- math-expert
- math-funciones
- math-intermediate
- math-logaritmos-exponenciales
- math-numeros-algebra
- math-sucesiones-series
- math-trigonometria
- math-vectores-matrices

## Solución

Usar ruta completa al cargar: `skill_view(name='stem/math/math-basics')` en vez de `skill_view(name='math-basics')`.

## Recomendación

Eliminar los archivos planos `/hermes-home/skills/stem/math/math-*.md` para eliminar la ambigüedad. Los SKILL.md en directorio son los que contienen el contenido completo.
