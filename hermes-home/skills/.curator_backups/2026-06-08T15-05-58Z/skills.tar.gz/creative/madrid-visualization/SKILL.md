---
name: madrid-visualization
description: "Madrid city visualization tools — isometric pixel art (Madrid3Pixel), 3D WebGL maps (NapMaps), and procedural city renderers. Stack decision guides: Canvas 2D vs MapLibre GL JS vs Three.js."
version: 1.0.0
author: Ntizar
tags: [madrid, visualization, map, isometric, 3d, webgl, canvas, city]
---

# Madrid Visualization

## Cuándo usar

- Quieres construir un visor o herramienta visual centrada en la ciudad de Madrid
- Necesitas decidir entre renderizado Canvas 2D isométrico vs WebGL 3D
- El proyecto se inspira en experiencias visuales existentes (isometric.nyc, etc.)
- Quieres efectos atmosféricos (nieve, lluvia, niebla) superpuestos a una visualización urbana
- Necesitas un repo completo con GitHub Pages / NaN.builders deploy en una sola sesión

## Stack Decision Matrix

| Necesidad | Canvas 2D Isométrico | MapLibre GL JS (WebGL 3D) | Three.js |
|-----------|---------------------|--------------------------|----------|
| Edificios 3D | Proyección isométrica manual | Extrusión nativa de polígonos | Geometría arbitraria |
| Mapa base real | No (puramente artístico) | Sí (CartoDB, ESRI, OSM) | Posible con tiles |
| Terreno 3D | No | Sí (raster DEM) | Sí |
| Ciclo día/noche | Simulado con opacidad/brillo | Iluminación 3D del motor | Iluminación 3D real |
| Partículas clima | Canvas overlay | Canvas overlay | Sistema de partículas |
| POIs interactivos | Coordenadas canvas | Marcadores nativos MapLibre | Raycaster |
| Rendimiento masa | ~5000 edificios en 2D | Ilimitado (GPU) | Ilimitado (GPU) |
| Bundle size | ~35 KB (vanilla) | ~800 KB (MapLibre) | ~600 KB (three.min) |
| TOUCH support | Manual | Nativo (pinch, rotate, pitch) | Manual |

## Patrón de Proyecto

Cada proyecto de visualización de Madrid sigue esta estructura:

```
repo/
├── index.html              # HTML con UI + canvas
├── package.json            # Vite build
├── vite.config.js
├── src/
│   ├── css/style.css       # Aurora Design System (azul #2563eb + naranja #f97316)
│   └── js/app.js           # Motor completo en un bundle
├── public/favicon.svg      # Favicon con gradiente Ntizar
└── README.md               # Documentación técnica detallada en español
```

## Reglas de Oro

1. **Código, comentarios, README y UI siempre en español**
2. **CSS Aurora v5.1** — paleta azul #2563eb → índigo #6366f1 → naranja #f97316, glassmorphism
3. **Vanilla JS + Vite** para proyectos isométricos Canvas 2D
4. **MapLibre GL JS + Vite** para proyectos con mapa base real y edificios 3D
5. **Repositorio público** (GitHub Pages) o **privado** (NaN.builders container)
6. **Un solo commit** con todo el proyecto — no desarrollo iterativo
7. **README técnico ultra-detallado** explicando stack, arquitectura, modelos abiertos, despliegue

## Proyectos en esta familia

- **Madrid3Pixel** — `Ntizar/Madrid3Pixel` → Visor isométrico pixel art (inspirado en isometric.nyc). Canvas 2D, tiles procedurales, 7 fases día/noche, edificios 3D, río Manzanares, metro L1-L6. GitHub Pages. → `references/madrid-3pixel.md`
- **NapMaps** — `Ntizar/NapMaps` (privado) → Visor 3D WebGL con MapLibre GL JS. Edificios procedurales 5000+, ciclo solar 8 fases, clima (nieve/lluvia/niebla), 14 POIs de Madrid con búsqueda, 4 estilos de mapa. NaN.builders (puerto 3700, contenedor Node.js no-root). Stadia Maps API key: `89affde8-a8b8-43b6-ab33-67c48c2a43b7`. → `references/napmaps.md`

## Pitfalls

- **Stadia Maps API key**: si la key es UUID v4, Stadia la acepta pero devuelve 401 si no hay plan activo. Tener siempre fallback a CartoDB (gratuito, sin key) en el JS.
- **MapLibre style.load**: al cambiar de estilo con `map.setStyle()`, las capas personalizadas (edificios, POIs) se pierden. Hay que resuscribirse al evento `style.load`.
- **Vite build → serve dist/**: El HTML de build referencia `/assets/` (sin prefijo `dist/`). Servir desde `dist/` directamente, no desde la raíz del proyecto.
- **Browser tool roto en NaN**: usar `curl` para validación HTTP; el navegador headless no funciona en subdominios *.apps.nan.builders.
- **Memory limit**: Almacenar solo referencias de proyecto, no estado sesión. Usar `session_search` para recuperar detalles.
