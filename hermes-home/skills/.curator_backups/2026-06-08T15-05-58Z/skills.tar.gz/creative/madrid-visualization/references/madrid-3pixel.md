# Madrid3Pixel — Visor Isométrico Pixel Art

**Repo:** `github.com/Ntizar/Madrid3Pixel`
**Deploy:** `ntizar.github.io/Madrid3Pixel/`
**Inspirado en:** [isometric.nyc](https://cannoneyed.com/projects/isometric-nyc)

## Stack

- **Visor**: Canvas 2D vanilla JS (`image-rendering: pixelated`)
- **Proyección**: Isométrica con rotación configurable
- **CSS**: Aurora v5.1 (azul + naranja, liquid glass)
- **Estructura**: Tiles procedurales (ground, building, park, water)
- **Efectos**: Partículas en canvas overlay (nieve, lluvia, niebla)
- **Deploy**: GitHub Pages via Actions (`.github/workflows/deploy.yml`)

## Funcionalidades clave

| Característica | Detalle |
|---------------|---------|
| **Fases día/noche** | 7: night → dawn → morning → midday → afternoon → sunset → dusk |
| **Edificios 3D** | Procedurales con landmarks reales (Sol, Gran Vía, Retiro, Debod, Atocha) |
| **Río Manzanares** | Curva animada con efecto shimmer |
| **Metro** | 6 líneas coloreadas (L1 a L6 circular) con colores reales |
| **Controles** | Presets horarios, capas, estilo visual, rotación, auto-rotar, screenshot |
| **Responsive** | Soporte táctil (pinch zoom + drag) |

## Estructura de archivos

```
Madrid3Pixel/
├── index.html               # HTML con UI Aurora + controles
├── src/css/style.css        # Sistema de diseño Aurora
├── src/js/main.js           # Motor: proyección, tiles, render, partículas
├── src/js/tiles.js          # Generador de tiles placeholder SVG
├── .github/workflows/deploy.yml  # CI/CD GitHub Pages
└── README.md
```

## Referencia técnica

- `main.js`: ~33.600 bytes — contiene proyección isométrica, sistema de tiles, renderizado de edificios, metro, río, parques, 7 fases día/noche, partículas atmosféricas, controles, screenshot, canvas sizing
- `tiles.js`: Generador de datos SVG inline para tiles procedurales
- `style.css`: ~17.000 bytes — Aurora v5.1 completo con glassmorphism, animaciones, gradientes

## Cómo usar

```bash
git clone https://github.com/Ntizar/Madrid3Pixel.git
cd Madrid3Pixel
npx serve . -l 3000
# O: python3 -m http.server 8080
```

GitHub Pages se deploya automáticamente al hacer push a main.

## Vínculos

- Skill padre: `creative/madrid-visualization`
- Skill hermana: `references/napmaps.md`