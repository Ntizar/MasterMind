# NapMaps — Referencia técnica

## Repositorio
- **URL**: `https://github.com/Ntizar/NapMaps` (privado)
- **Deploy**: NaN.builders → `napmaps-ntizar-ntizar.apps.nan.builders`

## Stack
- **Mapa**: MapLibre GL JS v4.7 (BSD, fork open-source de Mapbox GL)
- **Tiles base**: CartoDB (Positron/Dark Matter, gratuito, sin key)
- **Tiles satélite**: ESRI World Imagery (gratuito, sin key)
- **Tiles premium**: Stadia Maps Alidade (key: `89affde8-a8b8-43b6-ab33-67c48c2a43b7`)
- **Elevación**: AWS Terrarium (open data, terrain RGB)
- **Build**: Vite 6
- **CSS**: Aurora Design System v5.1 "Constellation"

## Funcionalidades
- 5000+ edificios procedurales de Madrid con alturas realistas
- 14 POIs: Puerta del Sol, Gran Vía, Retiro, Debod, Atocha, Bernabéu, etc.
- Ciclo solar 8 fases con iluminación dinámica
- Clima: nieve (400 copos), lluvia (600 gotas), niebla (transiciones suaves)
- 4 estilos: Calles (CartoDB Light) · Oscuro (CartoDB Dark) · Satélite (ESRI) · Terreno 3D (MapLibre)
- Búsqueda de POIs con fly-to animado
- Vista aérea / modo 3D toggle
- Screenshot con captura canvas
- FPS counter

## Dockerfile (NaN.builders)
Patrón: `FROM node:20-alpine` single-stage con usuario no-root (`appuser`).
- Puerto: 3700 (NaN) + 80 (healthchecks)
- Build: `npm ci` + `npx vite build`
- Serve: servidor Node.js embebido con SPA fallback
- Healthcheck: `wget -qO- http://localhost:80/ || exit 1`

## Problemas conocidos
- **Stadia Maps API key**: válida pero puede devolver 401 si el plan no soporta el estilo. Tener fallback a CartoDB en el código JS.
- **MapLibre style.load**: al cambiar estilo con `map.setStyle()`, las capas personalizadas se pierden. Resuscribirse al evento `style.load`.
- **NaN deploy bloqueado por root**: si el contenedor ejecuta como root, el pod se queda en Pending. Siempre usar `USER appuser`.
- **NaN polling**: no hay webhooks. NaN detecta cambios cada ~1-5 minutos.

## Para desarrollo local
```bash
git clone https://github.com/Ntizar/NapMaps.git
cd NapMaps && npm install && npm run dev
# Abre en http://localhost:3000
```