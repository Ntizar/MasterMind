---
name: sistema-electrico-simulador
description: "Simulador interactivo del sistema electrico espanol 2026-2035: simulacion anual de 8.760 horas, trayectoria multianual, 17 escenarios, demanda sectorial, almacenamiento avanzado, politica energetica. Derivado de SistemaElectricoFuturo."
version: "1.0.0"
tags: [energia, simulador, sistema-electrico, monte-carlo, spain]
---

# Sistema Electrico Simulador - Patron de Simulacion Energetica

## Descripcion

Patron para construir simuladores interactivos del sistema electrico espanol con simulacion horaria de 8.760 horas, trayectoria multianual, escenarios politicos y metricas de estres del sistema.

## Origen

Derivado del repositorio [SistemaElectricoFuturo](https://github.com/Ntizar/SistemaElectricoFuturo) v3.1.

## Novedades v3.1

- 17 escenarios con casos realistas para Espana
- Demanda sectorial: residencial, servicios, industria, VE, bombas de calor, H2 verde
- Calendario nuclear real basado en ENRESA con opcion de prorroga
- Almacenamiento avanzado: degradacion de baterias, bombeo con reserva estacional, V2G
- Politica energetica: tope ibérico, CfDs, peajes dinamicos, PVPC
- Trayectoria 2026-2035 con rampas de despliegue y estado persistente entre anos

## Modos de Analisis

### 1. Simulacion Anual
Calcula una unica anualidad de 8.760 horas para un ano objetivo. Sirve para comparar escenarios, ajustar parametros o estudiar sensibilidad.

### 2. Trayectoria 2026-2035
Ejecuta 10 anos consecutivos con:
- Rampas de solar, eolica, offshore y baterias
- Crecimiento del parque VE y bombas de calor
- Acumulacion del objetivo de H2
- Degradacion de baterias entre anos
- Disponibilidad nuclear segun calendario real o prorroga

## Escenarios Incluidos

| # | Escenario | Idea principal |
|---|-----------|----------------|
| 0 | Datos Reales 2025 | Referencia base del sistema reciente |
| 1 | PNIEC Base 2030 | Despliegue renovable y almacenamiento de referencia |
| 2 | Prorroga Nuclear | Mas firmeza nuclear, menos urgencia de respaldo |
| 3 | Sin Nuclear | Cierre acelerado y fuerte tension de sistema |
| 4 | Almacenamiento Masivo | Mucha bateria y bombeo para absorber excedentes |
| 5 | Crisis del Gas | Gas y CO2 muy altos |
| 6 | Hidrogeno Verde | Electrolisis flexible absorbiendo excedentes |
| 7 | Sequia Extrema | Baja hidraulicidad y mas estres del sistema |
| 8 | Cierre Nuclear ENRESA | Calendario oficial sin prorroga |
| 9 | Prorroga 60 Anos | Escenario defensivo de seguridad de suministro |
| 10 | Apagón Ibérico Repetido | Shock de inercia y reserva rodante |
| 11 | VE Masivo 2030 | 10M de VE, smart charging y V2G |
| 12 | Autoconsumo 30 GW | FV detras del contador a gran escala |
| 13 | PNIEC 2030 Actualizado | Variante mas ambiciosa del despliegue |
| 14 | Ley de Cambio Climatico 2050 | Senda multianual de descarbonizacion |
| 15 | Ola de Calor Extrema | Pico de demanda y penalizacion solar |
| 16 | Crisis Geopolitica Gas + CO2 | Shock europeo con prorroga nuclear defensiva |

## Fuentes de Datos

- REE: https://www.ree.es/es/datos
- OMIE: https://www.omie.es/
- MITECO: https://www.miteco.gob.es/es/energia/temas/planificacion/plan-nacional-integrado-energia-clima.html
- CNMC: https://www.cnmc.es/ambitos-de-actuacion/energia/peajes-y-cargos
- ENTSO-E: https://transparency.entsoe.eu/
- EU ETS: https://climate.ec.europa.eu/eu-action/eu-emissions-trading-system-eu-ets_es

## Metricas Clave

- Horas sin gas
- Estres de red
- Coste del sistema
- LCOE y LCOS aproximados
- Renovables media antes/despues

## Implementacion en Hermes

Para replicar este patron:

1. Crear modulo de demanda sectorial por subsector
2. Implementar calendario nuclear real (ENRESA)
3. Modelar almacenamiento con degradacion
4. Simular 8.760 horas con datos ESIOS/REE
5. Generar dashboard con graficas interactivas (Chart.js o Plotly)
6. Permitir comparar multiples escenarios

## Pitfalls

- **Validacion tecnica minima** — cubrir sintaxis JS, simulacion anual y trayectoria multianual
- **Fuentes de datos** — las APIs de REE/OMIE pueden tener cambios de endpoint
- **Rendimiento** — 8.760 horas x 10 anos x 17 escenarios puede ser pesado, usar cache
- **ESLint v10 flat config** — ESLint v10 ignora .eslintrc.json. Crear eslint.config.js con globals explicitos (Vue, Plotly, SEF, C). Ver skill frontend-dashboard-patterns patron 13.
- **Vite rutas relativas en index.html** — scripts con src="js/app.js" no se procesan por Vite. Usar src="/js/app.js" con barra leading. Para IIFEs (sin type="module"), usar post-build script (postbuild.js) que copia JS/CSS a dist/ y transforma referencias. Ver skill frontend-dashboard-patterns patron 14.