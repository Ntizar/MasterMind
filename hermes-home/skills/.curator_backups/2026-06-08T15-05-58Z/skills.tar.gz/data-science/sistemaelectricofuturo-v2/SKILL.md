---
name: sistemaelectricofuturo-v2
version: "2.0.3"
title: Sistema Eléctrico Futuro v2
description: Simulador interactivo del sistema eléctrico español 2026-2050 — motor headless TypeScript, datos climáticos reales Open-Meteo, merit-order SRMC, Monte Carlo multi-semilla.
tags: [electricity, energy, simulation, spain, esios, ree, merit-order, srmc, monte-carlo, typescript, vue]
added: 2026-06-02
---

# Sistema Eléctrico Futuro v2

> Repositorio: `Ntizar/SistemaElectricoFuturo-v2`
> Versión actual: **v2.0.3** (auditoría + correcciones junio 2026)
> Lengua: **castellano obligatorio**

## Arquitectura

**Motor headless TypeScript** + **Frontend Vue 3** + **Backend Node.js** (Express opcional)

```
src/
├── engine/                    # Motor de simulación (sin UI, ejecutable en Node y browser)
│   ├── types.ts               # Tipos: SimParams, SimResult, HourlyResult, AnnualSummary
│   ├── utils.ts               # Mulberry32 PRNG, clamp, mean, percentile, calendario
│   ├── defaults.ts            # PARAMS_DEFAULT + 14 escenarios predefinidos
│   ├── index.ts               # Orquestador: simular(params, weather) → SimResult
│   ├── merit-order.ts         # Despacho SRMC 12 tecnologías + precio marginal
│   ├── price.ts               # Peajes P1/P2/P3 + CfD doble cara + precio final
│   ├── demand.ts              # Demanda sectorial (residencial, servicios, industria, VE, HPC)
│   ├── nuclear.ts             # Calendario ENRESA (7 reactores, paradas recarga ~30d/18m)
│   ├── storage.ts             # Baterías Li-ion + bombeo + V2G con SOC tracking
│   └── weather/               # Modelo climático v2
│       ├── index.ts           # Orquestador: obtenerClima(config) → ProcessedWeather
│       ├── open-meteo.ts      # Fetch Open-Meteo Archive API (gratis, sin key)
│       └── climate-shift.ts   # Ajustes IPCC: ΔT, brightening solar, sequía, olas calor
├── server/                    # Express (desplegado opcionalmente)
│   ├── index.ts               # Servidor Express con health checks
│   └── routes/                # POST /api/simulate, GET /api/weather, GET /api/scenarios
├── web/                       # Frontend Vue 3 + Plotly
│   ├── main.ts                # Entry point
│   ├── App.vue                # Layout + tabs + orquestación
│   └── components/            # 10 componentes Vue
├── data/                      # Datos de referencia
└── tests/                     # 19 tests de calibración (Vitest)
```

### Stack
- **Motor:** TypeScript headless (sin dependencias UI)
- **Backend:** Express.js (opcional para Monte Carlo pesado)
- **Frontend:** Vue 3 + Vite 6
- **Charts:** Plotly.js (via plotly.js-dist-min)
- **Tests:** Vitest
- **Build:** TypeScript estricto + vue-tsc
- **Deploy:** Docker multi-stage → NaN.builders / Cloudflare

## Modelo climático v2 (INNOVACIÓN CLAVE)

**v1 (semillas):** Mulberry32 → clima pseudoaleatorio. Sin correlaciones reales.
**v2 (datos reales):** Open-Meteo Archive API → 8760 horas de radiación, viento, temperatura reales. Climate Shift aplica ΔT IPCC sobre datos físicos.

```
Open-Meteo Archive (2020-2025) → fetchOpenMeteo() → procesarOpenMeteo() → aplicarClimateShift() → ProcessedWeather
```

- Radiación solar → capacity factor (800 W/m² pico, modelo panel 30° sur)
- Viento → CF eólico (modelo turbina: cut-in 3m/s, rated 12m/s, cut-out 25m/s, potencia ∝ v³)
- ΔT = (añoObj - añoRef) / 10 × 0.3°C (IPCC SSP2-4.5)
- Brightening: +0.5%/año radiación solar
- Sequía: hidraulicidad reducida, olas de calor extremas

## Engine API

```typescript
import { simular } from '@engine';
import { getWeatherData, procesarOpenMeteo } from '@engine/weather/open-meteo';
import { aplicarClimateShift } from '@engine/weather/climate-shift';

const rawData = await getWeatherData(2024);
const weather = procesarOpenMeteo(rawData);
const ajustado = aplicarClimateShift(weather, { deltaT: 0.3, ... });
const resultado = await simular(params, ajustado);
// resultado.resumen → AnnualSummary (precio medio, ENS, LOLE, emisiones)
// resultado.hourly → HourlyResult[] (8760 horas)
```

## Tests

```bash
npx vitest run  # 36 tests: 19 calibración + 17 integración
```

Tests cubren: nuclear (ENRESA), CF solar/eólico, SRMC (nuclear, solar, CCGT), PRNG Mulberry32, utilidades, pérdidas de red, hidrofluyente, offshore CF, inercia síncrona, degradación baterías, V2G nocturno, mes climate-shift, industria fines de semana.

## Escenarios predefinidos (14)

nuclear: base-2030, prorroga-10, prorroga-20, cierre-2030, sin-nuclear
renovables: pniec-2030, futuro-verde, almacenamiento-masivo
costes: gas-caro, gas-barato
demanda: demanda-alta
stress: sequia-extrema, apagon-repunte, sin-gas
politica: balance-cero

## Datos de referencia REE 2025

| Concepto | Capacidad (GW) | Generación (TWh) | CF |
|----------|---------------|-----------------|-----|
| Nuclear | 7.3 (reporta 7.0) | 51.9 | 0.90 |
| Solar FV | 24.7 | 52.5 | 0.24 |
| Eólica | 31.6 | 55.6 | 0.20 |
| Hidro | 17.1 | 37.6 | 0.20 |
| Gas (CCGT) | 24.0 | 52.1 | — |
| Demanda | — | 248 | — |
| Precio medio | — | — | 63 €/MWh |

## Componentes Vue (cableados y funcionales)

| Componente | Función | Tab |
|------------|---------|-----|
| `ControlPanel.vue` | Sliders: capacidad, costes, demanda, clima, escenarios | — (sidebar) |
| `KPICards.vue` | 6 tarjetas KPI con colores semáforo | — (header) |
| `HourlyChart.vue` | Mix generación stacked + precio (Plotly) | `mix` |
| `TrajectoryChart.vue` | Trayectoria 2026-2035 multi-eje | `trayectoria` |
| `ComparisonView.vue` | Comparación lado a lado escenarios | `comparacion` |
| `HeatmapChart.vue` | Mapa de calor precios hora×día | `heatmap` |
| `DispatchSankey.vue` | Diagrama Sankey flujo anual | `sankey` |
| `MonteCarloPanel.vue` | Monte Carlo multi-semilla con histograma | `mc` |
| `SliderRow.vue` | Slider individual | (subcomponente) |
| `SliderGroup.vue` | Contenedor de sliders | (subcomponente) |

**Todos los componentes están cableados** (auditoría junio 2026). MonteCarloPanel llama al engine directamente en browser (`import { simular } from '../../engine/index'`).

## Backend (Fase 3 — desplegado opcionalmente)

- Express en `src/server/index.ts`
- Rutas: `simulate.ts`, `weather.ts`, `scenarios.ts`
- Cache LRU (50 entradas, sin TTL — posible fuga de memoria)
- Health checks: `/healthz` (uptime), `/readyz` (ready)
- **Sin Helmet, sin rate limiting, sin logging estructurado**

## Deploy (NaN.builders)

- Dockerfile multi-stage: builder (npm ci + build + typecheck) → runtime (serve -s dist)
- **Arquitectura frontend-only:** Engine se ejecuta en browser. Backend Express no es necesario.
- Service Worker dinámico: cache-first para assets, network-first para Open-Meteo API
- Source maps desactivados en producción
- Build Vite: 57 módulos, ~26s. Plotly (4.6MB) es el chunk más grande.
- **Archivos de proyecto:** `.env.example` (creado), `.nvmrc` (Node 22), `docs/PLAN.md` (tracking de mejoras)

---

## ⚠️ PITFALLS — Resueltos / Activos

### ✅ RESUELTOS (auditoría + correcciones junio 2026)

#### B1: Grid losses duplicado → CORREGIDO
- **Antes:** `perdidasRed: demandaRed * 1.04` (doble aplicación del 4%).
- **Ahora:** `perdidasRed: demandaRed - demandaGW` (diferencia real, línea index.ts:287).

#### B2: Hidro correlacionado con viento → CORREGIDO
- **Antes:** `hidroFluyente = ... clamp(weather.wind[h] * 1.5 + 0.2, 0.3, 1.0)`.
- **Ahora:** Usa `weather.precipitation[h] / 5 × factorEstacionalHidro × hidraulicidad`.

#### B3: Offshore factor ad-hoc → CORREGIDO
- **Antes:** Factor `1.1` sobre wind CF sin justificación.
- **Ahora:** `FC_EOLICO_OFFSHORE_REAL = 0.45` en `types.ts`, calibrado.

#### B4: Sankey con valores hardcoded → CORREGIDO
- **Antes:** `16.5%`, `21.3%` fijos en `DispatchSankey.vue`.
- **Ahora:** Lee `props.resumen.generacionPorTecnologia`.

#### B5: Backend inseguro → Documentado (frontend-only)
- El deploy es frontend-only. Backend Express no se construye en producción.

#### Backend no desplegado → Frontend-only implementado
- **Antes:** El Dockerfile ejecuta `serve -s dist`. Backend Express no se construye.
- **Ahora:** Engine headless se ejecuta directamente en el navegador. MonteCarloPanel llama a `import { simular } from '../../engine/index'`. Open-Meteo permite CORS directo.
- **No requiere backend para simulación estándar.**

#### Service Worker roto → Cache dinámico
- **Antes:** `STATIC_ASSETS = ['/assets/main.js']` no coincide con hashes de Vite.
- **Ahora:** Estrategia dinámica: cache-first para assets del mismo origen, network-first para Open-Meteo. Ver `public/sw.js`.

#### Source maps expuestos → Desactivados
- **Antes:** `sourcemap: true` en producción.
- **Ahora:** `sourcemap: false` en build.

#### Error banner invisible → Implementado
- **Antes:** catch de errores solo hacía `console.error`.
- **Ahora:** `errorMsg` reactivo con banner rojo visible y botón dismiss.

#### Progreso trayectoria sin feedback → Añadido
- **Antes:** 10 simulaciones secuenciales sin indicador.
- **Ahora:** `progresoAnimacion` muestra "📈 Trayectoria: año X/10 (20XX)".
- **Datos Open-Meteo cargados una vez** y reutilizados para todos los años.

#### calcularDemandasHoraria duplicado → Unificado
- **Antes:** `index.ts` tenía su propia función simplificada duplicando `demand.ts`.
- **Ahora:** `index.ts` importa y usa `calcularDemandaHoraria()` de demand.ts.

#### Componentes sin cablear → Todos activos
- **Antes:** MonteCarloPanel, HeatmapChart, DispatchSankey no se mostraban.
- **Ahora:** 7 tabs funcionales: mix, trayectoria, comparacion, heatmap, sankey, mc, info.

#### A1: Mes en climate-shift → CORREGIDO
- **Antes:** `Math.floor((h % 8760) / 730)`.
- **Ahora:** `Math.floor(h / 730.5)`.

#### A2: Degradación baterías exponencial → CORREGIDO
- **Antes:** `b.capacidadMax *= (1 - degradacion * 0.0001)` (colapso exponencial).
- **Ahora:** Incremental con mínimo 80% de capacidad original.

#### A3: V2G sin restricción horaria → CORREGIDO
- **Antes:** V2G activo 24h.
- **Ahora:** Solo nocturno (22h–06h), parámetro `horaDelDia` en `operarAlmacenamiento`.

#### A4: Industria fines de semana -70% → CORREGIDO
- **Antes:** Factor 0.3 (España es ~25% de bajada).
- **Ahora:** Factor 0.75.

#### A5: Inercia síncrona = nuclear + hidroFluyente → CORREGIDO
- **Antes:** `mustRunGW = nuclear + hidroFluyente`.
- **Ahora:** `mustRunGW = nuclear + hidroEmbalse`.

#### M1: DeltaT arbitrario → CORREGIDO
- **Antes:** 0.3°C sin justificación.
- **Ahora:** 0.5°C (IPCC SSP2-4.5: 0.2°C/década × 3 décadas desde 2020).

#### M2: Mulberry32 duplicado → CORREGIDO
- **Antes:** Clase en `utils.ts` + función en `index.ts`.
- **Ahora:** Import único de `utils.ts`.

#### M3: Slider baterías 0–80 GW → CORREGIDO
- **Antes:** Max 80 GW (imposible físicamente).
- **Ahora:** Max 25 GW + slider horas (1–12h) + slider hidraulicidad.

### 🟡 ACTIVOS (pendientes de mejora)

#### Cache LRU sin TTL (solo si se usa backend Express)
- `src/server/routes/simulate.ts`: cache con Map, límite 50 entradas, sin TTL.
- Solución: añadir TTL (1h).

#### Sin rate limiting en POST
- POST /api/simulate sin límite. Cada llamada descarga datos Open-Meteo + simulación completa.
- Solución: `express-rate-limit` (10 req/min).

#### Plotly 4.6MB en bundle
- `plotly.js-dist-min` es el chunk más grande del build.
- Solución: carga diferida con `import()` dinámico en cada componente que lo necesita.

#### Sin tests de integración servidor
- Solo `calibration.test.ts` (19 tests engine) + `integracion.test.ts` (17 tests).
- Recomendación: añadir supertest para rutas Express si se despliega backend.

#### Sin Web Worker para Monte Carlo pesado
- 100+ semillas ejecutadas en batches de 5 en el hilo principal.
- Congela UI durante ~10-30s según cantidad.
- Solución: mover Monte Carlo a Web Worker via Comlink.

---

## Recomendación arquitectónica: Frontend-only

El motor headless TypeScript está diseñado para ejecutarse tanto en Node como en browser. Dado que el deploy NaN.builders sirve estáticos eficientemente, la arquitectura óptima es:

```
[Browser] → import @engine → simulate(weather) → Plotly charts
           → fetch Open-Meteo directo (CORS)
           → Monte Carlo en Web Worker (opcional)
```

**Ventajas:**
- Sin backend = sin coste de servidor, sin 502, sin latencia API
- Funciona offline (con SW corregido)
- El mismo código sirve para dev y prod
- Monte Carlo pesado → endpoint Express opcional en NaN separado

**Contraindicaciones:**
- Open-Meteo tarda ~2-5s en descargar 8760 horas desde browser (CORS ok pero lento)
- Cache de datos climáticos en IndexedDB necesario para evitar re-descargas
- Monte Carlo 100+ semillas puede congelar el UI → Web Worker necesario

---

## Referencias

- `references/corrupcion-archivos-lineas.md` — Cómo evitar corrupción de archivos con patch/read_file
- `references/service-worker-dinamico.md` — Patrón SW dinámico para Vite (cache-first + network-first)
- `references/auditoria-junio-2026.md` — Auditoría completa: 5 críticos, 6 altos, 6 medios. Hallazgos B1-B17.