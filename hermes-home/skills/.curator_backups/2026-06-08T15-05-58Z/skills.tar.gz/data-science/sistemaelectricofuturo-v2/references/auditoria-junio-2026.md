# Auditoría Sistema Eléctrico Futuro v2 — Junio 2026

## Metodología
- Revisión completa de código: engine (TypeScript), frontend (Vue 3), backend (Express), tests, config.
- 11 archivos de engine, 10 componentes Vue, 3 rutas Express, Dockerfile, config.
- 19 tests de calibración existentes (Vitest).

## Hallazgos Clasificados

### 🔴 Críticos (5)

| ID | Archivo | Problema | Impacto |
|----|---------|----------|---------|
| B1 | `src/engine/index.ts:162` | Grid losses duplicado (1.04 aplicado dos veces) | Distorsión balance energético ~4%, afecta precio y ENS |
| B2 | `src/engine/index.ts:157` | Hidro fluyente correlacionado con wind en vez de precipitation | Sobreestimación hidro en sequías con viento |
| B3 | `src/engine/index.ts:64` | Factor ad-hoc 1.1 en offshore sin justificación | Sobreestimación CF eólico con offshore |
| B4 | `src/web/components/DispatchSankey.vue:24` | Sankey con porcentajes hardcoded (16.5%, 21.3%, 19.1%) | Gráfico decorativo, no muestra resultados reales |
| B5 | `src/server/index.ts` | CORS wildcard, sin Helmet, sin rate limiting | Vulnerable a abuso si se despliega backend |

### 🟠 Altos (6)

| ID | Archivo | Problema |
|----|---------|----------|
| B6 | `src/engine/index.ts:148` | Hidro bombeo no considera precio bajo para activarse |
| B7 | `src/engine/storage.ts` | Batería sin degradación (ciclos ilimitados) |
| B8 | `src/engine/index.ts:180` | V2G modelado como capacidad fija, no por hora |
| B9 | `src/engine/weather/climate-shift.ts` | Mes de aplicación del shift sin alineación temporal |
| B10 | `src/server/routes/simulate.ts` | Cache LRU sin TTL, posible memory leak |
| B11 | `src/engine/index.ts` | Sin verificación de balance energético (generación = demanda) |

### 🟡 Medios (6)

| ID | Archivo | Problema |
|----|---------|----------|
| B12 | `src/web/components/DispatchSankey.vue` | Datos de ejemplo en tooltip |
| B13 | `src/engine/defaults.ts` | Escenarios sin comentarios explicativos |
| B14 | `src/engine/weather/open-meteo.ts` | Sin cache de datos Open-Meteo |
| B15 | `tests/engine/calibration.test.ts` | Solo tests unitarios, sin integración |
| B16 | `src/engine/index.ts` | Sin warnings por parámetros fuera de rango |
| B17 | `src/web/App.vue` | Sin lazy loading de Plotly (4.6MB bundle) |

## Recomendación de Prioridad
1. **B1-B2** (engine core) → Más impacto científico
2. **B4** (Sankey) → Impacto visual/UX directo
3. **B5** (backend security) → Solo si se despliega backend
4. **B7** (battery degradation) → Impacto a largo plazo
5. **B11** (balance check) → Verificación de integridad
