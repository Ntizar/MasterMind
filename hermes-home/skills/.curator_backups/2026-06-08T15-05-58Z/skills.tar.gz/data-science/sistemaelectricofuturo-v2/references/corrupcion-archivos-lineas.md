# Corrupción de archivos por prefijos de línea

## Problema

Cuando se usa `read_file()` en execute_code, el output incluye prefijos de línea:
```
     1|import { simular } from './index';
     2|
     3|export function test() {
```

Si ese contenido se pasa directamente a `write_file()` o `patch()`, los prefijos quedan escritos en el archivo, corrompiéndolo.

## Ejemplo de corrupción

```python
# ❌ MAL — corrompe el archivo
from hermes_tools import read_file, write_file
content = read_file("src/engine/types.ts")["content"]
write_file("src/engine/types.ts", content)  # Archivo ahora tiene "     1|..." en cada línea
```

## Solución

```python
# ✅ BIEN — limpiar prefijos antes de escribir
import re
content = read_file("src/engine/types.ts")["content"]
clean = re.sub(r'^\s*\d+\|', '', content, flags=re.MULTILINE)
write_file("src/engine/types.ts", clean)
```

## Solución alternativa (terminal)

```bash
sed -i 's/^[0-9]*|//' archivo.ts
```

## Prevención

1. **NUNCA** usar output de `read_file()` directamente en `write_file()`
2. Siempre limpiar prefijos con regex antes de reescribir
3. Si el archivo es largo (>200 líneas), considerar usar `terminal` con `cat` en vez de `read_file`
4. Después de escribir, verificar con `head -5 archivo.ts` que no tiene prefijos

## Detección

Si un archivo tiene líneas que empiezan con espacios + número + `|`, está corrompido:
```bash
grep -P '^\s*\d+\|' archivo.ts  # Detecta corrupción
sed -i 's/^[0-9]*|//' archivo.ts  # Repara
```
