# Service Worker Dinámico para Vite

## Problema

SW con rutas fijas (`/assets/main.js`) fallan con Vite porque:
- Nombres con hash: `/assets/index-DGm1QEKq.js`
- Hash cambia cada build → SW cachea rutas inexistentes

## Solución: Estrategia por tipo de recurso

### Cache-first (assets mismo origen)
```js
async function cacheFirst(request) {
  const cached = await caches.match(request);
  if (cached) return cached;
  const response = await fetch(request);
  if (response.ok) {
    const cache = await caches.open(CACHE_NAME);
    cache.put(request, response.clone());
  }
  return response;
}
```

### Network-first (APIs externas)
```js
async function networkFirst(request, cacheName) {
  try {
    const response = await fetch(request);
    if (response.ok) {
      const cache = await caches.open(cacheName);
      cache.put(request, response.clone());
    }
    return response;
  } catch {
    const cached = await caches.match(request);
    return cached || new Response('Offline', { status: 503 });
  }
}
```

### Router de fetch
```js
self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);
  if (url.hostname.includes('open-meteo.com'))
    return event.respondWith(networkFirst(event.request, API_CACHE));
  if (url.origin !== self.location.origin)
    return event.respondWith(fetch(event.request));
  event.respondWith(cacheFirst(event.request));
});
```

### Activación + limpieza
```js
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME && k !== API_CACHE).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});
```

## Cuándo aplicar

- Apps Vue/React/Vite con SW para PWA
- Deploys en plataformas estáticas (NaN.builders, CF Pages, Netlify)
- Assets con nombres no predecibles (Vite hashes)

## Contraindicaciones

- Precacheo específico al instalar → vite-plugin-pwa mejor
- Shell SPA que debe cargar offline inmediatamente