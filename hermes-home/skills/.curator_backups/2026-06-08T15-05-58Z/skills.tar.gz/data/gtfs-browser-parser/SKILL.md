---
name: gtfs-browser-parser
description: Parser GTFS completo en navegador: descompresion ZIP en memoria con fflate, deteccion de encoding, tolerancia a ficheros malformados, logica completa de calendario GTFS (calendar.txt + calendar_dates.txt). Derivado de nap-dashboard.
version: "1.0.0"
tags: [gtfs, transporte, parser, navegador, movilidad]
---

# GTFS Browser Parser - Patron de Parsing GTFS en Navegador

## Descripcion

Patron para parsear ficheros GTFS comprimidos directamente en el navegador sin servidor: descompresion en memoria, parsing de CSV, logica completa de calendario GTFS y visualizacion de rutas.

## Origen

Derivado del repositorio [nap-dashboard](https://github.com/Ntizar/nap-dashboard) que consume la API del NAP (Punto de Acceso Nacional de transporte de España).

## Arquitectura

```
Browser
  -> fflate (descompresion ZIP en memoria)
  -> Parser CSV propio
  -> Deteccion de encoding (UTF-8 -> Windows-1252 fallback)
  -> Logica calendario GTFS
  -> Visualizacion (Leaflet + Recharts)
```

## Parsing GTFS

- **Descompresion en memoria** con `fflate` — sin escribir nada en disco
- **Deteccion de encoding** — fallback UTF-8 -> Windows-1252 cuando se detectan caracteres corruptos
- **Tolerancia a ficheros malformados** — cada fila se parsea en try/catch; las filas con errores se cuentan y se notifican
- **Cap de stop_times** — limitado a 100.000 registros para no bloquear el hilo principal
- **Tipos de ruta europeos extendidos** (NeTEx 100-1700): tren de alta velocidad, cercanias, metro, tranvia, funicular, teleférico, ferry

## Logica de Calendario GTFS

El visor implementa la logica completa del estandar GTFS para determinar si un servicio opera en un dia concreto:

1. Comprueba primero `calendar_dates.txt` (excepciones puntuales — tienen prioridad)
2. Si no hay excepcion, consulta `calendar.txt` (dias de la semana + rango de fechas)
3. Si un servicio solo usa `calendar_dates.txt` (sin `calendar.txt`), funciona igualmente

## Estructura del Parser

```javascript
// Ficheros GTFS standard
const GTFS_FILES = [
  'agency.txt',
  'routes.txt',
  'trips.txt',
  'stop_times.txt',
  'stops.txt',
  'calendar.txt',
  'calendar_dates.txt',
  'frequencies.txt',
  'transfers.txt',
  'transfers.txt',
  'feed_info.txt'
];

// Logica de calendario
function isServiceActiveOnDate(serviceId, date, calendar, calendarDates) {
  // 1. Check calendar_dates first (exceptions have priority)
  const exception = calendarDates.get(serviceId)?.get(date.toISOString());
  if (exception) return exception.type === 1; // 1 = added, 2 = removed
  // 2. Check calendar.txt
  const cal = calendar.get(serviceId);
  if (!cal) return false;
  const dayOfWeek = date.getDay();
  const isValidDay = checkDayOfWeek(cal, dayOfWeek);
  const isInDateRange = date >= cal.startDate && date <= cal.endDate;
  return isValidDay && isInDateRange;
}
```

## Implementacion en Hermes

Para replicar este patron:

1. Usar `fflate` para descompresion ZIP en memoria (no `jszip` — mas ligero)
2. Parsear CSV con split por lineas y comas (no usar libreria pesada)
3. Implementar fallback de encoding UTF-8 -> Windows-1252
4. Aplicar try/catch por fila para tolerancia a errores
5. Para calendario GTFS: prioridad a calendar_dates sobre calendar

## Pitfalls

- **Ficheros grandes** (>15 MB descomprimidos) pueden tardar varios segundos — el parsing ocurre en el hilo principal
- **stop_times masivo** — limitar a 100.000 registros maximo
- **Encoding corrupto** — detectar caracteres U+FFFD y fallback a Windows-1252
- **calendar_dates sin calendar.txt** — algunos feeds usan solo calendar_dates, hay que soportarlo
