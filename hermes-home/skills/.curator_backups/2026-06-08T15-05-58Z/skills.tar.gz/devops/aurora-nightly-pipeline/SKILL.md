---
name: aurora-nightly-pipeline
version: "1.0.0"
category: devops
description: Pipeline de mejora continua nocturna automatica con lint, build, test y deploy. Basado en Ntizar Aurora v5.1.
tags: [devops, aurora, nightly, pipeline]

---

# Aurora Nightly Pipeline — Mejora Continua Nocturna

## Resumen

Pipeline de mejora continua nocturna automatica con lint, build, test y deploy. Basado en Ntizar Aurora v5.1 Constellation design system.

## Cuando Usar

- Quieres mejora continua automatica de un proyecto frontend
- Necesitas lint, build, test y deploy automaticos cada noche
- Buscas detectar regressiones antes de que lleguen a produccion
- Quieres un pipeline que funcione sin intervencion humana

## Pasos

### 1. Estructura de Jobs Nocturnos

```yaml
name: Nightly Pipeline
on:
  schedule:
    - cron: '0 3 * * *'
  workflow_dispatch:

jobs:
  lint:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 20
      - run: npm ci && npm run lint:fix
      - uses: stefanzweifel/git-auto-commit-action@v5
        with:
          commit_message: "chore: auto-fix lint"

  build:
    runs-on: ubuntu-latest
    needs: lint
    steps:
      - uses: actions/checkout@v4
      - run: npm ci && npm run build

  test:
    runs-on: ubuntu-latest
    needs: build
    steps:
      - uses: actions/checkout@v4
      - run: npm ci && npm test

  deploy:
    runs-on: ubuntu-latest
    needs: test
    if: github.ref == 'refs/heads/master'
    steps:
      - uses: actions/checkout@v4
      - run: npm ci && npm run build
      - uses: peaceiris/actions-gh-pages@v3
        with:
          github_token: ${{ secrets.GITHUB_TOKEN }}
          publish_dir: ./dist
```

### 2. Flujo

```
Cron 3:00 AM UTC
  → lint (detectar + auto-fix)
  → build (verificar compila)
  → test (suite completa)
  → deploy (solo master)
```

## Pitfalls

- Auto-commits pueden crear bucles — usar `if: github.event_name == 'schedule'`
- Deploy automatico solo en master
- Verificar tests no flaky antes de activar deploy automatico

## Archivos de Referencia

- Ntizar-Aurora: https://github.com/Ntizar/Ntizar-Aurora
- CDN: https://cdn.jsdelivr.net/gh/Ntizar/Ntizar-Aurora@master/
- v5.1 Constellation
