---
name: aurora-nightly
description: "Mejora continua nocturna del sistema de diseño Ntizar Aurora — cada noche: investigación web → análisis gap → mejora CSS focalizada → commit → reaprendizaje. Bucle infinito de perfección."
version: 1.0.0
author: Koldo
tags: [aurora, css, design-system, nightly, continuous-improvement, liquid-glass]
---

# Aurora Nightly — Mejora Continua Nocturna

Sistema de mejora continua iterativa del CSS Aurora (Ntizar-Aurora). Cada noche, 4 iteraciones que investigan, analizan, mejoran y committean mejoras al repositorio.

## Cuándo usar

- Crear un pipeline nocturno de mejora continua de diseño
- Iterar sobre un sistema de diseño CSS
- Buscar y aplicar tendencias actuales de diseño web

## Workflow de 4 pasos (4 jobs nocturnos)

### Job #1 — Investigación Web (01:00 UTC)
1. Buscar tendencias actuales de diseño web (CSS, UI, UX)
2. Explorar 3-5 fuentes: CSS-Tricks, Smashing Magazine, Awwwards, CSS Design Gallery, MDN
3. Extraer patrones, técnicas CSS modernas, tendencias de diseño
4. Guardar hallazgos en `nightly/research-log.md`
5. Output: lista de oportunidades de mejora identificadas

**Método de investigación probado (2026-05-31):**
- **RSS-first:** CSS-Tricks RSS (`/feed/`) y MDN Blog RSS (`/blog/rss.xml`) son las fuentes más fiables. Extraen 15+ artículos en un solo fetch.
- **Parseo:** Descargar a archivo con `curl URL -o /tmp/feed.xml`, luego usar `execute_code` para parsear XML con regex. NUNCA usar `curl | python3` (trigger de seguridad).
- **caniuse.com:** JS-rendered, no parseable con curl simple. Usar para datos de soporte solo si la página devuelve HTML estático.
- **Wikipedia API:** Útil para contexto general, pero limitado en contenido CSS específico.
- **Browser tool:** Puede fallar con errores de undici/Node.js. Si falla, fallback a curl.

### Job #2 — Análisis Gap + Mejora #1 (02:00 UTC)
1. Leer `nightly/research-log.md` del job anterior
2. Leer INDEX.md de Aurora para entender el estado actual
3. Identificar los 3 gaps más importantes entre lo encontrado y Aurora
4. Aplicar la mejora #1 al CSS relevante (pack más apropiado)
5. Commit con mensaje descriptivo: "feat: [mejora] — razón"
6. Actualizar `nightly/iteration-log.md` con lo cambiado

### Job #3 — Mejora #2 (03:00 UTC)
1. Leer `nightly/iteration-log.md` para evitar duplicados
2. Aplicar la mejora #2 basada en la investigación
3. Commit descriptivo
4. Actualizar log

### Job #4 — Mejora #3 + Reaprendizaje (04:00 UTC)
1. Aplicar la mejora #3
2. Hacer commit
3. Actualizar memoria/skills con lo aprendido
4. Generar resumen nocturno para Telegram

## Reglas de mejora

- **Una mejora a la vez**: cada job hace UN cambio concreto y verificable
- **NUNCA inventar clases**: solo usar clases documentadas en INDEX.md o tokens CSS
- **NUNCA hardcodear valores**: usar var(--nz-*) tokens
- **Mantener compatibilidad**: cambios aditivos, nunca breaking
- **Pack apropiado**: elige el pack CSS correcto para cada mejora
- **CSS-only**: no añadir JS a menos que sea estrictamente necesario
- **Siempre commit con mensaje descriptivo** en castellano

## Estructura de logs

```
nightly/
  research-log.md    — Hallazgos de investigación web del día
  iteration-log.md   — Historial de mejoras aplicadas (qué, por qué, en qué archivo)
  summary.md         — Resumen nocturno para Telegram
```

## Archivos de referencia

- `INDEX.md` — Mapa completo de todas las clases y tokens de Aurora
- `AGENTS.md` — Reglas no negociables de uso
- `SYSTEM.md` — Arquitectura del sistema
- `references/dialog-open-pattern.md` — Ejemplo aplicado de `:open` pseudo-class para drawer nativo
- `references/css-features-state.md` — Tabla completa de features CSS implementadas vs faltantes + script de gap analysis

## Patrones de mejora CSS (técnicas probadas)

### Tokens CSS para valores hardcodeados en animaciones
Cuando encuentres valores fijos en keyframes o reglas de animación (distancias, escalas, opacidades), reemplazarlos por `var(--nz-*, fallback)` para permitir personalización inline sin CSS override.

Ejemplo aplicado (2026-05-30):
```css
/* Antes */
.nz-reveal--scroll { transform: translateY(1.25rem); }
/* Después */
.nz-reveal--scroll { transform: translateY(var(--nz-reveal-offset, 1.25rem)); }
```
- El keyframe debe usar el MISMO token para consistencia
- Los fallbacks deben ser idénticos al valor anterior (cero impacto visual)
- Documentar nuevos tokens en INDEX.md

### :open pseudo-class para componentes nativos
Usar `details:open` y `dialog:open` en vez de clases `.is-open` gestionadas por JS. Elimina la necesidad de JS para estilizar estados abiertos.

**Patrón aplicado:**
1. Identificar selector actual: `.nz-component.is-open`
2. Añadir `dialog.nz-component:open` como alternativa nativa
3. Mantener fallback `.is-open` para compatibilidad con div-based
4. Documentar en INDEX.md el patrón nativo

Ejemplo aplicado (drawer, 30/05/2026):
```css
/* Antes */
.nz :where(.nz-drawer.is-open) { transform: translateX(0); }
/* Después */
.nz :where(dialog.nz-drawer):open { transform: translateX(0); }
.nz :where(div.nz-drawer.is-open) { transform: translateX(0); }
```

Ver `references/dialog-open-pattern.md` para el ejemplo completo y patrón generalizable.

### Atributos data-nz como extensión del sistema
Si necesitas un nuevo valor visual (ej: esquina recortada), añadirlo como `data-nz-*` attribute en vez de una clase nueva. Ej: `data-nz-shape="cut"` en `ntizar.next.css`.

## ⚠️ Pitfalls

- **No reescribir packs enteros**: siempre patch focalizado
- **No romper compatibilidad**: los cambios deben ser aditivos
- **No duplicar mejoras**: siempre leer iteration-log.md primero
- **No usar inglés en commits ni logs**: TODO en castellano
- **El CSS total es ~170KB**: no intentar cargar todos los archivos en contexto, leer solo el pack relevante
- **No añadir JS a menos que sea estrictamente necesario**: Aurora es CSS-only. Las mejoras deben ser CSS puro o progressive enhancement.

## Análisis de gaps (Job #2)

Cuando el Job #2 necesita identificar los gaps más importantes entre la investigación y el estado actual de Aurora:

1. **Leer todos los packs** con `execute_code` (no cargar en contexto):
   ```python
   all_files = ['ntizar.css', 'ntizar.next.css', 'ntizar.ui.css', 'ntizar.motion.css', 'ntizar.data.css', 'ntizar.forms.css', 'ntizar.patterns.css']
   combined = ''
   for f in all_files:
       with open(f, 'r') as fh:
           combined += fh.read().lower() + '\n'
   ```
2. **Para cada feature de la investigación**, verificar si existe en el texto combinado (`.lower()`).
3. **Clasificar**: `✓` ya implementado / `✗` oportunidad.
4. **Priorizar** por: (a) soporte caniuse >80%, (b) impacto visual, (c) cambio mínimo, (d) aditivo no breaking.
5. **Documentar** el análisis completo en `research-log.md` con la tabla de gaps.

## Investigación web (Job #1) — Provenido (2026-06-01)

- **RSS feeds** son la fuente más fiable para tendencias CSS:
  - CSS-Tricks `/feed/` — 15 artículos recientes, los más ricos en CSS puro
  - MDN Blog `/blog/rss.xml` — artículos de referencia oficial
  - Josh Comeau `/rss.xml` — excelencia en animación CSS
  - Smashing Magazine `/feed/` — útil pero más UX que CSS puro
  - LogRocket `/feed/` — complementario (UX/design engineering)
- **Artículos profundos:** fetch individual con `curl URL -o /tmp/article.html` y parsear `<article>` con `execute_code` (regex `r'<article[^>]*>(.*?)</article>'`)
- **caniuse.com** es JS-rendered — no parseable con curl simple, usar solo para verificación rápida
- **Wikipedia API** útil para contexto general, limitado en CSS específico
- **Browser tool** puede fallar con errores de undici/Node.js — fallback a curl
- **NUNCA usar `curl | python3`** — trigger de seguridad. Descargar a archivo y usar `execute_code`
- **Smashing Magazine bloquea curl** — devuelve ~110 bytes (cloudflare). Si el feed RSS funciona pero los artículos no, es normal.
- **Google Design (design.google/feed/)** — no disponible actualmente
- **Sitios de referencia visual:** Stripe.com, Linear.app, Vercel.com, Awwwards.com (usar browser tool si disponible, o buscar artículos sobre ellos en los RSS)

## Creación del pipeline (4 cron jobs)

Cuando se crea desde cero, se crean 4 jobs con `cronjob action=create`:

```
Job #1: "0 1 * * *" — Investigación web
Job #2: "0 2 * * *" — Mejora CSS #1 (repeat: 2)
Job #3: "0 3 * * *" — Mejora CSS #2 (repeat: 2)
Job #4: "0 4 * * *" — Mejora CSS #3 + Reaprendizaje (repeat: 2)
```

Cada job debe tener:
- `deliver: origin` (entrega resumen a Telegram)
- `skills: ["aurora-nightly"]` (carga la skill)
- `model: qwen3.6` vía `provider: custom` (NaN — NUNCA openrouter, no hay API key configurada)
- `repeat: 2` en jobs #2-#4 (se ejecuta cada noche)
