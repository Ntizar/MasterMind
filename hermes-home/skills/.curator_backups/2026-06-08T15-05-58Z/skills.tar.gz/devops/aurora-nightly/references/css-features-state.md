# CSS Features — Estado en Aurora (2026-06-01)

## Features implementadas en Aurora

| Feature | Pack | Notas |
|---|---|---|
| View Transitions API | core | `view-transition-name` |
| View Timeline | `ntizar.motion.css` | `animation-timeline: view()` |
| Scroll Timeline | `ntizar.motion.css` | `animation-timeline: scroll()` |
| :has() | core | Pseudo-clase padre |
| Container queries | `ntizar.next.css` | `@container` |
| OKLCH color | `ntizar.next.css` | `oklch()`, `oklab()` |
| :open pseudo-class | core | `details:open`, `dialog:open` |
| @layer | core | Cascade layers |
| backdrop-filter | `ntizar.next.css` | Glassmorphism |
| mix-blend-mode | core | Mezcla de colores |
| color-mix() | `ntizar.next.css` | Mezcla de colores nativa |
| color-contrast() | `ntizar.next.css` | Contraste accesible |
| forced-color-adjust | core | Windows High Contrast |
| prefers-reduced-motion | core | Accesibilidad movimiento |
| content-visibility | core | Rendimiento renderizado |
| text-wrap | core | `text-wrap: balance` |
| scroll-driven | `ntizar.motion.css` | Animaciones scroll |

## Features faltantes (priorizadas)

| Feature | Pack objetivo | Soporte | Prioridad |
|---|---|---|---|
| corner-shape | `ntizar.next.css` | Chrome 138+ | **MUY ALTA** |
| sibling-index() | `ntizar.motion.css` | Chrome 138+ | Media-Alta |
| text-reveal (letter-spacing) | `ntizar.motion.css` | Universal | Media |
| ::checkmark | `ntizar.forms.css` | Chrome 138+ | Media |
| field-sizing | `ntizar.forms.css` | Chrome 131+ | Bajo-Medio |
| @starting-style | core | Chrome 111+ | Media |
| line-clamp | core | Universal | Media |
| overflow: clip | core | Universal | Baja |
| scrollbar-gutter | core | Universal | Baja |
| shape() | core | Chrome 131+ | Baja |
| inset() | core | Universal | Baja |
| border-shape | core | Chrome 138+ | Baja |
| overscroll-behavior | core | Universal | Baja |
| clip-path | core | Universal | Baja |
| position-anchor | `ntizar.next.css` | Chrome 123+ | Baja |
| anchor-name | `ntizar.next.css` | Chrome 123+ | Baja |

## Patrón de gap analysis

Para futuros jobs, usar este script en `execute_code`:

```python
import os

all_files = [
    '/root/workspace/Ntizar-Aurora/ntizar.css',
    '/root/workspace/Ntizar-Aurora/ntizar.next.css',
    '/root/workspace/Ntizar-Aurora/ntizar.ui.css',
    '/root/workspace/Ntizar-Aurora/ntizar.motion.css',
    '/root/workspace/Ntizar-Aurora/ntizar.data.css',
    '/root/workspace/Ntizar-Aurora/ntizar.forms.css',
    '/root/workspace/Ntizar-Aurora/ntizar.patterns.css',
]

combined = ''
for f in all_files:
    if os.path.exists(f):
        with open(f, 'r') as fh:
            combined += fh.read().lower() + '\n'

features = {
    'view-transition': 'View Transitions API',
    'view-timeline': 'View Timeline',
    'scroll-timeline': 'Scroll Timeline',
    'animation-timeline': 'Animation Timeline',
    '@scope': '@scope rule',
    'has(': ':has() pseudo-class',
    'container-type': 'Container queries',
    'position-anchor': 'Position anchor',
    'anchor-name': 'Anchor name',
    'corner-shape': 'corner-shape property',
    'sibling-index': 'sibling-index() function',
    'color-mix': 'color-mix() function',
    'oklch': 'OKLCH color space',
    ':open': ':open pseudo-class',
    '@layer': '@layer cascade layers',
    '@starting-style': '@starting-style',
    'overflow-clip': 'overflow: clip',
    'shape()': 'shape() function',
    'clip-path': 'clip-path',
    'backdrop-filter': 'backdrop-filter',
    'mix-blend-mode': 'mix-blend-mode',
    'line-clamp': 'line-clamp',
    'inset()': 'inset() image function',
    'color-contrast': 'color-contrast() function',
    'border-shape': 'border-shape',
    'forced-color-adjust': 'forced-color-adjust',
    'prefers-reduced-motion': 'prefers-reduced-motion',
    'content-visibility': 'content-visibility',
    'scrollbar-gutter': 'scrollbar-gutter',
    'field-sizing': 'field-sizing',
    'text-wrap': 'text-wrap',
    'scroll-driven': 'scroll-driven',
    'overscroll-behavior': 'overscroll-behavior',
}

for key, label in features.items():
    found = key.lower() in combined
    status = "✓" if found else "✗"
    print(f"  {status} {label}: {'present' if found else 'MISSING'}")
```
