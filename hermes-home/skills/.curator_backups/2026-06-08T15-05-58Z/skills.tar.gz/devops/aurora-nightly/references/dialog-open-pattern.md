# Ejemplo aplicado: :open pseudo-class para drawer nativo

## Contexto

Iteración #2 del pipeline aurora-nightly (30/05/2026). La mejora consistió en añadir soporte nativo `<dialog>` al componente drawer de Aurora, eliminando la dependencia de `.is-open` gestionada por JS.

## Cambio aplicado

**Archivo:** `ntizar.ui.css`

```css
/* Antes (solo .is-open) */
.nz :where(.nz-drawer.is-open) { transform: translateX(0); }

/* Después (dual path) */
.nz :where(dialog.nz-drawer):open { transform: translateX(0); }
.nz :where(div.nz-drawer.is-open) { transform: translateX(0); }
```

## HTML resultante

```html
<!-- Nativo, sin JS para abrir/cerrar -->
<dialog class="nz-drawer">
  <div class="nz-drawer__panel">...</div>
</dialog>

<!-- Fallback div-based (mantiene compatibilidad) -->
<div class="nz-drawer is-open">
  <div class="nz-drawer__panel">...</div>
</div>
```

## Patrón generalizable

La misma técnica aplica a cualquier componente que use `.is-open`:
1. Identificar el selector actual: `.nz-component.is-open`
2. Añadir `dialog.nz-component:open` como alternativa nativa
3. Mantener el fallback `.is-open` para compatibilidad
4. Documentar en INDEX.md el patrón nativo

## Referencia

- `:open` pseudo-class: Baseline en todos los navegadores (Safari 26.5+)
- CSS-Tricks "What's !important #11" (May 2026)
