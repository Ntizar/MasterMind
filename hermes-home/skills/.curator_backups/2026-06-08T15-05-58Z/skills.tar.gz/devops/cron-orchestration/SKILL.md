---
name: cron-orchestration
description: Patrón para orquestar múltiples cron jobs con un plan maestro compartido — crear MEGA-PLAN.md como fuente de verdad, spawn crons espaciados en el tiempo, cada uno autocontenido referenciando el plan.
tags: [devops, cronjob, orchestration]
---

# Cron Job Orchestration — Multi-Sesión con Plan Maestro

## Trigger

Cuando el usuario pide generar un proyecto grande que requiere múltiples sesiones/entregas (ej. curso de 10 sesiones, serie de informes, batch de archivos), usar este patrón.

## Pasos

1. **Crear MEGA-PLAN.md** en el directorio de trabajo
   - Estructura general del proyecto
   - Diseño visual unificado (paleta, CDN, estilo)
   - Estructura de cada capítulo/archivo
   - Tono por etapa/tipo
   - Contenido detallado por sesión
   - Requisitos técnicos
   - Checklist de calidad
   - Estructura de archivos

2. **Crear archivo principal** (INDEX.html, README, etc.) con navegación entre entregas

3. **Crear cron jobs** con:
   - `deliver: origin` (entregar al chat actual)
   - Schedule espaciado (cada 12h o 24h para no saturar)
   - `repeat: once` (ejecutar una sola vez)
   - Cada cron con prompt autocontenido que referencie el MEGA-PLAN.md
   - Nombre descriptivo: `NombreProyecto SNN — Descripción`

4. **Verificar que los crons se crearon** con `cronjob action=list`

## Reglas

- El MEGA-PLAN.md es la fuente de verdad: TODOS los crons lo referencian
- Cada cron debe ser autocontenido (no depende del contexto del chat)
- Espaciar crons para evitar saturación de tokens
- Incluir en cada cron prompt: leer MEGA-PLAN.md primero, luego generar
- Límite de líneas por archivo (ej. 2000 líneas HTML) para evitar truncamiento
- Incluir footer de atribución en cada archivo

## Pitfalls

- NO crear crons en bucle infinito (`repeat: forever`) para proyectos de una sola vez
- NO usar `openrouter` como provider en crons de Koldo (401 error) — usar `qwen3.6` vía `custom`
- NO olvidar que los crons corren en sesión aislada: el prompt debe ser completamente autocontenido
- Si el MEGA-PLAN cambia después de crear crons, actualizar los prompts de los crons afectados
- **Schedule format IMPORTANTE:** El campo `schedule` REQUIERE formato ISO timestamp para one-shots: `2026-06-09T08:00:00`. El formato `once at 2026-06-09 08:00` NO funciona y da error de validación. Para recurring usar cron expression: `0 8 * * *`

## Ejemplo de estructura

```
S01 → 2026-06-09T06:00:00
S02 → 2026-06-09T18:00:00
S03 → 2026-06-10T06:00:00
...
S11 → Auditoría final (lee todos los archivos generados)
```
