---
name: inventario-apis-procesamiento
description: "Procedimiento para procesar el catálogo de 10.498+ APIs de API-mega-list en un inventario local estructurado por categorías. Incluye lectura de estado.json, análisis de progreso por categoría, y generación de resúmenes diarios."
version: "1.0.0"
tags: [inventario, apis, pipeline, resumen, cron]
---

# Inventario de APIs — Procesamiento

## Cuándo usar

- Se ejecuta el cron diario de procesamiento de inventario de APIs
- Necesitas generar un resumen del estado del inventario
- Quieres verificar el progreso de procesamiento por categoría
- Revisas el historial de commits del repo de inventario

## Estructura del Inventario

```
/tmp/inventario-apis/
  estado.json              # Metadata: total, procesadas, categorias, api_procesadas
  README.md                # Descripción del proyecto
  .git/                    # Git repo con historial de procesamiento
  agentes-ia/              # Categoría: APIs de agentes IA (689/697 procesadas)
  ia/                      # Categoría: Inteligencia Artificial (79/1208 procesadas)
  automatizacion/          # Categoría: Automatización (0/4825)
  clima-y-medio-ambiente/  # Categoría: Clima y Medio Ambiente
  ecommerce/               # Categoría: Comercio Electrónico
  empleo/                  # Categoría: Empleo
  finanzas/                # Categoría: Finanzas y Criptomonedas
  generacion-lead/         # Categoría: Generación de Leads
  herramientas-desarrollador/
  herramientas-seo/
  inmobiliarias/
  integraciones/
  negocios/
  noticias/
  otras/
  redes-sociales/
  servidores-mcp/
  viajes/
```

## Archivos Clave

### estado.json

JSON con la estructura:
```json
{
  "version": "1.0",
  "creado": "2026-05-26",
  "fuente": "https://github.com/cporter202/API-mega-list",
  "total_estimado": 10498,
  "procesadas": 753,
  "categorias": {
    "categoria-id": {
      "nombre": "Nombre Legible",
      "total": 1234,
      "procesadas": 56,
      "ultima_actualizacion": "2026-06-01 21:55"
    }
  },
  "api_procesadas": ["Nombre API 1", "Nombre API 2", ...]
}
```

### Git History

Cada procesamiento genera un commit `Procesamiento de APIs — actualización automática`.

Para revisar actividad reciente:
```bash
cd /tmp/inventario-apis
git log --since="2026-06-01" --oneline | wc -l   # commits hoy
git diff HEAD~N HEAD --stat                        # cambios en N commits
git diff HEAD~N HEAD --name-only -- '*.json' | wc -l  # nuevos JSONs
```

## Resumen Diario — Formato

Al generar un resumen diario, incluir:

1. **Total APIs catalogadas** — `estado.json` → `procesadas` y `api_procesadas.length`
2. **Progreso global** — `procesadas / total_estimado * 100`
3. **Actividad del día** — contar commits del día en git
4. **Estado por categoría** — iterar `categorias` del estado.json
5. **Categorías con datos reales** — contar directorios con subdirectorios JSON

## Progreso Actual (2026-06-01)

- Total APIs en fuente: 10,498
- APIs procesadas: 753 (7.2%)
- Categorías activas: 2 de 18
  - Agentes IA: 689/697 (98.9%) ✅ casi completa
  - IA: 79/1,208 (6.5%) 🔄 en progreso
- Categorías sin procesar: 16
- Commits hoy: ~42 (cada ~30 min)

## Categorías Pendientes por Volumen

| Categoría | Total | Estado |
|-----------|-------|--------|
| Automatización | 4,825 | ⬜ Sin tocar |
| Generación de Leads | 3,452 | ⬜ Sin tocar |
| Redes Sociales | 3,268 | ⬜ Sin tocar |
| Herramientas Dev | 2,652 | ⬜ Sin tocar |
| Comercio Electrónico | 2,440 | ⬜ Sin tocar |

## Pitfalls

- **estado.json truncado**: si el archivo es muy grande, usar offset/limit para leer por partes
- **Conteo inconsistente**: `api_procesadas.length` puede diferir de `procesadas` si hay duplicados o actualizaciones parciales
- **Directorios vacíos**: no todos los directorios de categoría tienen archivos JSON aún — verificar con `ls`
- **Git log en cron**: usar rangos de fecha ISO para evitar problemas de zona horaria
- **Push falla con token enmascarado**: si `GITHUB_TOKEN` está vacío o enmascarado (`***`), el push a GitHub falla. Los datos se guardan localmente en `/tmp/inventario-apis` pero el commit no se sube. Verificar token con `echo "${GITHUB_TOKEN:0:10}"` antes de intentar push. Si el token en `.env` es literalmente `***`, no hay credenciales válidas.
- **Cron no carga `.env`**: el script `procesar-apis.py` lee `GITHUB_TOKEN` con `os.environ.get()` — el archivo `/hermes-home/.env` NO se carga automáticamente. Si el push falla, hacer manualmente: `source /hermes-home/.env && git remote set-url origin "https://${GITHUB_TOKEN}@github.com/Ntizar/inventario-apis.git" && git push`.
- **Divergencia de ramas con otro cron**: si otro cron procesa el mismo repo simultáneamente, las ramas divergen. No hacer `git pull --rebase` (genera conflictos masivos). En su lugar: `git fetch origin && git checkout -B main origin/main` para sincronizar local con remote. Las APIs locales duplicadas se pierden pero ya están en el remote.
- **Token válido pero push rechazado**: verificar permisos con `curl -s -H "Authorization: token $TOKEN" https://api.github.com/repos/Ntizar/inventario-apis | grep push`. Si el token funciona en API pero falla en git push, puede ser un problema de credential store vs URL embebida.
