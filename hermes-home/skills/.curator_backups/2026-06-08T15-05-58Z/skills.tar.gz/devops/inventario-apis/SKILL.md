---
name: inventario-apis
description: "Leer y resumir el inventario de APIs procesado en /tmp/inventario-apis/. Incluye parsing de estado.json, resumen por categorías, progreso global, y actividad reciente."
version: 1.0.0
author: Hermes Agent
tags: [inventario, apis, resumen, cron, devops]
---

# Inventario de APIs — Lectura y Resumen

Procedimiento para leer y generar resúmenes del inventario de APIs almacenado en `/tmp/inventario-apis/`.

## Estructura del directorio

```
/tmp/inventario-apis/
├── estado.json          # Archivo maestro con métricas globales
├── README.md            # Resumen por categorías (markdown)
├── automatizacion/      # Subdirectorios por categoría
│   ├── README.md
│   └── <api-name>/      # Una carpeta por API
├── ia/
├── agentes-ia/
└── ...
```

## Lectura de estado.json

`estado.json` es la fuente de verdad. Estructura:

```json
{
  "version": "1.0",
  "creado": "2026-05-26",
  "fuente": "https://github.com/cporter202/API-mega-list",
  "total_estimado": 10498,
  "procesadas": 1744,
  "categorias": {
    "automatizacion": {
      "nombre": "Automatización",
      "total": 4825,
      "procesadas": 259,
      "ultima_actualizacion": "2026-06-07 21:40"
    }
  },
  "api_procesadas": ["API 1", "API 2", ...]
}
```

### Pasos para leer

1. **Leer estado.json** con `json.load()` en Python
2. **Extraer métricas globales**: `total_estimado`, `procesadas`, `categorias`
3. **Calcular progreso**: `procesadas / total_estimado * 100`
4. **Clasificar categorías**:
   - `>90%` → completadas
   - `50-90%` → en avance
   - `1-50%` → en progreso
   - `0%` → pendientes
5. **Filtrar actividad reciente**: buscar `ultima_actualizacion` que coincida con la fecha objetivo

### Código de referencia

Ver `references/lectura-estado.py` para el script completo de parsing.

## Formato de resumen

El resumen debe incluir:
- **Progreso global**: X/Y APIs, Z% avance
- **Categorías completadas** (>90%): con emoji 🏆
- **Categorías en avance** (50-90%): con emoji 🟢
- **Categorías en progreso** (1-50%): con emoji 🟡
- **Categorías pendientes** (0%): lista con conteo total
- **Actividad del día**: categorías actualizadas hoy
- **Historial**: últimas 3 actualizaciones

## Pitfalls

- **README.md puede tener texto corrupto**: el conteo de APIs en el README puede incluir texto formateado que no son APIs reales. Siempre confiar en `estado.json` como fuente de verdad.
- **Categorías con total=0**: algunas categorías (Finanzas, Clima) tienen `total: 0` y deben omitirse en los cálculos.
- **Directorios vs archivos**: cada API es un subdirectorio en la carpeta de categoría, no un archivo JSON. No buscar JSONs dentro de las carpetas de categoría.
- **Estado no se actualiza automáticamente**: si se procesaron APIs nuevas en el directorio pero `estado.json` no se actualizó, las métricas estarán desfasadas.

## Referencias

- `references/lectura-estado.py` — Script Python de parsing completo de `estado.json` con clasificación por categorías y detección de actividad reciente.
- `references/api-mega-list.md` — Referencia del catálogo API-mega-list: origen, categorías, proceso de procesamiento.
