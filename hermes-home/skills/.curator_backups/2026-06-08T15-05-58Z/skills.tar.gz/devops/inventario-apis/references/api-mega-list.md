# API-mega-list — Referencia

## Origen

- **Repo:** https://github.com/cporter202/API-mega-list
- **Licencia:** catálogo público de APIs organizadas por categoría
- **Total estimado:** ~10.498 APIs

## Categorías principales

| Categoría | APIs | Progreso |
|---|---|---|
| Automatización | 4.825 | 5,4% |
| Redes Sociales | 3.268 | 0% |
| Generación de Leads | 3.452 | 0% |
| Herramientas Dev | 2.652 | 0% |
| Ecommerce | 2.440 | 0% |
| Inteligencia Artificial | 1.208 | 68,3% |
| Otras APIs | 1.297 | 0% |
| Agentes IA | 697 | 98,9% |
| Inmobiliarias | 851 | 0% |
| Integraciones | 890 | 0% |
| Empleo | 848 | 0% |
| Herramientas SEO | 710 | 0% |
| Noticias | 590 | 0% |
| Viajes | 397 | 0% |
| Servidores MCP | 131 | 0% |
| Negocios | 2 | 0% |

## Proceso de procesamiento

Cada API se procesa generando:
1. Un subdirectorio con nombre slugificado en la categoría correspondiente
2. Un README.md con tabla de APIs procesadas
3. Actualización de estado.json con métricas

## Estado del inventario

Archivo maestro: `/tmp/inventario-apis/estado.json`
- `total_estimado`: APIs totales en el catálogo
- `procesadas`: APIs procesadas en total
- `categorias`: diccionario con métricas por categoría
- `api_procesadas`: lista plana de nombres de APIs procesadas
