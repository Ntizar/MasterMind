---
name: koldo-setup
description: "Configura y mantiene el sistema personal de agentes Koldo — sincronización de repositorio GitHub, instalación de skills, configuración de SOUL.md y auto-configuración de cron para el segundo cerebro de Ntizar."
version: 1.3.0
author: Ntizar + Hermes Agent
tags: [koldo, setup, github, skills, soul, nan, identity]
---

# Koldo Setup

Procedures for setting up and maintaining the Koldo personal agent system — a private GitHub repo that serves as the agent's second brain (skills, notes, memory, config, scripts).

## Cuándo usar

- Se configura un nuevo entorno de Hermes Agent para Ntizar
- Necesitas sincronizar skills desde el repositorio Koldo al sistema local
- El SOUL.md se corrompió o truncó y necesita recuperación
- Se necesitan configurar cron jobs de sincronización automática

## Cuándo NO usar

- Configurar un usuario diferente de Ntizar → el repo y las rutas son específicas
- Solo necesitas instalar un skill individual → usa `skill_manage(action='create')` directamente
- El sistema ya está configurado y funcionando → no reconfigurar sin necesidad

## Identity

El nombre del agente es **Koldo**, no "Hermes Agent". Hermes es el framework subyacente; Koldo es el nombre que David (Ntizar) le dio a su sistema de agente personal. Al presentarte o referirte a ti mismo, usa "Koldo".

- **Framework:** Hermes Agent (el motor subyacente)
- **Nombre:** Koldo (el agente personal)
- **Usuario:** David Antizar (Ntizar)

Esta es la identidad preferida del usuario. Siempre presentarse como Koldo.

## Setup

### 1. Install GitHub CLI

```bash
curl -fsSL https://cli.github.com/packages/githubcli-archive-keyring.gpg | dd of=/usr/share/keyrings/githubcli-archive-keyring.gpg 2>/dev/null
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/githubcli-archive-keyring.gpg] https://cli.github.com/packages stable main" | tee /etc/apt/sources.list.d/github-cli.list > /dev/null
apt-get update -qq && apt-get install -y -qq gh
```

### 2. Authenticate with GitHub

```bash
# Read token from .env
token=$(grep GITHUB_TOKEN /hermes-home/.env 2>/dev/null | cut -d= -f2-)

# ⚠️ PITFALL: gh auth login fails when GITHUB_TOKEN env var is set
# Clear it first:
GITHUB_TOKEN="" echo "$token" | gh auth login --with-token
```

### 3. Clone the repo

```bash
cd /root/workspace
git clone https://github.com/Ntizar/koldo.git
```

### 4. Configure Hermes to use it as a skills source

In `/hermes-home/config.yaml`:

```yaml
skills:
  external_dirs:
    - /root/workspace/Koldo/koldo
```

Then `/reset` (new session) for Hermes to detect the new skills.

### 5. Copy skills to local directory

```bash
mkdir -p /hermes-home/skills/koldo
cp /root/workspace/Koldo/koldo/*.md /hermes-home/skills/koldo/
```

Create a `SKILL.md` umbrella in `/hermes-home/skills/koldo/SKILL.md` listing the individual skills.

### 6. Actualizar SOUL.md

Configurar `/hermes-home/SOUL.md` con: identidad del agente, reglas, sistema de conocimiento en 3 capas, estructura del repo, modelo de subagentes, stack actual y lista de skills.

### 7. Set up auto-sync cron

Create a cron job that runs daily:

```bash
# Schedule: 0 9 * * * (daily at 09:00 UTC)
# Prompt:
cd /root/workspace/Koldo && git pull origin main
cp /root/workspace/Koldo/koldo/*.md /hermes-home/skills/koldo/
gh auth status || re-authenticate from /hermes-home/.env
```

See `scripts/koldo-autoconfig.sh` for the ready-to-use sync script (includes SOUL.md size guard).
See `scripts/restore-soul.sh` for SOUL.md sync check and recovery.
See `scripts/backup-hermes-memory.sh` for manual backup of memory to repo.

## Estructura del Repositorio

```
Koldo/
├── README.md                          ← Visión general del sistema
├── ARCHITECTURE.md                    ← Documentación técnica (capas, flujos)
├── koldo/                             ← Skills CORE del sistema
│   ├── SKILL.md                       ← Índice umbrella de skills propios
│   ├── SOUL.md                        ← Plantilla de identidad
│   └── (skills .md individuales)
├── learning/                          ← Sistema de aprendizaje autónomo
│   ├── MEGA-PLAN-LECTURA-ESCRITURA.md ← Plan maestro del curso
│   ├── README.md                      ← Cómo funciona el sistema
│   ├── sesiones/                      ← HTMLs de lecciones generadas
│   └── indices/                       ← Índices temáticos (autores, vocab...)
├── improvement/                       ← Mejora continua de Koldo
│   ├── skills-desapavechadas.md       ← Skills que no uso y debería
│   ├── skills-nuevas-proyecto.md      ← Skills que debería crear
│   └── INDEX.md                       ← Índice unificado de mejoras
├── skills/                            ← Skills de referencia (hub externo)
│   └── INDEX.md                       ← Catálogo completo
├── config/
│   └── skill-priority.json            ← Prioridad HIGH/MEDIUM/LOW
├── scripts/                           ← Automatizaciones
│   ├── koldo-autoconfig.sh            ← Autoconfiguración diaria
│   ├── generate-skill-index.sh        ← Generador de índice
│   └── (otros scripts)
├── memory/                            ← Respaldo de memoria
├── notes/                             ← Notas de sesiones
│   └── _template.md                   ← Template con frontmatter YAML
└── .deploy/                           ← Deploy configs (nginx, Docker)
```

## Reglas

1. **Nunca borrar del repositorio** — solo crear nuevos archivos o modificar archivos que creaste
2. **Formato de notas:** `YYYY-MM-DD-titulo.md` en `notes/`
3. **Skills:** cada skill tiene su propio archivo en `koldo/`
4. **Commit tras aprender:** lecciones importantes → commit al repositorio
5. **Sin secretos en notas/commits/chat**
6. **SOUL.md es la fuente de verdad** para la identidad del agente — mantenerlo sincronizado con el repo

## Pitfalls

- **Hermes no detecta external_dirs mid-session** — reiniciar sesión (`/reset`) tras cambiar `config.yaml`
- **SKILL.md requerido** — archivos `.md` individuales no se detectan sin un `SKILL.md` umbrella
- **gh auth falla con GITHUB_TOKEN set** — limpiar primero: `GITHUB_TOKEN="" echo "$token" | gh auth login --with-token`
- **SOUL.md debe actualizarse** — instalar skills no es suficiente; la identidad debe estar en SOUL.md
- **SOUL.md puede truncarse** — puede reducirse a ~48 bytes. **Detección:** `wc -c /hermes-home/SOUL.md` — si <1000, está corrupto. **Recuperación:** `cp /root/workspace/Koldo/koldo/SOUL.md /hermes-home/SOUL.md`
- **Hermes memory drifts from repo** — el cron NO hace backup de memoria. Usar `scripts/backup-hermes-memory.sh` manualmente.
- **SOUL.md size guard (ACTUALIZADO 2026-06-03)** — `koldo-autoconfig.sh` usa lógica de 3 vías: (1) si local < 1000 bytes → SIEMPRE restaurar desde repo (truncado), (2) si repo > local → restaurar, (3) si local > repo y local > 1000 → subir al repo. El guard anterior solo comparaba `repo > local`, lo que permitía corrupción parcial silenciosa.
- **Config drift silencioso** — `tts.edge.voice` y `display.language` pueden perderse tras updates de Hermes o reconfiguraciones. **Verificar periódicamente:** `grep "voice:" /hermes-home/config.yaml | head -1` debe mostrar `es-ES-AlvaroNeural`, y `grep "language:" /hermes-home/config.yaml` debe mostrar `es` en sección display. Si están en inglés → el agente responde en inglés y TTS suena raro.
- **Hermes path quirk** — algunos deployments usan `/hermes-home/` en vez de `~/.hermes/`. Verificar `$HERMES_HOME`.
- **No crear skills con write_file manual** — usar `skill_manage(action='create')`.
- **Duplicate workspace clones** — solo una copia de Koldo repo en `/root/workspace/Koldo/`.
- **gh CLI no instalado** — `git push` funciona sin `gh`.
- **Debian Node.js stub crashes** — `/usr/bin/node` es un stub que crashea. Usar nvm o shebang directo al path nvm.

## Patrón de Sincronización Bidireccional

El sistema Koldo usa **sincronización bidireccional** entre el repositorio GitHub y Hermes Agent:

1. **GitHub → Hermes**: `cd /root/workspace/Koldo && git pull origin main` luego `cp -n /root/workspace/Koldo/koldo/*.md /hermes-home/skills/koldo/`
2. **Hermes → GitHub**: Copiar `MEMORY.md` y `USER.md` a `memory/hermes-memory.md` y `memory/hermes-user.md`, luego `git add -A && git commit -m "auto: backup de memoria $(date +%Y-%m-%d)" && git push origin main`

El script `scripts/koldo-autoconfig.sh` automatiza ambas direcciones. Ejecutar manualmente o vía cron para sync diario.

### Pitfalls de sincronización

- **Skills ya sincronizados**: Antes de copiar, ejecuta `diff <(ls koldo/ | sort) <(ls /hermes-home/skills/koldo/ | sort)` — si está vacío, no se necesita copia.
- **Nombres de archivos de backup**: Usar siempre `memory/hermes-memory.md` y `memory/hermes-user.md` en el repo.
- **Mensajes redirect de git son benignos**: Si `git push` muestra redirect, el push aún funciona. No tratar como error.
- **URL canónica en minúsculas**: El repo migró a `https://github.com/Ntizar/koldo.git` (minúsculas). Usar esta forma para evitar warnings.
- **Copia segura con `cp -n`**: Siempre usar `cp -n` para preservar archivos exclusivos de Hermes.

## Mantenimiento

### Sincronizar skills del repositorio

```bash
cd /root/workspace/Koldo && git pull origin main
cp -n /root/workspace/Koldo/koldo/*.md /hermes-home/skills/koldo/
```

### Auto-prune de sesiones

Desde 2026-06-03:
```yaml
# En /hermes-home/config.yaml
sessions:
  auto_prune: true           # ← ACTIVADO
  retention_days: 60         # ← 60 días (antes 90)
  vacuum_after_prune: true
  min_interval_hours: 24
```

Esto limpia automáticamente sesiones >60 días. La DB de state.db se mantiene bajo control sin intervención manual.

### Regenerar índice de notas

```bash
cd /root/workspace/Koldo && python3 scripts/generate-notes-index.py
```

Esto escanea `notes/` y genera `notes/INDEX.md` con tabla agrupada por categorías. Ejecutar tras crear/modificar notas.

### Verificar skill priority

Los 144 skills están categorizados en `config/skill-priority.json`. Cuando añadas skills nuevos, añadirlos a la categoría correspondiente (HIGH/MEDIUM/LOW).

### Añadir un nuevo skill al repositorio

1. Crear archivo en `koldo/<name>.md` con frontmatter correcto
2. Actualizar `koldo/SKILL.md` umbrella
3. Copiar a `/hermes-home/skills/koldo/`
4. Commit y push
5. Actualizar SOUL.md si es un skill core

### Actualizar SOUL.md

Cada vez que cambie el stack (nuevo modelo, dashboard, API), actualizar SOUL.md. Es el manual operativo del agente.

## Patrón de Sub-Skill (refs adjuntos)

Para skills que importan de repos de GitHub, usar el patrón de **sub-skill con refs**:

```
skills/<nombre>/
├── SKILL.md              ← Resumen corto (~1-2KB) — carga siempre
└── references/
    ├── patron-clave.md   ← Patrón de código o procedimiento extraído del repo
    ├── otro-patron.md    ← Otro patrón clave
    └── ...
```

**Cómo funciona:**
1. SKILL.md contiene resumen + tabla de refs disponibles
2. Los refs se cargan bajo demanda: `skill_view(name='nombre', file_path='references/patron.md')`
3. El contenido viene del repo real
4. Costo: ~1-2KB siempre + ~3KB por ref

**Cuándo usar:** Skills de repos externos con valor educativo, cuando el skill necesita código real, cuando el repo tiene patrones repetibles.
**No usar para:** Skills propios del sistema Koldo, skills con un solo procedimiento, skills de menos de 1000 estrellas.
**Ejemplo creado:** `google-eng-practices` con 3 refs.

## SOUL.md Architecture (ACTUALIZADO 2026-06-01)

SOUL.md y `agente-principal.md` son **complementarios, no duplicados**:
## Arquitectura SOUL.md (ACTUALIZADO 2026-06-01)

SOUL.md y `agente-principal.md` son **complementarios, no duplicados**:

- `SOUL.md` (~3-4 KB): Identidad breve, reglas, stack, pitfalls críticos
- `agente-principal.md` (~3 KB): Manual operativo detallado (repo structure, subagentes, seguridad)

**Reglas:**
- SOUL.md: sin tablas (Telegram no las soporta), usar listas `**clave** → valor`
- SOUL.md: sección `## Identidad` breve (nombre, usuario, TTS, CSS, idioma)
- SOUL.md: sección `## Capas de conocimiento` como lista, no tabla
- SOUL.md: pitfall section con los errores más críticos del sistema
- `agente-principal.md`: extiende con detalles operativos
- **NUNCA duplicar el mismo contenido en ambos archivos**

## Patrón de Autoauditoría

Cuando el usuario pida "autoauditar" o cuestione si el sistema funciona bien, ejecutar este check rápido:

### 1. SOUL.md integrity
```bash
wc -c /hermes-home/SOUL.md  # Debe ser >1000 bytes
diff /hermes-home/SOUL.md /root/workspace/Koldo/koldo/SOUL.md  # Deben ser idénticos
```

### 2. Config correctness
```bash
grep "voice:" /hermes-home/config.yaml | head -1   # Debe ser es-ES-AlvaroNeural
grep "language:" /hermes-home/config.yaml           # display section debe ser 'es'
grep "provider:" /hermes-home/config.yaml | head -1 # Debe ser 'edge' para TTS
```

### 3. Skills health
```bash
# Skills sin tags (debería ser 0)
find /hermes-home/skills -name "SKILL.md" -exec sh -c 'if head -1 "$1" | grep -q "^---"; then if ! head -10 "$1" | grep -q "^tags:"; then echo "NO TAGS: $1"; fi; fi' _ {} \;

# Skills sin versión (debería ser 0)
find /hermes-home/skills -name "SKILL.md" -exec sh -c 'if head -1 "$1" | grep -q "^---"; then if ! head -10 "$1" | grep -q "^version:"; then echo "NO VERSION: $1"; fi; fi' _ {} \;
```

### 4. Memory pressure
```bash
# Si memoria >85%, Considerar podar entradas obsoletas
wc -c /hermes-home/SOUL.md
```

### 5. Cron jobs status
```bash
hermes cron list  # Todos deben mostrar last_status: ok
```

**Frecuencia:** Cuando el usuario lo pida o cada ~2 semanas como mantenimiento preventivo.

## Patrón de Auditoría de Librería

Cuando el sistema de skills necesita mantenimiento, cargar el skill `skill-audit-pattern` para ejecutar la auditoría sistemática. El script `scripts/audit-skills.py` hace un análisis completo.

**Objetivo:** 10/10 checks pasados = 5 estrellas.

### Filtro para Crear Nuevos Skills

1. **¿Es un patrón reutilizable?** → Si es específico de un proyecto → NO es skill
2. **¿Aporta algo nuevo?** → Si solo documenta un CLI tool → NO es skill
3. **¿Es compacto?** → Si es >5KB → usar refs pattern
4. **¿Tiene tags?** → Mínimo 3 tags descriptivos
5. **¿Es necesario?** → Si ya existe un skill similar → fusionar

### Criterios de Calidad

- ✅ **Patrón reutilizable** — Patrón, procedimiento o metodología aplicable a múltiples proyectos
- ❌ **Project README** — Documenta un proyecto específico → va a `notes/`
- ❌ **CLI Wrapper** — Solo documenta cómo usar una CLI → no aporta valor
- ⚠️ **Fragmentado** — Cubre un tema pero podría fusionarse

## Skill Learning Script (`skill-learning.sh`)

Script automatizado que instala skills del hub uno a uno, avanzando un índice en `.skill-learning-state.json`.

### Estado del script

- **State file:** `/hermes-home/skills/.skill-learning-state.json`
- **Log:** `/hermes-home/skills/skill-learning.log`
- **Script:** `/hermes-home/scripts/skill-learning.sh`
- **Total skills en cola:** 118 (lista en `PRIORITY_SKILLS` del script)

### Pitfalls críticos del script

- **State desincronizado con disco:** El estado JSON puede marcar un skill como "learned" pero el archivo NO existe en `/hermes-home/skills/`. **Siempre verificar con `find`:**
  ```bash
  for skill in duckduckgo-search searxng-search scrapling code-wiki; do
    find /hermes-home/skills -name "SKILL.md" -path "*$skill*" -not -path "*/quarantine/*"
  done
  ```
- **Quarantine = instalación fallida:** Si un skill aparece en `.hub/quarantine/`, la instalación falló y el script seguirá reintentando infinitamente. **Solución:** eliminar de quarantine y dejar que el script lo intente de nuevo, o saltar a la siguiente skill.
- **Timeout en `hermes skills install`:** El script tiene timeout de 120s. Si la instalación tarda más, el script falla pero el state no avanza (el skill se reintentará en la siguiente ejecución). **Verificar:** `grep "Installing" /hermes-home/skills/skill-learning.log | tail -5`
- **Reintentos infinitos en skills de quarantine:** Si un skill está en quarantine, el script lo reintentará cada tick sin fin. **Solución manual:**
  ```bash
  # Verificar si está en quarantine
  ls /hermes-home/skills/.hub/quarantine/
  # Si es un skill problemático, eliminarlo y avanzar el índice manualmente
  rm -rf /hermes-home/skills/.hub/quarantine/<skill-name>
  python3 -c "
  import json
  with open('/hermes-home/skills/.skill-learning-state.json') as f:
      data = json.load(f)
  data['current_index'] = data['current_index'] + 1
  with open('/hermes-home/skills/.skill-learning-state.json', 'w') as f:
      json.dump(data, f, indent=2)
  "
  ```
- **Índice se reinicia:** Si el state file se pierde o corrompe, el script vuelve al índice 0 e instala los mismos skills de nuevo. **Backup:** el log es la fuente de verdad del progreso real.

### Verificación rápida de progreso

```bash
# Estado actual
cat /hermes-home/skills/.skill-learning-state.json

# Últimos 5 intentos
tail -10 /hermes-home/skills/skill-learning.log

# Skills realmente instalados vs state
python3 -c "
import json, os, subprocess
with open('/hermes-home/skills/.skill-learning-state.json') as f:
    state = json.load(f)
installed = []
for skill in state.get('learned', []):
    result = subprocess.run(['find', '/hermes-home/skills', '-name', 'SKILL.md', '-path', f'*{skill}*'], capture_output=True, text=True)
    if result.stdout and 'quarantine' not in result.stdout:
        installed.append(skill)
    else:
        print(f'MARKED BUT NOT INSTALLED: {skill}')
print(f'Installed: {len(installed)}/{len(state.get(\"learned\", []))}')
"
```

### Troubleshooting completo

Para troubleshooting detallado (state desincronizado, quarantine infinito, timeouts), ver `references/skill-learning-troubleshooting.md`.

## Notas

- Este skill consolida el skill `koldo-system` de devops. Usar este para todas las tareas de setup/mantenimiento de Koldo.
- El cron job `cf21b05773aa` (koldo-autoconfig) se ejecuta diariamente a las 09:00 UTC.
- SOUL.md en `/hermes-home/SOUL.md` es la fuente de identidad del agente — mantenerlo siempre sincronizado con el repo.
- Para monitoreo y observabilidad después del setup, ver el skill `agent-observability` → `references/nan-portfolio-pattern.md`.
- Dashboard de control completo: `/root/workspace/koldo_control_center.py` — dashboard completo con kanban, gráficos, acciones y auth. Ejecutar con `python3 koldo_control_center.py [puerto]`.
- Para portfolio de apps en NaN Spaces, ver `agent-observability` → `references/nan-portfolio-pattern.md`.
- Para integración Apple Calendar / iCloud CalDAV, ver skill `caldav-calendar`.
- **2026-06-01:** Auditoría completa de librería. 205 → 150 skills (eliminados 55: 12 project-readmes + 25 CLI wrappers + 18 top-level project-readmes + 2 others). 100% skills con tags. 27 categorías. Skill `skill-audit-pattern` creado + cron `skill-maintenance` (83139c479ddb) para auditorías mensuales.
- **2026-06-03:** Autoauditoría del sistema. Fix: SOUL.md restaurado (3591 bytes), TTS voice corregido a `es-ES-AlvaroNeural`, display.language a `es`, 7 skills sin tags/versión arreglados, `koldo-autoconfig.sh` mejorado con guard robusto (MIN_SOUL_SIZE=1000, lógica 3 vías). Añadido patrón de autoauditoría al skill. Pitfall de config drift documentado.
- **2026-06-06:** Script `skill-learning.sh` — documentados pitfalls de state desincronizado, quarantine infinito y timeout. Verificar progreso real con `find` vs state JSON. Añadido `references/skill-learning-troubleshooting.md` con troubleshooting completo.
- **2026-06-06:** `rest-graphql-debug` atascado en quarantine desde ~12:15 UTC. El script reintentará infinitamente. Solución: eliminar de quarantine y avanzar índice manualmente.
