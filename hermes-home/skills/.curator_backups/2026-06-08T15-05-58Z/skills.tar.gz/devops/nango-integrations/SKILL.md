---
name: nango-integrations
version: "1.0.0"
description: >
  Plataforma Nango para construir integraciones con 800+ APIs. Maneja
  OAuth, API keys, token refresh, proxy autenticado y generación de
  integraciones con IA. Incluye patrón de skills para construir integraciones.
license: MIT
tags: [devops, nango, API, integrations]

---

# Nango — Integraciones con 800+ APIs

## Cuándo usar

- Construyes integraciones de producto con APIs externas (OAuth, API keys)
- Necesitas manejar auth multi-tenant con token refresh automático
- Quieres un proxy autenticado para hacer requests a APIs de tus usuarios
- Precisas sincronización de datos programada entre tu app y APIs externas

## Cuándo NO usar

- Solo necesitas hacer una llamada puntual a una API → un simple fetch es suficiente
- Tu app no necesita integraciones con terceros → no hay valor añadido
- Necesitas controlar completamente la infraestructura de auth → usa tu propio sistema OAuth

## Visión General

[Nango](https://github.com/NangoHQ/nango) (9.4k⭐) es una plataforma open-source para construir integraciones de producto con IA. Soporta 800+ APIs con auth manejado, proxy autenticado y escalado automático.

## Tres Primitivas

### 1. Auth
- OAuth2, API Keys, Basic Auth gestionados
- Token refresh automático
- White-label auth flow embebible
- Multi-tenant connection management

```typescript
// Embed auth in your frontend
nango.openConnectUI({ onEvent: (event) => { /* handle completion */ } });

// Get connected user data
const connections = await nango.listConnections();
const data = await nango.sync({ connectionId: 'xxx', sync: 'getUser' });
```

### 2. Proxy
- Requests autenticados a través del proxy de Nango
- Resuelve provider, inyecta credenciales
- Maneja retries y rate limits automáticamente

```typescript
import { Nango } from '@nangohq/node';
const nango = new Nango({ secretKey: '<NANGO_SECRET_KEY>' });
const response = await nango.proxy({
  provider: 'slack',
  endpoint: '/api/users.list',
  parameters: { limit: 10 }
});
```

### 3. Sync
- Sincronización de datos programada
- Webhooks para cambios en tiempo real
- Soporte para incrementales y full syncs

## Estructura de Skills

Nango usa un sistema de skills en `.agents/skills/`:

```
.agents/skills/
├── agent-builder-skill/     # Crear/mejorar subagentes
├── building-and-verifying/  # Build y verificar integraciones
├── creating-database-migrations/
├── creating-integration-docs/  # Docs para nuevas integraciones
├── creating-skills-skill/
├── running-and-testing-locally/
├── running-tests/
└── ui-visual-debugging/
```

## Patrones Clave

### Skill de Integración
Cada skill tiene:
- `SKILL.md` — Descripción, cuándo usar, comandos
- `EXAMPLES.md` — Ejemplos prácticos
- `references/` — Documentación de referencia
- `templates/` — Templates reutilizables

### Creating Integration Docs
```
docs/api-integrations/[slug].mdx          # Quickstart
docs/api-integrations/[slug]/how-to-register...  # OAuth setup
docs/api-integrations/[slug]/connect.mdx  # Custom UI
snippets/generated/[slug]/PreBuiltUseCases.mdx  # Sync snippets
docs/docs.json                            # Navigation
packages/providers/providers.yaml         # Provider config
```

## Proveedores Soportados
800+ proveedores incluyendo: Slack, Salesforce, HubSpot, Stripe, GitHub, Jira, Notion, Google Workspace, Microsoft 365, y muchos más.

## Referencias
- [Nango GitHub](https://github.com/NangoHQ/nango)
- [Nango Docs](https://nango.dev/docs/)
- [800+ APIs](https://nango.dev/docs/integrations/overview/)
