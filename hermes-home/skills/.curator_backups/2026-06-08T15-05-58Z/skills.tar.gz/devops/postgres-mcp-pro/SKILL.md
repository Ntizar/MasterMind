---
name: postgres-mcp-pro
version: "1.0.0"
description: >
  PostgreSQL MCP Pro — servidor MCP con index tuning, explain plans, 
  health checks y ejecución segura de SQL. Para agentes IA que necesitan 
  acceso configurable read/write a PostgreSQL con análisis de rendimiento.
license: MIT
tags: [devops, postgres, MCP, database]

---

# PostgreSQL MCP Pro

## Cuándo usar

- Un agente IA necesita acceder a una base de datos PostgreSQL para explorar el schema
- Necesitas diagnóstico de rendimiento: health checks, index tuning, query plans
- Quieres ejecución segura de SQL con validación y límites para agentes IA
- Necesitas recomendaciones de índices basadas en la carga real de queries

## Cuándo NO usar

- No necesitas acceso programático desde agentes IA → usa psql o DBeaver directamente
- La BD es MySQL, SQLite o MongoDB → este skill es específico de PostgreSQL
- Necesitas escritura en producción sin supervisión → usa modo `restricted` (solo lectura)

## Visión General

[postgres-mcp](https://github.com/crystaldba/postgres-mcp) (2.8k⭐) es un servidor MCP open-source que proporciona acceso configurable read/write a PostgreSQL con análisis de rendimiento para agentes IA.

## Características

### 🔍 Database Health
- Análisis de index health
- Connection utilization
- Buffer cache analysis
- Vacuum health
- Sequence limits
- Replication lag
- Y más métricas de salud

### ⚡ Index Tuning
- Explora miles de índices posibles
- Algoritmos de optimización industriales
- Encuentra la mejor solución para tu workload
- Simula impacto de índices hipotéticos

### 📈 Query Plans
- Valida y optimiza EXPLAIN plans
- Simula impacto de índices hipotéticos
- Detecta problemas de performance

### 🧠 Schema Intelligence
- Generación SQL context-aware
- Comprensión profunda del schema
- Recomendaciones de diseño

### 🔒 Safe SQL Execution
- Ejecución segura con límites
- Validación de queries antes de ejecutar
- Rollback automático en errores

## Estructura

```
src/postgres_mcp/
├── server.py          # MCP server principal
├── tools/             # Herramientas MCP
├── database/          # Conexión y queries
├── health/            # Health checks
├── tuning/            # Index tuning
└── config/            # Configuración
```

## Instalación

```bash
pip install postgres-mcp
```

## Configuración

```yaml
# postgres_mcp config
database:
  host: localhost
  port: 5432
  name: mydb
  user: postgres
  password: secret

security:
  read_only: false    # true = solo lectura
  max_rows: 10000     # límite de filas
  allowed_tables:     # tabla blanca
    - users
    - orders
```

## Herramientas MCP

| Herramienta | Descripción |
|-------------|-------------|
| `db_health` | Análisis completo de salud |
| `index_recommendations` | Recomendaciones de índices |
| `explain_plan` | Análisis de plan de ejecución |
| `safe_query` | Ejecución segura de SQL |
| `schema_inspect` | Exploración de schema |
| `vacuum_status` | Estado de vacuum |
| `connection_stats` | Estadísticas de conexión |

## Uso con Agentes

```python
# Ejemplo: Un agente puede preguntar
# "¿Por qué es lenta esta query?"
# → El servidor MCP ejecuta EXPLAIN ANALYZE
# → Sugiere índices
# → Propone query reescrita
```

## Referencias
- [postgres-mcp GitHub](https://github.com/crystaldba/postgres-mcp)
- [MCP Specification](https://modelcontextprotocol.io/)
