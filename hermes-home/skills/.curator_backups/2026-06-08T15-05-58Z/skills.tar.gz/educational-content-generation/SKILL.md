---
name: educational-content-generation
version: "1.0.0"
description: "Generar contenido educativo HTML interactivo (lecciones, ejercicios, simulaciones) mediante cron jobs — patrones para evitar fallos de token, generación de HTML auto-contenido y orquestación de sesiones."
tags: [educación, html, cron-jobs, contenido-interactivo, vanilla-js]
---

# Educational Content Generation — Generación de contenido educativo HTML

Generar lecciones educativas interactivas como HTML auto-contenido, ejecutado vía cron jobs programados.

## Trigger del usuario

- Usuario pide crear contenido educativo (lecciones, ejercicios, simulaciones)
- Usuario quiere un curso completo con sesiones programadas en el tiempo

## Pasos

1. **Definir el plan maestro** → crear un `MEGA-PLAN.md` con estructura de todas las sesiones, contenido por sesión, diseño visual unificado, tono por nivel
2. **Generar primera sesión directamente** → NO delegar en cron para la primera sesión (sirve como referencia de patrón)
3. **Crear jobs cron para sesiones restantes** → uno por sesión, programados con `once at <timestamp>`
4. **Verificar que cada job genera el HTML correcto** → el HTML debe ser auto-contenido, máximo 500 líneas

## Reglas CRÍTICAS para cron jobs

### 1. Límite de líneas

**TODO HTML generado debe ser máximo 500 líneas.** Si el contenido lo requiere, sacrifica interactividad o ejemplos, pero NUNCA excedas 500 líneas.

**Por qué:** Los cron jobs tienen límite de tokens. Un HTML de 800+ líneas hace que el agente se quede sin tokens antes de terminar el `write_file`, resultando en un archivo corrupto o vacío.

### 2. Escribir todo de una vez

**NUNCA usar `execute_code` ni `write_file` recursivo.** Escribe TODO el HTML de una sola vez con un solo `write_file`.

**Por qué:** Múltiples writes o `execute_code` con `patch`/`write_file` en bucle causan timeouts y archivos parciales.

### 3. Prompt del cron job

El prompt debe incluir SIEMPRE:
- Referencia al MEGA-PLAN.md para contenido
- Patrón de diseño de referencia (ej: "usa el mismo patrón que s01-1primaria.html")
- Instrucciones explícitas de límite de 500 líneas
- Prohibición de `execute_code` y `write_file` recursivo
- Ruta exacta del archivo de salida
- Footer con atribución

### 4. Patrón de diseño

Cada sesión debe seguir el mismo patrón visual:
- CDN Aurora para estilos (`@ntizar/aurora@latest`)
- Body con `class="nz"`
- Sidebar de navegación entre capítulos
- Capítulos con canvas interactivos
- Modo oscuro/claro
- Footer: "Hecho con ❤️ por David Antizar"

## Estructura de cada sesión

```
HTML auto-contenido
├── Head (meta, CDN Aurora, estilos inline)
├── Header con título y toggle dark mode
├── Sidebar de navegación
├── Main con capítulos:
│   ├── Teoría (caja azul)
│   ├── Ejemplos resueltos (caja naranja)
│   ├── Canvas interactivo
│   └── Mini ejercicios con feedback
└── Footer
```

## Pitfalls

- **HTMLs >500 líneas:** el agente del cron se queda sin tokens y el write_file se queda sin contenido → archivo vacío o corrupto
- **execute_code con write_file:** causa timeouts y archivos parciales → usar write_file directo
- **Prompt sin instrucciones de límite:** el agente genera HTMLs enormes → fallo garantizado
- **Confundir job_id:** los jobs "once" se autodestruyen tras ejecutarse → si un job falla, hay que crear uno nuevo con el ID correcto
- **Sesión previa ya generada:** si un job anterior generó un HTML parcial (S02 en la práctica), verificar el archivo antes de crear nuevo job

## Referencias

- `references/math-course-pipeline.md` — caso de estudio: curso completo de matemáticas con 11 sesiones programadas
