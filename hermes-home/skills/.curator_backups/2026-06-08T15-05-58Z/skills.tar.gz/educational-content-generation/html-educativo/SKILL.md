---
name: html-educativo
version: "1.0.0"
description: "Generar contenido educativo HTML interactivo — patrones de estructura, tamaño, diseño y publicación."
tags: [html, educativo, interactivo, primaria, contenido]
---

# HTML Educativo — Generación de contenido interactivo

## Qué hace

Generar páginas HTML educativas autocontenidas con teoría, ejemplos, interactividad y ejercicios.

## Trigger del usuario

- Pedir generar una "sesión", "lección", "tema" educativo en HTML
- "Generar Math S04" o cualquier referencia a contenido educativo
- "Dividir en subtemas" cuando un tema es demasiado grande

## Pasos

1. **Planificar división:** si el tema tiene >3 subtemas o el contenido estimado supera ~15KB, dividir en sub-sesiones independientes (una por subtema)
2. **Estructura de cada sub-sesión:**
   - Header con título de sesión y barra de progreso
   - Sección intro con objetivos
   - 1-3 capítulos con: teoría → ejemplos → interactividad → ejercicios
   - Resumen final con checklist
   - Navegación anterior/siguiente
   - Footer con atribución
3. **Generar con execute_code + write_file:** NUNCA usar write_file directo del agent (pierde el argumento content cuando el prompt es largo). Usar `execute_code` con `hermes_tools.write_file()` o Python `open()`
4. **Verificar tamaño:** cada archivo debe ser <20KB. Si no, dividir más.

## Estructura visual

- **Paleta:** azul `#2563eb` + naranja `#f97316` + verde `#10b981` + rojo `#ef4444`
- **Fondo:** blanco (modo claro SOLO para contenido educativo)
- **Tipografía:** Inter, system-ui, sans-serif
- **Cajas didácticas:** borde izquierdo de 4px con color según tipo (teoría=azul, ejemplo=naranja, problema=verde, error=rojo, idea=púrpura)
- **Interactividad:** sliders, botones, quizzes con feedback inmediato
- **Atribución:** "Hecho con ❤️ por David Antizar" en el footer

## Tono por nivel

| Nivel | Tono |
|-------|------|
| 1º-2º Primaria | Lenguaje muy simple, frases cortas, emojis, apoyo visual |
| 3º-4º Primaria | Lenguaje claro, símbolos graduales, problemas cotidianos |
| 5º-6º Primaria | Más formal pero cercano, datos reales |
| ESO/Bachiller | Riguroso, aplicaciones reales |

## Pitfalls

- **write_file directo falla:** si el contenido >15KB, el agent pierde el argumento `content`. SIEMPRE usar `execute_code` con Python `open()` para escribir archivos grandes.
- **Cron jobs tienen límite de contexto:** no generar contenido grande vía cron. Generar directamente o dividir en sub-sesiones pequeñas.
- **NUNCA modo oscuro en contenido educativo:** el usuario especifica modo claro SOLO para contenido educativo.
- **NUNCA mencionar Koldo/Aurora en contenido educativo:** solo atribuir a David Antizar.
- **Cada sub-sesión debe ser autónoma:** no depender de archivos externos, todo inline (CSS + JS).
- **NUNCA PARAR a mitad de generación:** si algo falla, reintentar y generar lo que falta. El usuario quiere TODO completo, no medias tareas. "Esto no puede pasar" = señal de frustración crítica.
- **execute_code puede fallar por stream stall:** si el tool call se interrumpe, reintentar con el mismo código Python, no cambiar de enfoque.
- **Template Python `.format()`:** usar `{{` y `}}` para escape de llaves literales en CSS/JS dentro del template.
- **Naming conflict entre cursos:** cuando generas un bloque de sesiones (S04-1 a S04-10), los archivos existentes con el prefijo mismo pueden ser de un curso diferente (ej: 4º Primaria vs Estadística para Ingeniería). SIEMPRE verificar qué archivos existen antes de generar. Si hay conflicto, usar nombres desambiguadores (ej: `s04-1-estadistica-conceptos-basicos.html` en vez de `s04-1.html`).
- **Batch de 10-20 sesiones:** cuando el usuario pide "generar todo", generar todas las sesiones de golpe con execute_code + Python write_file, una tras otra. No parar entre sesiones. El usuario quiere TODO completo.
- **Python `'''` en HTML:** si el HTML contiene `'''` (ej: notación de derivada tercera `s'''(t)`), Python interpreta las triple comillas como cierre de string y da SyntaxError. SOLUCIÓN: usar `r"""..."""` (raw triple double-quote) en vez de `"""..."""`.
- **Carácter `→` (flecha Unicode):** dentro de strings Python normales, el carácter `→` (U+2192) puede causar SyntaxError en ciertos contextos. SOLUCIÓN: usar `r"""..."""` o reemplazar `→` por `-->` en el HTML.
- **Unicode en HTML educativo:** el HTML educativo debe usar caracteres Unicode normales (emojis, flechas, etc.) SIN problema porque el archivo se escribe como bytes. El problema es SOLO cuando el contenido HTML con caracteres especiales está DENTRO de un string Python. Si usas `r"""`, los caracteres Unicode se preservan.
- **Batch masivo (20+ archivos):** cuando generas un volumen grande de sesiones (Bachiller 10 + Carrera 10 = 20), hacerlo en execute_code separados (uno por batch de 2-3 archivos) es más fiable que un script único gigante. Cada execute_code es un proceso independiente sin límite de contexto compartido.
- **Función make_html reutilizable:** definir una función `make_html()` en cada script que reciba título, capítulos (lista de strings HTML), navegación y resumen, y construya el HTML completo. Esto reduce duplicación de CSS/JS/header/footer. Usar concatenación de strings (`+`) en vez de f-strings para evitar conflictos con llaves del template.
- **CSS como variable raw:** `CSS = r"""..."""` como variable global en cada script es fiable. No intentar compartirla entre scripts (cada execute_code es independiente).

## Archivos de soporte

- `references/cron-failures.md` — lecciones sobre fallos de cron jobs por tamaño de contenido
- `references/estructura-matematicas.md` — plan maestro del curso de matemáticas: 10 volúmenes, estado de cada uno, bloque de Estadística para Ingeniería
- `references/template-html-educativo.md` — CSS completo, JS base, componentes interactivos reutilizables
- `references/matematicas-completo.md` — Estado completo del curso de matemáticas: 86 archivos, Primaria+ESO+Bachiller+Carrera+Estadistica Ingenieria