# Estructura del Curso de Matemáticas — Estado Final (2026-06-08)

## Resumen

94 archivos HTML, 11 volúmenes, 100% completados, 0 links rotos.

## Volúmenes

| # | Volumen | Archivos | Sesiones | Estado |
|---|---------|----------|----------|--------|
| 01 | 1º Primaria | s01-1primaria.html + 10 sesiones | 11 | ✅ |
| 02 | 2º Primaria | s02-2primaria.html + 7 sesiones | 8 | ✅ |
| 03 | 3º Primaria | s03-3primaria.html + 6 sesiones | 7 | ✅ |
| 04 | 4º Primaria | s04-4primaria.html + 8 sesiones | 8 | ✅ |
| 04+ | Estadística e Ing. | s04-estadistica-inicio.html + 10 sesiones | 10 | ✅ |
| 05 | 5º Primaria | s05-5primaria.html + 6 sesiones | 6 | ✅ |
| 06 | 6º Primaria | s06-6primaria.html + 6 sesiones | 6 | ✅ |
| 07 | 1º ESO | s07-1eso.html + 4 sesiones | 4 | ✅ |
| 08 | 2º-3º ESO | s08-2-3eso.html + 5 sesiones | 5 | ✅ |
| 09 | Bachiller | s09-bachiller.html + 10 sesiones | 10 | ✅ |
| 10 | 1º Carrera | s10-1carrera.html + 10 sesiones | 10 | ✅ |

## Archivos de resumen (10)

Cada uno lista las sesiones de su volumen con navegación Anterior/Siguiente:
- s01-1primaria.html, s02-2primaria.html, s03-3primaria.html
- s04-4primaria.html, s04-estadistica-inicio.html, s05-5primaria.html
- s06-6primaria.html, s07-1eso.html, s08-2-3eso.html
- s09-bachiller.html, s10-1carrera.html

## INDEX.html

- Links hardcodeados (sin JS)
- 11 tarjetas con colores por nivel
- Progreso: 11/11 completados
- Footer con atribución a David Antizar

## GitHub Pages

https://ntizar.github.io/DeSumarIntegrar/
Repo: github.com/Ntizar/DeSumarIntegrar
