# Matematicas - Estado Completo (2026-06-08)

## Volumen: Primaria (S01-S06)
- **S01:** 10 sesiones (contar, sumar, figuras, medidas)
- **S02:** 10 sesiones (sumas/restas llevadas, multiplicacion, dinero)
- **S03:** 10 sesiones (mult 2 cifras, division, fracciones, perimetro)
- **S04:** 10 sesiones (fracciones equivalentes, decimales, areas, problemas)
- **S05:** 10 sesiones (decimales, areas, porcentajes, tiempo)
- **S06:** 10 sesiones (operaciones grandes, fracciones, proporcionalidad, algebra)
- Total: 60 archivos HTML

## Volumen: ESO (S07-S08)
- **ESO1:** 5 sesiones (numeros enteros, proporcion, algebra, estadistica)
- **ESO2:** 5 sesiones (ecuaciones 1 grado, Tales, funciones, circunferencia, probabilidad)
- Total: 10 archivos HTML

## Volumen: Bachiller (S09) — COMPLETO
- **S09-1:** s09-1-bachiller-limites.html (13,930 B)
- **S09-2:** s09-2-bachiller-continuidad-derivadas.html (12,728 B)
- **S09-3:** s09-3-bachiller-reglas-derivacion.html (12,292 B)
- **S09-4:** s09-4-bachiller-aplicaciones-derivadas.html (9,951 B)
- **S09-5:** s09-5-bachiller-integrales-indefinidas.html (8,457 B)
- **S09-6:** s09-6-bachiller-integrales-definidas.html (8,340 B)
- **S09-7:** s09-7-bachiller-aplicaciones-integrales.html (9,061 B)
- **S09-8:** s09-8-bachiller-probabilidad-avanzada.html (9,912 B)
- **S09-9:** s09-9-bachiller-distribuciones-combinadas.html (8,915 B)
- **S09-10:** s09-10-bachiller-repaso.html (8,811 B)
- Total: 10 archivos, ~103 KB

## Volumen: 1 Carrera (S10) — COMPLETO
- **S10-1:** s10-1-carrera-limites-multivariable.html (7,994 B)
- **S10-2:** s10-2-carrera-derivadas-parciales.html (8,785 B)
- **S10-3:** s10-3-carrera-integrales-multiples.html (8,686 B)
- **S10-4:** s10-4-carrera-edos-primer-orden.html (8,698 B)
- **S10-5:** s10-5-carrera-edos-segundo-orden.html (8,632 B)
- **S10-6:** s10-6-carrera-series-fourier.html (8,861 B)
- **S10-7:** s10-7-carrera-espacios-vectoriales.html (8,376 B)
- **S10-8:** s10-8-carrera-autovalores.html (8,399 B)
- **S10-9:** s10-9-carrera-transformaciones-lineales.html (7,929 B)
- **S10-10:** s10-10-carrera-repaso.html (8,879 B)
- Total: 10 archivos, ~84 KB

## Volumen: Estadistica Ingenieria (S04-Eng)
- **S04-1 a S04-10:** 10 archivos con nombres desambiguados (estadistica-conceptos-basicos, etc.)
- Total: 10 archivos

## Gran Total
- **86 archivos HTML** en /root/workspace/matematicas/
- Todos autocontenidos (CSS + JS inline)
- Todos con quiz interactivo
- Todos con atribucion a David Antizar
