# Template completo HTML Educativo

## Template base (v1.0) — usar con execute_code + Python write_file

### CSS (siempre igual)

```css
:root{--azul:#2563eb;--naranja:#f97316;--verde:#10b981;--rojo:#ef4444;--fondo:#fff;--texto:#1e293b;--gris:#94a3b8;--azul-claro:#eff6ff;--naranja-claro:#fff7ed;--verde-claro:#ecfdf5;--rojo-claro:#fef2f2;--pura-claro:#faf5ff;--pura:#a855f7}
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:Inter,system-ui,-apple-system,sans-serif;background:var(--fondo);color:var(--texto);line-height:1.6}
.header{background:linear-gradient(135deg,var(--azul),#1d4ed8);color:#fff;padding:2rem 1.5rem;text-align:center}
.header h1{font-size:1.8rem;margin-bottom:.5rem}
.header p{opacity:.9;font-size:1rem}
.progress-bar{height:4px;background:rgba(255,255,255,.3);border-radius:2px;margin-top:1rem;overflow:hidden}
.progress-fill{height:100%;background:#fff;border-radius:2px;width:0%;transition:width .3s}
.container{max-width:800px;margin:0 auto;padding:1.5rem}
.chapter{margin-bottom:2.5rem}
.chapter-title{font-size:1.4rem;color:var(--azul);margin-bottom:1rem;padding-bottom:.5rem;border-bottom:2px solid var(--azul-claro)}
.box{padding:1rem 1.2rem;border-radius:8px;margin:1rem 0;border-left:4px solid}
.box-teoria{background:var(--azul-claro);border-color:var(--azul)}
.box-ejemplo{background:var(--naranja-claro);border-color:var(--naranja)}
.box-error{background:var(--rojo-claro);border-color:var(--rojo)}
.box-idea{background:var(--pura-claro);border-color:var(--pura)}
.box strong{display:block;margin-bottom:.3rem}
.interactive{background:#f1f5f9;border-radius:12px;padding:1.5rem;margin:1.5rem 0}
.interactive h3{color:var(--azul);margin-bottom:1rem;font-size:1.1rem}
.interactive button{background:var(--azul);color:#fff;border:none;padding:.5rem 1.2rem;border-radius:6px;cursor:pointer;font-size:.95rem;margin:.3rem}
.interactive button:hover{background:#1d4ed8}
.result{margin-top:.8rem;padding:.8rem;border-radius:6px;font-weight:600;min-height:2rem}
.result.ok{background:var(--verde-claro);color:#065f46}
.result.fail{background:var(--rojo-claro);color:#991b1b}
.exercises{margin:1.5rem 0}
.exercise{background:#f1f5f9;border-radius:8px;padding:1rem;margin:.8rem 0}
.exercise p{font-weight:600;margin-bottom:.5rem}
.nav{display:flex;justify-content:space-between;margin:2rem 0;padding:1rem 0;border-top:1px solid #e2e8f0;border-bottom:1px solid #e2e8f0}
.nav a{color:var(--azul);text-decoration:none;font-weight:600;padding:.5rem 1rem;border-radius:6px}
.nav a:hover{background:var(--azul-claro)}
.nav .disabled{color:var(--gris);cursor:default;pointer-events:none}
.summary{background:var(--azul-claro);border-radius:12px;padding:1.5rem;margin:2rem 0}
.summary h3{color:var(--azul);margin-bottom:.8rem}
.summary ul{list-style:none;padding:0}
.summary li{padding:.3rem 0;padding-left:1.5rem;position:relative}
.summary li::before{content:"✓";color:var(--verde);font-weight:bold;position:absolute;left:0}
.footer{text-align:center;padding:2rem 1rem;color:var(--gris);font-size:.85rem;border-top:1px solid #e2e8f0;margin-top:2rem}
.quiz-options{display:flex;gap:.5rem;justify-content:center;flex-wrap:wrap;margin:1rem 0}
.quiz-btn{padding:.6rem 1.5rem;border-radius:8px;border:2px solid var(--azul);background:#fff;font-size:1.1rem;font-weight:600;cursor:pointer;transition:all .2s}
.quiz-btn:hover{background:var(--azul-claro)}
.quiz-btn.correct{background:var(--verde);color:#fff;border-color:var(--verde)}
.quiz-btn.wrong{background:var(--rojo);color:#fff;border-color:var(--rojo)}
```

### JS base (siempre igual)

```javascript
function checkExercise(btn, correct) {
  const parent = btn.parentElement;
  parent.querySelectorAll('.quiz-btn').forEach(b => {
    b.disabled = true;
    b.style.pointerEvents = 'none';
  });
  if(correct) { btn.classList.add('correct'); }
  else { btn.classList.add('wrong'); }
}

window.onscroll = function() {
  var h = document.documentElement;
  var p = (window.scrollY/(h.scrollHeight-h.clientHeight))*100;
  document.getElementById('progress').style.width = p+'%';
};
```

### Componentes interactivos comunes

1. **Quiz buttons:** `onclick="checkExercise(this, true/false)"`
2. **Sliders:** `<input type="range" oninput="updateFunc()">`
3. **Canvas:** para gráficos de barras, pizzas fraccionadas
4. **SVG dinámico:** para figuras geométricas, fracciones
5. **Botones de selección:** cambiar entre temas/tablas

## Ejemplo de batch generation (2026-06-08)

28 archivos HTML generados en 4 batches con execute_code + Python write_file:
- S01: 11 archivos (contar, sumar, restar, figuras, medidas, patrones)
- S02: 8 archivos (sumas/restas llevadas, multiplicación, tablas, dinero)
- S03: 7 archivos (mult 2 cifras, división, fracciones, perímetro, estadística)
- S04: 1 archivo (fracciones equivalentes — ya existente)
