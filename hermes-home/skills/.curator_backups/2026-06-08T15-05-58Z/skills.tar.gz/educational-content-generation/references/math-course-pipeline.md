# Caso de Estudio: Curso de Matemáticas con Cron Jobs

## Contexto

David Antizar quiere un curso completo de matemáticas (1º Primaria → 1º Carrera) con 11 sesiones, cada una con HTML interactivo. Las sesiones se generan mediante cron jobs programados en el tiempo.

## Problema encontrado

El primer cron job (Math S01) falló con:
- **Error:** `write_file: missing required field 'content'`
- **Causa:** El agente del cron generó un HTML de ~850 líneas (similar a S02 que ya existía), se quedó sin tokens antes de terminar el write_file, y el file-mutation verifier detectó que el archivo no se modificó
- **Síntoma:** "Stream stalled mid tool-call" + "1 file(s) were NOT modified"

## Solución aplicada

1. **S01 generado directamente** (no vía cron) → 696 líneas, HTML auto-contenido con 6 capítulos
2. **Jobs S02-S11 actualizados** con instrucciones explícitas:
   - "máximo 500 líneas"
   - "NO uses execute_code ni write_file recursivo"
   - "Escribe TODO el HTML de una sola vez con write_file"
3. **S02 recreado** con job_id nuevo (el anterior se autodestruyó al fallar parcialmente)

## Patrón de prompts para jobs

Cada job debe tener un prompt con:
- Contexto: "Eres Koldo, agente personal de David Antizar"
- Tarea específica: "generar la SESIÓN XX del curso de matemáticas para [nivel]"
- Reglas CRÍTICAS (límite 500 líneas, no execute_code, write_file directo)
- Referencia al MEGA-PLAN.md
- Patrón de diseño de referencia
- Ruta de salida exacta
- Footer con atribución

## Cronograma

| Sesión | Nivel | Programación |
|--------|-------|-------------|
| S01 | 1º Primaria | Generado directamente |
| S02 | 2º Primaria | 2026-06-08 18:00 UTC |
| S03 | 3º Primaria | 2026-06-09 00:00 UTC |
| S04 | 4º Primaria | 2026-06-09 06:00 UTC |
| S05 | 5º Primaria | 2026-06-09 12:00 UTC |
| S06 | 6º Primaria | 2026-06-09 18:00 UTC |
| S07 | 1º ESO | 2026-06-10 00:00 UTC |
| S08 | 2º-3º ESO | 2026-06-10 06:00 UTC |
| S09 | Bachiller | 2026-06-10 12:00 UTC |
| S10 | 1º Carrera | 2026-06-10 18:00 UTC |
| S11 | Auditoría | 2026-06-11 00:00 UTC |

## Archivos generados

- `/root/workspace/matematicas/s01-1primaria.html` — 696 líneas, 6 capítulos
- `/root/workspace/matematicas/MEGA-PLAN.md` — plan maestro con contenido de todas las sesiones
- `/root/workspace/matematicas/s02-2primaria.html` — existente (parcial, se regenerará)
