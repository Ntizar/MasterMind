---
name: frontend-dashboard-patterns
description: "Patrones completos para dashboards frontend vanilla JS: cliente API robusto, orquestación de carga, error boundaries, tabs con navegación, persistencia, fechas, colores, sparklines, Web Workers y debugging. Todo lo que necesitas para construir dashboards resilientes sin bundler."
version: 1.0.0
author: Hermes Agent
tags: [frontend, dashboard, patterns, vanilla-js, resilience, geodatos, leaflet, choropleth]
---

# Frontend Dashboard Patterns — Colección Completa

Patrones reutilizables para dashboards frontend vanilla JS sin bundler. Inspirados en ESIOS Dashboard y Ntizar Aurora.

## Tabla de Contenidos

1. [Cliente API Robusto](#1-cliente-api-robusto) — reintentos, circuit breaker, timeouts
2. [Orquestación de Carga](#2-orquestación-de-carga) — Promise.allSettled, anti-doble-carga, cache fallback
3. [Error Boundaries](#3-error-boundaries) — overlay global, errores por sección, retry
4. [Tabs con Navegación](#4-tabs-con-navegación) — hash navigation, lazy-loading, deep-linking
5. [Persistencia de Estado](#5-persistencia-de-estado) — localStorage con validación, expiración, corrupción
6. [Manejo de Fechas](#6-manejo-de-fechas) — UTC→local, zonas horarias, DST
7. [Sistema de Colores](#7-sistema-de-colores) — tokens CSS, modo oscuro, variables semánticas
8. [Sparklines con Plotly](#8-sparklines-con-plotly) — mini gráficos inline optimizados
9. [Web Workers + Comlink](#9-web-workers--comlink) — cálculos pesados sin bloquear UI
10. [Debugging Patterns](#10-debugging-patterns) — scope, lifecycle, DOM integrity
11. [Aurora Design System](#11-aurora-design-system) — CSS puro, 11 packs opt-in, namespaced .nz, 5 skins
12. [Geodatos Choropleth](#12-geodatos-choropleth) — Leaflet + Canvas, TopoJSON, lazy loading geodatos
13. [GTFS Browser Parser](#13-gtfs-browser-parser) — parsing GTFS en navegador sin servidor
14. [Three.js 3D Scenes](#14-threejs-3d-scenes) — escenas 3D interactivas con texturas procedurales
15. [ESLint v10 Flat Config](#15-eslint-v10-flat-config) — flat config, globals, ignores
16. [Vite HTML Script Processing](#16-vite-html-script-processing) — IIFEs, post-build, rutas relativas

---

## 1. Cliente API Robusto

Clase `ApiClient` con reintentos exponenciales (backoff + jitter), circuit breaker por endpoint, timeouts por operación, y clasificación de errores HTTP.

**Reglas clave:**
- No reintentar 4xx (excepto 429)
- Circuit breaker: N fallos → abrir circuito T segundos → half-open → cerrar/reabrir
- Timeout por request con AbortController
- Integrar con `Promise.allSettled` para carga paralela tolerante a fallos

**Ver:** `references/api-client-pattern.md` para código completo.

---

## 2. Orquestación de Carga

Clase `DataOrchestrator` para cargar múltiples endpoints en paralelo con:
- Anti-doble-carga (mínimo 3s entre cargas)
- Estados de loading por sección
- Fallback a datos cacheados
- `Promise.allSettled` para tolerancia parcial

**Ver:** `references/orquestacion-carga-pattern.md` para código completo.

---

## 3. Error Boundaries

Patrón de resiliencia:
- Overlay global cuando todo falla (network, 5xx)
- Errores por sección para fallos parciales
- `safeRender()` wrapper para que un error de render no rompa el resto
- Timeout en servidor con `withTimeout()` wrapper
- Clasificación de errores: 404, 502, 503, network, timeout → mensajes distintos

**Ver:** `references/error-boundaries-pattern.md` para código completo.

---

## 4. Tabs con Navegación

Clase `TabController` para:
- Navegación por hash (`#demanda`) con deep-linking
- Lazy-loading de contenido
- Persistencia de última tab en localStorage
- Navegación por teclado (ArrowLeft/ArrowRight)
- Accesibilidad: `role="tab"`, `aria-selected`

**Ver:** `references/tabs-navigation-pattern.md` para código completo.

---

## 5. Persistencia de Estado

Clase `PersistStore` para localStorage con:
- Validación de integridad al leer
- Expiración automática (TTL configurable)
- Control de tamaño (truncar arrays si exceden límite)
- Manejo de `QuotaExceededError`
- Recuperación ante datos corruptos
- Opcional: `HybridStore` con sessionStorage + localStorage

**Ver:** `references/persistence-pattern.md` para código completo.

---

## 6. Manejo de Fechas

Patrones para fechas consistentes:
- **NUNCA usar `new Date('YYYY-MM-DD')`** → se interpreta como UTC
- Usar `new Date(year, month, day)` para fechas locales
- `toLocaleString('es-ES')` para formateo con zona horaria del navegador
- Detección de DST con `Intl.DateTimeFormat().resolvedOptions().timeZone`
- Normalización de inputs de fecha

**Ver:** `references/dates-timezone-pattern.md` para código completo.

---

## 7. Sistema de Colores

Patrón de diseño centralizado:
- Variables CSS semánticas (`--color-success`, `--color-danger`)
- Variables de gráfico fijas (`--color-chart-1`...) para consistencia
- Modo oscuro con `[data-theme="dark"]`
- Toggle con localStorage + `prefers-color-scheme` fallback
- Un solo archivo de configuración → cambios globales en un lugar

**Ver:** `references/color-system-pattern.md` para código completo.

---

## 8. Sparklines con Plotly

Mini gráficos inline optimizados:
- Reducir datos a 50 puntos máx. antes de renderizar
- Sin hover, sin ejes, sin leyenda → rendimiento máximo
- `Plotly.purge()` al destruir para liberar memoria
- Color condicional (verde si sube, rojo si baja)
- Punto final destacado con marker más grande

**Ver:** `references/sparklines-pattern.md` para código completo.

---

## 9. Web Workers + Comlink

Cálculos pesados sin bloquear UI:
- Spatial hashing para ray-casting eficiente
- Precomputación + cache
- `Comlink.transfer()` para arrays grandes (ArrayBuffer)
- `visitToken` vs `Set` para evitar allocation por frame
- Batch calculations para terrazas grandes

**Ver:** `references/web-workers-pattern.md` para código completo.

---

## 10. Debugging Patterns

Patrones de bugs recurrentes en vanilla JS multi-script:
1. **Scope de variables** → `var charts = window.charts = {}`
2. **Tab renderizada antes del fetch lazy** → marcar solo tras fetch exitoso
3. **Esquema de datos incorrecto** → fetch independiente con esquema correcto
4. **Canvas no existe en DOM** → verificar IDs coincidentes
5. **Nombre de función inconsistente** → grep en archivos JS
6. **Botón sin event listener** → verificar que `addEventListener` está vinculado en `DOMContentLoaded` o al final del script

### 🔥 Fallo CRÍTICO: `apiFetch` NO es un fetch genérico

`apiFetch()` en `public/js/api.js` **requiere obligatoriamente un parámetro `fecha`** (segundo argumento). Construye la URL como `${API_BASE}/${endpoint}?fecha=...`.

**Si necesitas llamar un endpoint que NO usa fecha** (ej: `/api/esios/forecast?days=30`), **NUNCA uses `apiFetch()`** → usa `fetch()` directo:

```javascript
// ❌ MALO — apiFetch añade ?fecha= obligatoriamente → 400 error
const data = await apiFetch('/api/esios/forecast?days=30');

// ✅ BUENO — fetch directo
const resp = await fetch('/api/esios/forecast?days=30');
const data = await resp.json();
```

### 🔥 Strings truncados con *** sin cerrar — causa de "se queda cargando"

Cuando una app web se queda en pantalla de loading eternamente, **primero verifica sintaxis JS**:

**Síntoma:** Loading spinner infinito, nada se renderiza, consola vacía o error de sintaxis no visible.

**Causa común:** URLs con `***` como placeholder de API key que les falta la comilla de cierre. El JS ni siquiera se parsea → `DOMContentLoaded` nunca se ejecuta → init() nunca se llama → loading nunca se oculta.

**Detección rápida con `execute_code`:**
```python
with open('src/js/app.js', 'r') as f:
    lines = f.readlines()
for i, line in enumerate(lines, 1):
    stripped = line.strip()
    if 'uri:' in stripped or 'tiles:' in stripped:
        single_quotes = stripped.count("'")
        if single_quotes % 2 != 0:
            print(f"Línea {i}: string sin cerrar ({single_quotes} comillas simples)")
```

**O con `node -c`:**
```bash
node -c src/js/app.js  # Si falla → error de sintaxis
```

**Fix:** Usar concatenación de variables en vez de strings inline:
```javascript
// ❌ MALO — string sin cerrar
uri: 'https://tiles.stadiamaps.com/styles/...?api_key=***\n

// ✅ BUENO — variable ya definida en el archivo
uri: 'https://tiles.stadiamaps.com/styles/...?api_key=' + API_KEY,
```

**Verificación post-fix:** `node -c` debe pasar → `npm run build` debe compilar → servidor debe responder 200.

**Ver:** `references/truncated-js-strings-napmaps.md` para auditoría completa de NapMaps con 12 casos documentados (edificios procedurales, factor de conversión, satélite roto, coordenadas invertidas, etc.).

### 🔥 Fallback data debe ser idéntica al JSON fuente

Cuando un dashboard carga datos de un JSON externo (`fetch('data.json')`) con fallback embebido en el catch, **los datos del fallback deben ser IDÉNTICOS al JSON**. Si no, el usuario ve datos diferentes según la fuente (CORS → fallback, sin CORS → JSON).

```javascript
// ❌ MALO — fallback tiene 2 entradas, JSON tiene 3
.catch(function() {
  var ENTRIES = [ {id: 1}, {id: 2} ];  // ← desactualizado
  render(ENTRIES);
});

// ✅ BUENO — fallback sincronizado con tokens-log.json
.catch(function() {
  var ENTRIES = [ {id: 1}, {id: 2}, {id: 3} ];  // ← idéntico al JSON
  render(ENTRIES);
});
```

**Regla:** Cuando actualices el JSON fuente, actualiza el fallback en el mismo commit.

**Ver:** `references/debugging-patterns.md` para checklist completo.

---

## 11. Aurora Design System

Design System CSS puro sin dependencias, sin build step, namespaced bajo `.nz`. 1 archivo core + 10 packs opt-in. 5 skins de marca. Liquid glass real con OKLCH. CDN público en jsDelivr.

**Repo:** https://github.com/Ntizar/Ntizar-Aurora
**URL:** https://ntizar.github.io/Ntizar-Aurora/

### Quick Start

```html
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/Ntizar/Ntizar-Aurora@latest/ntizar.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/Ntizar/Ntizar-Aurora@latest/ntizar.next.css">

<body class="nz"
      data-nz-theme="light"
      data-nz-skin="aurora"
      data-nz-shape="default"
      data-nz-density="comfortable"
      data-nz-motion="standard"
      data-nz-color-system="oklch">
  ...
</body>
```

### Reglas de Oro

1. **Todo lo público vive bajo `.nz`** — no hay clases globales sueltas
2. **Todos los valores son tokens `--nz-*`** — nunca hardcodes un hex o un `16px`
3. **Sin `!important`** fuera de utilidades
4. **BEM** para componentes: `.nz-card__body--featured`
5. **Si no aparece en `gallery.html`, no existe** — la galería es la única fuente de verdad

### Uso con IA Agents (crucial para ahorrar tokens)

**NO** pegar el CSS en el prompt (170 KB ≈ 50.000 tokens).

**SÍ** hacer:
1. Dar al agent solo `AGENTS.md` + `INDEX.md` (~20 KB / ~5.000 tokens)
2. Linkar el CSS vía CDN en el HTML generado
3. Decir al agent: "Generate HTML only. The CSS is already linked. Use Aurora classes from INDEX.md."

### Pitfalls

- **No JS shipped** — modal/tabs/drawer/dropdown/toast son styled, no behaved
- **WCAG AAA** aplica solo a la skin `contrast`, no a todas
- **No tree-shaking** — una página con 5 componentes carga el pack completo

---

## 15. ESLint v10 Flat Config

ESLint v10+ ignora completamente `.eslintrc.json` (legacy config). Necesita `eslint.config.js` (flat config).

**Causa raíz de errores:** Los 7 errores `no-undef` (`Plotly`, `Vue`, `C`, `SEF`) aparecen porque los globals definidos en `.eslintrc.json` son ignorados por completo.

**Solución — `eslint.config.js`:**
```javascript
import globals from 'globals';
export default [{
    files: ['js/**/*.js', 'tests/**/*.js'],
    languageOptions: {
        ecmaVersion: 'latest',
        sourceType: 'module',
        globals: {
            ...globals.browser,
            ...globals.es2021,
            ...globals.node,
            SEF: 'readonly',
            Vue: 'readonly',
            Plotly: 'readonly',
            C: 'readonly',
        },
    },
    rules: {
        'no-unused-vars': ['warn', { argsIgnorePattern: '^_' }],
        'no-console': 'off',
        eqeqeq: ['error', 'always'],
        semi: ['error', 'always'],
        quotes: ['error', 'single'],
    },
}, { ignores: ['node_modules/', 'dist/', '*.min.js'] }];
```

**Pitfalls:**
- `no-undef` aparece cuando los globals no están declarados en flat config
- `no-unused-vars` usa `argsIgnorePattern: '^_'` para permitir `_` y `_idx` como args sin uso
- La sección `{ ignores: [...] }` es obligatoria para no lintear node_modules/dist
- `.eslintrc.json` debe eliminarse o renombrarse para evitar confusión

**Ver:** `references/eslint-v10-flat-config.md`

---

## 16. Vite HTML Script Processing

Vite **solo transforma scripts que son ES modules** (`type="module"` o `.mjs`). Scripts de página (IIFEs sin `type="module"`) se ignoran completamente → no se transforman → no se hashan → **404 en el deploy**.

### Patrón A — Rutas relativas vs absolutas (scripts ES modules)

Si los scripts son ES modules, Vite los transforma a `/assets/hash.js`. Solo necesita rutas absolutas:

```diff
- <script type="module" src="js/app.js"></script>
+ <script type="module" src="/js/app.js"></script>
```

### Patrón B — Scripts de página (IIFEs, sin type="module")

**Problema:** Vite **no transforma** scripts `<script src="/js/app.js">` aunque tengan ruta absoluta. Los scripts IIFE no son ES modules, así que Vite los ignora.

**Síntoma:**
- HTML desplegado muestra `{{ }}` sin procesar (Vue no carga)
- `dist/` no contiene los archivos JS
- `curl /js/app.js` → 404

**Solución — Post-build script (`postbuild.js`):**

1. Copia los scripts JS/CSS a `dist/js/` y `dist/css/`
2. Transforma las referencias en el HTML (`/js/` → `js/`)
3. Se ejecuta tras `vite build`

```javascript
// postbuild.js
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const distDir = path.join(__dirname, 'dist');
const srcJsDir = path.join(__dirname, 'js');
const srcCssDir = path.join(__dirname, 'css');

const htmlPath = path.join(distDir, 'index.html');
let html = fs.readFileSync(htmlPath, 'utf-8');

const jsFiles = ['app.js', 'simulator.js', 'charts.js', /* ... */];
fs.mkdirSync(path.join(distDir, 'js'), { recursive: true });
for (const js of jsFiles) {
    const src = path.join(srcJsDir, js);
    if (fs.existsSync(src)) fs.copyFileSync(src, path.join(distDir, 'js', js));
}

fs.mkdirSync(path.join(distDir, 'css'), { recursive: true });
const cssFiles = ['app.css', 'ntizar.css'];
for (const css of cssFiles) {
    const src = path.join(srcCssDir, css);
    if (fs.existsSync(src)) fs.copyFileSync(src, path.join(distDir, 'css', css));
}

// Transformar referencias: /js/ → js/ (sin barra leading)
html = html.replace(/src="\/js\//g, 'src="js/');
html = html.replace(/href="\/css\//g, 'href="css/');
fs.writeFileSync(htmlPath, html);
```

En `package.json`:
```json
{
  "scripts": {
    "build": "vite build && node postbuild.js"
  }
}
```

### Patrón D — `rollupOptions.input` + post-build (alternativa)

Si quieres que Vite **incluya** los scripts en el build (para que aparezcan en el `dist/`), puedes añadirlos a `rollupOptions.input` en `vite.config.js`:

```javascript
export default defineConfig({
    build: {
        outDir: 'dist',
        emptyOutDir: true,
        rollupOptions: {
            input: [
                'index.html',
                'js/constants.js', 'js/theme.js', 'js/app.js',
                // ... todos los scripts
            ],
        },
    },
});
```

**Nota:** Esto **no transforma** los scripts IIFE (siguen siendo IIFEs), pero Vite los incluye en el `dist/` como assets con hash. Combinado con el post-build script para transformar referencias, es la solución más robusta.

### Patrón E — Dockerfile + scripts originales

Si usas un Dockerfile que copia todo el repo (`COPY . .`), los scripts `js/` y `css/` ya existen en el contenedor. Solo necesitas que el HTML tenga las rutas correctas.

**Solución:** El HTML del repo puede tener rutas relativas (`src="js/..."`) directamente — el Dockerfile los servirá correctamente. No se necesita Vite para nada.

**Pitfalls:**
- `rollupOptions.input` **NO transforma** scripts IIFE — solo los incluye como assets
- `transformIndexHtml` en plugins personalizados **NO funciona** como handler nativo de Vite
- El post-build script es **la solución más práctica** para proyectos con scripts legacy
- GitHub Pages sirve `dist/` → si los scripts no están en `dist/js/`, dan 404
- NaN.builders sirve el `dist/` del build → mismo problema
- **CRÍTICO:** El HTML del repo debe tener rutas absolutas (`/js/...`) para que Vite al menos las reconozca. El post-build las convierte a relativas (`js/...`) para que funcionen en el deploy.
- **Solo aplica a `index.html` en la raíz del proyecto.** Scripts cargados dinámicamente con `createElement('script')` no se ven afectados.
- **No confundir con CDN scripts.** Los scripts CDN (`https://cdn...`) no necesitan transformación.
- **CSS también aplica.** `<link href="css/app.css">` tampoco se transforma sin la barra.

### Patrón C — Convertir a ES modules (solución elegante)

Si es posible, convertir los IIFEs a ES modules con `export` y usar `type="module"` en el HTML. Vite los transforma automáticamente.

**Pitfalls:**
- `rollupOptions.input` NO funciona para scripts IIFE — Vite no los procesa como assets
- `transformIndexHtml` en plugins personalizados NO funciona como handler nativo
- El post-build script es la solución más práctica para proyectos con scripts legacy
- GitHub Pages sirve `dist/` → si los scripts no están en `dist/js/`, dan 404
- NaN.builders sirve el `dist/` del build → mismo problema
- **CRÍTICO:** El HTML del repo debe tener rutas absolutas (`/js/...`) para que Vite al menos las reconozca. El post-build las convierte a relativas (`js/...`) para que funcionen en el deploy.

**Ver:** `scripts/vite-postbuild.js` para un script reutilizable (actualizar lista de archivos por proyecto).
**Ver:** `references/vite-html-script-processing.md` para diagnóstico completo.

---

## 12. Geodatos Choropleth (Leaflet + Canvas)

Patrón para dashboards geodatos con miles de polígonos. Basado en España Atlas (8.132 municipios).

**Reglas clave:**
- **Canvas renderer** obligatorio para >500 polígonos (`L.canvas()`)
- **TopoJSON** en vez de GeoJSON (~70% menos de tamaño)
- **Hash index** para acceso O(1): `IDX[cod] = {...}`
- **`setStyle()`** para re-colorear sin reconstruir geometría
- **Pane system** para z-index de capas叠加
- **Lazy loading** de datasets temáticos con `ensureDataset()`

**Ver:** `koldo/espanatlas-architecture` para referencia completa con código, 10 trucos de rendimiento, y patrones de escalabilidad.

---

## 13. GTFS Browser Parser

Patron para parsear ficheros GTFS comprimidos directamente en el navegador sin servidor: descompresion en memoria, parsing de CSV, logica completa de calendario GTFS y visualizacion de rutas.

**Repo:** https://github.com/Ntizar/nap-dashboard

### Arquitectura

```
Browser
  -> fflate (descompresion ZIP en memoria)
  -> Parser CSV propio
  -> Deteccion de encoding (UTF-8 -> Windows-1252 fallback)
  -> Logica calendario GTFS
  -> Visualizacion (Leaflet + Recharts)
```

### Parsing GTFS

- **Descompresion en memoria** con `fflate` — sin escribir nada en disco
- **Deteccion de encoding** — fallback UTF-8 -> Windows-1252 cuando se detectan caracteres corruptos
- **Tolerancia a ficheros malformados** — cada fila se parsea en try/catch; las filas con errores se cuentan y se notifican
- **Cap de stop_times** — limitado a 100.000 registros para no bloquear el hilo principal
- **Tipos de ruta europeos extendidos** (NeTEx 100-1700): tren de alta velocidad, cercanias, metro, tranvia, funicular, teleférico, ferry

### Logica de Calendario GTFS

1. Comprueba primero `calendar_dates.txt` (excepciones puntuales — tienen prioridad)
2. Si no hay excepcion, consulta `calendar.txt` (dias de la semana + rango de fechas)
3. Si un servicio solo usa `calendar_dates.txt` (sin `calendar.txt`), funciona igualmente

### Pitfalls

- **Ficheros grandes** (>15 MB descomprimidos) pueden tardar varios segundos
- **stop_times masivo** — limitar a 100.000 registros maximo
- **Encoding corrupto** — detectar caracteres U+FFFD y fallback a Windows-1252
- **calendar_dates sin calendar.txt** — algunos feeds usan solo calendar_dates
