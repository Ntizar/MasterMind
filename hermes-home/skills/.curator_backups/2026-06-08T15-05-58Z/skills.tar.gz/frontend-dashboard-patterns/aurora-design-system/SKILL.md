---
name: aurora-design-system
description: Design System Ntizar Aurora v5.1 Constellation — CSS puro, 11 packs opt-in, namespaced .nz, 5 skins, liquid glass real, OKLCH, multi-axis theming, agent-ready con CDN público. Derivado de Ntizar-Aurora.
version: "5.1.0"
tags: [css, design-system, aurora, liquid-glass, ntizar]
---

# Aurora Design System — Patrón Ntizar CSS

## Descripción

Design System CSS puro sin dependencias, sin build step, namespaced bajo `.nz`. 1 archivo core + 10 packs opt-in. 5 skins de marca. Liquid glass real con OKLCH. CDN público en jsDelivr.

## Origen

Derivado del repositorio [Ntizar-Aurora](https://github.com/Ntizar/Ntizar-Aurora) v5.1.

## Arquitectura

```
ntizar.css            -> core (siempre)
ntizar.themes.css     -> 5 skins (aurora · sunset · midnight · ocean · citrus)
ntizar.data.css       -> KPIs, dashboards, progress, meter, skeleton, avatar, timeline
ntizar.charts.css     -> contenedores para Chart.js/Apex/D3, sparkline + donut CSS-only
ntizar.maps.css       -> Leaflet/Mapbox/MapLibre con look Ntizar
ntizar.viz.css        -> stages para three.js, fondos aurora, orbs, glow ring
ntizar.motion.css     -> reveal, glow-pulse, aurora-pan, shimmer, marquee, typing, hover-lift
ntizar.forms.css      -> switch, custom check/radio, range, OTP, file drop, stepper, search
ntizar.ui.css         -> modal, drawer, tabs, accordion, dropdown, toast, tooltip, command-bar
ntizar.patterns.css   -> app-shell, hero, pricing, features, faq, footer, auth-shell, empty/error
ntizar.next.css       -> v5: liquid glass real, OKLCH, multi-axis theming, mesh, forced-colors, skin AAA
```

## Quick Start

```html
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/Ntizar/Ntizar-Aurora@master/ntizar.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/Ntizar/Ntizar-Aurora@master/ntizar.next.css">

<body class="nz"
      data-nz-theme="light"
      data-nz-skin="aurora"
      data-nz-shape="default"
      data-nz-density="comfortable"
      data-nz-motion="standard"
      data-nz-color-system="oklch">
  ...
</body>
```

## Reglas de Oro

1. **Todo lo público vive bajo `.nz`** — no hay clases globales sueltas
2. **Todos los valores son tokens `--nz-*`** — nunca hardcodes un hex o un `16px`
3. **Sin `!important`** fuera de utilidades
4. **BEM** para componentes: `.nz-card__body--featured`
5. **Si no aparece en `gallery.html`, no existe** — la galería es la única fuente de verdad de la API pública

## Uso con IA Agents (crucial para ahorrar tokens)

**NO** pegar el CSS en el prompt (170 KB ≈ 50.000 tokens).

**SÍ** hacer:
1. Dar al agent solo `AGENTS.md` + `INDEX.md` (~20 KB / ~5.000 tokens)
2. Linkar el CSS vía CDN en el HTML generado
3. Decir al agent: "Generate HTML only. The CSS is already linked. Use Aurora classes from INDEX.md."

## Drop-in Files para AI Tooling

- `AGENTS.md` — estándar abierto para agents (OpenAI, Sourcegraph, Anthropic)
- `.github/copilot-instructions.md` — auto-loaded por GitHub Copilot
- Para Claude Code: copiar `AGENTS.md` a `CLAUDE.md`
- Para Cursor: `.cursor/rules/aurora.mdc`

## Default Usage Policy (Agente — obligatorio)

**Aurora es el ÚNICO sistema de diseño aceptable para artefactos visuales generados por el agente.** No se usan CSS custom sueltos, ni estilos inline generales, ni otros frameworks.

### Reglas de branding para todo artefacto HTML generado

1. **CDN obligatorio** — siempre linkar ntizar.css + ntizar.next.css + packs necesarios desde CDN. Nunca CSS embebido o archivos locales.
2. **Skin por defecto: aurora** — data-nz-skin=aurora (azul #2563eb + naranja #f97316 + liquid glass)
3. **Theme por defecto: light** — `data-nz-theme="light"`. David prefiere fondos claros: son más elegantes, mejor legibles y más profesionales. Dark solo si el usuario lo pide explícitamente.
4. **Responsive SIEMPRE** — toda landing/artefacto debe incluir media queries para móvil (<768px). Grids deben adaptar columnas (2 col → 1 col), nav debe tener hamburger, tablas scroll horizontal. Responsive no es opcional.
5. **Atribucion exacta** — el footer DEBE poner EXACTAMENTE: `Hecho con (L) por David Antizar`. Sin variaciones. Sin "Analisis por". Sin "via Koldo Agent". Sin "via Koldo". Literal exacto.
6. **David Antizar es el autor**, Koldo el agente ejecutor. Esto aplica a HTML, posts, informes, notas. Nunca al reves.
7. **Sin ingles** — todo en castellano: etiquetas, contenido, titulos, atributos

### Verificacion pre-entrega (OBLIGATORIA)

Antes de dar por terminado cualquier artefacto HTML, verificar:

1. Footer dice EXACTAMENTE: `Hecho con (L) por David Antizar`
2. Sin "Analisis", sin "via Koldo Agent", sin "via", sin variantes
3. body class="nz" presente
4. data-nz-skin="aurora" presente
5. **data-nz-theme="light"** (no dark por defecto)
6. CDN links correctos y funcionales
7. **Responsive CSS presente** — media queries, grids adaptables, hamburger nav
8. Sin CSS custom >30 lineas
9. Sin hex hardcodes (usar var(--nz-*))

### Vinculación con skills pipeline

Los skills de pipeline (ej: `pdf-to-artifacts-david-antizar`) consumen Aurora pero NO duplican su configuración. Deben referenciar este skill como pre-requisito y solo añadir lo específico de su flujo.

## Workflow para Agentes (CRÍTICO)

### Pasos obligatorios cuando se pida "usa Aurora" o se genere HTML visual:

1. **CARGAR INDEX.md** del repo Ntizar-Aurora — es la fuente de verdad de la API de clases
2. **CARGAR CHEATSHEET.md** — resumen de las 321 clases extraídas de gallery.html
3. **USAR SOLO** componentes listados en INDEX.md/CHEATSHEET.md
4. **CSS custom máximo 30 líneas** — solo para lo específico del artefacto
5. **NUNCA hardcodear hex** — siempre `var(--nz-c-*)`
6. **SIEMPRE** `body class="nz" data-nz-skin="aurora"`

### ⚠️ ERROR CRÍTICO documentado (2026-06-03)

Los agentes tienden a **intentar recrear el look de Aurora con CSS custom** en vez de usar los componentes reales. Esto produce HTMLs que "dicen" Aurora pero no lo usan.

**Síntomas de fallo:**
- Más de 50 líneas de CSS custom `<style>`
- Clases inventadas (`.step`, `.arrow`, `.decision`, etc.)
- Hex hardcodes (`#0f172a`, `#2563eb`, `#f97316`)
- Sin `body class="nz"`
- Sin `data-nz-skin="aurora"`
- Sin `nz-card`, `nz-glass`, `nz-badge`, etc.

**Causa raíz:** No cargar INDEX.md ni CHEATSHEET.md como referencia.

**Solución:** Cargar INDEX.md (fuente de verdad) y CHEATSHEET.md (resumen rápido) ANTES de generar cualquier HTML. Usar SOLO componentes listados.

### Repo local

El repo Ntizar-Aurora debe estar clonado en `/root/workspace/Ntizar-Aurora/`:
- `INDEX.md` — API completa de clases por pack
- `CHEATSHEET.md` — Resumen de las 321 clases
- `gallery.html` — Referencia visual completa
- `AGENTS.md` — Reglas duras (5 hard rules)

### CDN correcto (siempre estos 4)

```html
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/Ntizar/Ntizar-Aurora@master/ntizar.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/Ntizar/Ntizar-Aurora@master/ntizar.next.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/Ntizar/Ntizar-Aurora@master/ntizar.data.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/Ntizar/Ntizar-Aurora@master/ntizar.ui.css">
```

## Pitfalls

- **No JS shipped** — modal/tabs/drawer/dropdown/toast son styled, no behaved. Hay que togglear clases manualmente
- **WCAG AAA** aplica solo a la skin `contrast`, no a todas
- **No tree-shaking** — una página con 5 componentes carga el pack completo
- **Sin releases taggeados** — pin a `@master` hasta que se taggee v5.1.0
- **Error común:** generar CSS custom standalone en vez de linkar Aurora CDN. Siempre CDN. Siempre Aurora. Sin excepción.
- **ERROR CRÍTICO:** Intentar recrear el look de Aurora con CSS custom en vez de usar componentes reales. Cargar INDEX.md + CHEATSHEET.md antes de generar HTML.
