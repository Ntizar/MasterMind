---
name: threejs-3d-scene
description: "Crear escenas 3D interactivas en navegador con Three.js — setup de escena, texturas procedurales, iluminación, cámara con animación, interacción raycaster, y pitfalls de OrbitControls."
version: 1.0.0
author: David Antizar
tags: [threejs, 3d, webgl, vanilla-js, canvas, procedural-textures, orbit-controls]
---

# Three.js — Escenas 3D Interactivas en Navegador

Crear escenas 3D interactivas en vanilla JS con Three.js, sin bundler, desde CDN.

## Setup Rápido

```html
<script type="importmap">
{
    "imports": {
        "three": "https://cdn.jsdelivr.net/npm/three@0.163.0/build/three.module.js",
        "three/addons/": "https://cdn.jsdelivr.net/npm/three@0.163.0/examples/jsm/"
    }
}
</script>
<script type="module">
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
// ... tu código
</script>
```

## Pasos Numerados

### 1. Escena + Cámara + Renderer

```javascript
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(55, w / h, 0.01, 10000);
camera.position.set(8, 6, 10);

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(w, h);
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.0;
document.getElementById('container').appendChild(renderer.domElement);
```

### 2. OrbitControls con damping

```javascript
const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.dampingFactor = 0.05;
controls.minDistance = 0.3;
controls.maxDistance = 150;
```

### 3. Iluminación

```javascript
scene.add(new THREE.PointLight(0xffffff, 3, 500)); // luz principal
scene.add(new THREE.AmbientLight(0x222233, 0.5));   // relleno
```

### 4. Texturas Procedurales (Canvas)

Crear texturas en canvas 2D → `THREE.CanvasTexture`:

```javascript
function createPlanetTexture(name, color) {
    const canvas = document.createElement('canvas');
    canvas.width = 512; canvas.height = 256;
    const ctx = canvas.getContext('2d');
    const c = new THREE.Color(color);
    const r = Math.floor(c.r * 255), g = Math.floor(c.g * 255), b = Math.floor(c.b * 255);

    // Gradiente base
    const grad = ctx.createLinearGradient(0, 0, 0, 256);
    grad.addColorStop(0, `rgb(${Math.min(255,r+40)},${Math.min(255,g+40)},${Math.min(255,b+40)})`);
    grad.addColorStop(0.5, `rgb(${r},${g},${b})`);
    grad.addColorStop(1, `rgb(${Math.max(0,r-40)},${Math.max(0,g-40)},${Math.max(0,b-40)})`);
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 512, 256);

    // Noise layers para detalle
    for (let layer = 0; layer < 3; layer++) {
        for (let i = 0; i < 1500 + layer * 500; i++) {
            const x = Math.random() * 512, y = Math.random() * 256;
            const alpha = (0.03 + Math.random() * 0.08) * (3 - layer);
            ctx.fillStyle = Math.random() > 0.5
                ? `rgba(255,255,255,${alpha})`
                : `rgba(0,0,0,${alpha})`;
            ctx.fillRect(x, y, 3 + Math.random()*3, 3 + Math.random()*3);
        }
    }

    // Features específicas por objeto
    if (name === 'Earth') {
        // océanos, continentes, nubes, casquetes polares...
    }

    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    return texture;
}
```

### 5. Materiales con texturas

```javascript
const geo = new THREE.SphereGeometry(radius, 64, 48);
const mat = new THREE.MeshStandardMaterial({
    map: texture, roughness: 0.75, metalness: 0.05
});
const mesh = new THREE.Mesh(geo, mat);
scene.add(mesh);
```

### 6. Interacción — Raycaster + Click

```javascript
const raycaster = new THREE.Raycaster();
const mouse = new THREE.Vector2();

renderer.domElement.addEventListener('click', (e) => {
    mouse.x = (e.clientX / w) * 2 - 1;
    mouse.y = -(e.clientY / h) * 2 + 1;
    raycaster.setFromCamera(mouse, camera);
    const intersects = raycaster.intersectObjects(meshesArray);
    if (intersects.length > 0) {
        const hit = intersects[0].object;
        // procesar hit...
    }
});
```

### 7. Animación de cámara (zoom a objeto)

⚠️ **PITFALL CRÍTICO: OrbitControls damping FIGHTS camera animation**

Cuando mueves `camera.position` y `controls.target` manualmente, el damping de OrbitControls los sobrescribe en cada frame. **Solución:**

```javascript
function animateCamera(target, position) {
    const startPos = camera.position.clone();
    const startTarget = controls.target.clone();
    // ⚠️ DESACTIVAR damping durante animación
    controls.enableDamping = false;
    const animStart = performance.now();
    const animDur = 1200;

    function animStep() {
        const t = Math.min((performance.now() - animStart) / animDur, 1);
        const ease = t < 0.5 ? 4*t*t*t : 1 - Math.pow(-2*t+2, 3)/2;
        camera.position.lerpVectors(startPos, position, ease);
        controls.target.lerpVectors(startTarget, target, ease);
        if (t < 1) requestAnimationFrame(animStep);
        else { controls.enableDamping = true; } // ⚠️ REACTIVAR al terminar
    }
    animStep();
}
```

### 8. Loop de animación

```javascript
function animate(time) {
    requestAnimationFrame(animate);
    controls.update();
    renderer.render(scene, camera);
}
animate(0);
```

### 9. Resize handler

```javascript
window.addEventListener('resize', () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
});
```

## Pitfalls

- **OrbitControls damping fights manual camera moves** → desactivar damping durante animación, reactivar al terminar (ver paso 7)
- **Canvas texture no se ve en esfera pequeña** → usar canvas de 512px mínimo, esfera de radio >= 0.3, cámara a distancia <= 3.0
- **Raycaster no detecta objetos** → verificar que los meshes están en `scene` y pasarlos al `intersectObjects()`
- **ES module scope** → variables dentro de `<script type="module">` NO son accesibles desde DevTools console. Usar `window.varName = ...` para debugging
- **Pixel ratio alto en móvil** → `Math.min(devicePixelRatio, 2)` para evitar sobrecarga GPU
- **Additive blending para glow** → usar `side: THREE.BackSide` + `blending: THREE.AdditiveBlending` + `depthWrite: false`
- **RingGeometry UVs rotas** → hay que recalcular UVs manualmente para que la textura se mapee radialmente
- **Three.js CDN version** → usar versión fija (`0.163.0`), no `latest`, para evitar breaking changes

## Casos de Uso

- Visualizaciones de datos 3D (sistemas, redes, geografía)
- Simulaciones físicas/orbitales
- Modelos 3D interactivos
- Dashboards con visualización espacial
- Arte generativo
