# Proyecto: Sistema Solar — Gemelo Digital

**URL:** https://ntizar.github.io/sistema-solar/
**Repo:** https://github.com/Ntizar/sistema-solar

## Qué se hizo

Gemelo digital interactivo del Sistema Solar con posiciones planetarias reales calculadas con mecánica orbital kepleriana (ecuación de Kepler resuelta numéricamente).

## Técnicas aplicadas

- **Three.js** sin bundler (importmap CDN)
- **Texturas procedurales** canvas 512px por planeta (Tierra con océanos/continentes/nubes, Júpiter con bandas y Gran Mancha Roja, Saturno con anillos y Cassini division, Mercurio con cráteres, Marte con casquetes polares)
- **Shader de glow** para el Sol (additive blending, BackSide)
- **20.000 estrellas** de fondo con colores variados
- **Mecánica orbital** — Kepler solver con 50 iteraciones máx.
- **Raycaster** para click en planetas
- **Cámara animada** con damping desactivado durante animación
- **GitHub Pages** deploy (branch gh-pages + workflow pages.yml)

## Lecciones

- OrbitControls damping **debe desactivarse** durante animación de cámara y reactivarse al terminar
- Canvas texture necesita >= 512px y esfera >= 0.3 radio para que se vea detalle
- ES module scope: variables no accesibles desde DevTools console (usar `window.`)
- GitHub Pages necesita branch `gh-pages` o workflow `pages.yml`
- Para deploy estático puro: `gh-pages` branch es más rápido que workflow
