---
name: github-pr-workflow
description: "GitHub PR lifecycle: branch, commit, open, CI, merge."
version: 1.1.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [GitHub, Pull-Requests, CI/CD, Git, Automation, Merge]
    related_skills: [github-auth, github-code-review]
---

# GitHub Pull Request Workflow

Complete guide for managing the PR lifecycle. Each section shows the `gh` way first, then the `git` + `curl` fallback for machines without `gh`.

## When to Use

- User wants to create, manage, or merge a Pull Request
- Need to set up a PR workflow (branch → commit → PR → CI → merge)
- CI checks are failing and need auto-fixing
- User asks to enable auto-merge or manage PR settings

## When NOT to Use

- Making small direct commits to main → no PR needed for trivial fixes
- Working with a non-GitHub repo (GitLab, Bitbucket) → different workflows
- The repo doesn't have PRs enabled → check repo settings first

## Prerequisites

- Authenticated with GitHub (see `github-auth` skill)
- Inside a git repository with a GitHub remote

### Quick Auth Detection

```bash
AUTH="gh"
command -v gh &>/dev/null && gh auth status &>/dev/null || AUTH="git"
# Set GITHUB_TOKEN from .env or .git-credentials if using curl
```

### Extracting Owner/Repo

```bash
REMOTE_URL=$(git remote get-url origin)
OWNER_REPO=$(echo "$REMOTE_URL" | sed -E 's|.*github\\.com[:/]||; s|\\.git$||')
OWNER=$(echo "$OWNER_REPO" | cut -d/ -f1)
REPO=$(echo "$OWNER_REPO" | cut -d/ -f2)
```

---

## 1. Branch Creation

This part is pure `git` — identical either way:

```bash
# Make sure you're up to date
git fetch origin
git checkout main && git pull origin main

# Create and switch to a new branch
git checkout -b feat/add-user-authentication
```

Branch naming conventions:
- `feat/description` — new features
- `fix/description` — bug fixes
- `refactor/description` — code restructuring
- `docs/description` — documentation
- `ci/description` — CI/CD changes

## 2. Making Commits

Use the agent's file tools (`write_file`, `patch`) to make changes, then commit:

```bash
# Stage specific files
git add src/auth.py src/models/user.py tests/test_auth.py

# Commit with a conventional commit message
git commit -m "feat: add JWT-based user authentication

- Add login/register endpoints
- Add User model with password hashing
- Add auth middleware for protected routes
- Add unit tests for auth flow"
```

Commit message format (Conventional Commits):
```
type(scope): short description

Longer explanation if needed. Wrap at 72 characters.
```

Types: `feat`, `fix`, `refactor`, `docs`, `test`, `ci`, `chore`, `perf`

## 3. Pushing and Creating a PR

### Push the Branch (same either way)

```bash
git push -u origin HEAD
```

### Create the PR

```bash
gh pr create \
  --title "feat: add JWT-based user authentication" \
  --body "## Summary
- Adds login and register API endpoints
- JWT token generation and validation

## Test Plan
- [ ] Unit tests pass

Closes #42"
```

Options: `--draft`, `--reviewer user1,user2`, `--label "enhancement"`, `--base develop`.
For curl: `POST /repos/{owner}/{repo}/pulls` with JSON body containing `title`, `body`, `head`, `base`. Add `"draft": true` for draft PRs.

## 4. Monitoring CI Status

### Check CI Status

```bash
gh pr checks
gh pr checks --watch  # polls every 10s until complete
```

For curl: `GET /repos/{owner}/{repo}/commits/{sha}/status` for combined status, `GET /commits/{sha}/check-runs` for Actions. Use polling loop (check every 30s, up to 10 min) for automated waits.

## 5. Auto-Fixing CI Failures

When CI fails, diagnose and fix. This loop works with either auth method.

### Step 1: Get Failure Details

```bash
gh run list --branch $(git branch --show-current) --limit 5
gh run view <RUN_ID> --log-failed
```

For curl: `GET /repos/{owner}/{repo}/actions/runs?branch=...` to list runs, download logs via `GET /actions/runs/{id}/logs`.

### Step 2: Fix and Push

```bash
git add <fixed_files>
git commit -m "fix: resolve CI failure in <check_name>"
git push
```

### Step 3: Verify

Re-check CI status using commands from Section 4 above.

### Auto-Fix Loop Pattern

When asked to auto-fix CI, follow this loop:

1. Check CI status → identify failures
2. Read failure logs → understand the error
3. Use `read_file` + `patch`/`write_file` → fix the code
4. `git add . && git commit -m "fix: ..." && git push`
5. Wait for CI → re-check status
6. Repeat if still failing (up to 3 attempts, then ask the user)

## 6. Merging

```bash
# Squash merge + delete branch (cleanest for feature branches)
gh pr merge --squash --delete-branch
# Enable auto-merge (merges when all checks pass)
gh pr merge --auto --squash --delete-branch
```

For curl: `PUT /repos/{owner}/{repo}/pulls/{number}/merge` with `merge_method: "merge"|"squash"|"rebase"`. Delete branch with `git push origin --delete $BRANCH`.

### Enable Auto-Merge (curl)

Uses GraphQL API since REST doesn't support auto-merge: `POST /graphql` with `mutation { enablePullRequestAutoMerge(input: {pullRequestId: "...", mergeMethod: SQUASH}) }`.

## 7. Complete Workflow Example

```bash
git checkout main && git pull origin main
git checkout -b fix/login-redirect-bug
# (Agent makes code changes)
git add src/auth/login.py tests/test_login.py
git commit -m "fix: correct redirect URL after login"
git push -u origin HEAD
# (see Section 3 for PR creation)
# (see Section 4 for CI monitoring)
# (see above for merge)
```

## Useful PR Commands

| Action | gh |
|--------|-----|
| List my PRs | `gh pr list --author @me` |
| View PR diff | `gh pr diff` |
| Add comment | `gh pr comment N --body "..."` |
| Request review | `gh pr edit N --add-reviewer user` |
| Close PR | `gh pr close N` |
| Check out PR | `gh pr checkout N` |

For curl equivalents, use the REST API endpoints for pulls/issues listed in the relevant sections above.
