---
name: github-repo-management
description: "Clone/create/fork repos; manage remotes, releases."
version: 1.1.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [GitHub, Repositories, Git, Releases, Secrets, Configuration]
    related_skills: [github-auth, github-pr-workflow, github-issues]
---

# GitHub Repository Management

Create, clone, fork, configure, and manage GitHub repositories. Each section shows `gh` first, then the `git` + `curl` fallback.

## Prerequisites

- Authenticated with GitHub (see `github-auth` skill)

### Setup

```bash
# Auth detection: prefer gh, fall back to GITHUB_TOKEN from .env or .git-credentials
AUTH="gh"
command -v gh &>/dev/null && gh auth status &>/dev/null || AUTH="git"
# Set GH_USER, OWNER, REPO as needed
```

---

## 1. Cloning Repositories

```bash
# Clone via HTTPS
git clone https://github.com/owner/repo-name.git

# Shallow clone, specific branch, SSH
git clone --depth 1 https://github.com/owner/repo-name.git
git clone --branch develop https://github.com/owner/repo-name.git
git clone git@github.com:owner/repo-name.git

# With gh shorthand
gh repo clone owner/repo-name
gh repo clone owner/repo-name -- --depth 1
```

## 2. Creating Repositories

```bash
# Public, with description, license
gh repo create my-new-project --public --description "A useful tool" --license MIT --clone

# Private, under an organization
gh repo create my-org/my-new-project --private --clone

# From existing local directory
cd /path/to/existing/project && gh repo create my-project --source . --public --push

# From a template
gh repo create my-new-app --template owner/template-repo --public --clone
```

### Pitfall: Private repo con `auto_init: true` (curl) → conflicto de merge

Cuando se crea un repo privado vía API con `"auto_init": true`, el remoto recibe un README inicial. Si luego haces `git push` desde un repo local con su propio README, falla por divergencia.

**Solución:** hacer merge (NO rebase):
```bash
cd /path/to/repo
git pull origin main --allow-unrelated-histories --no-edit  # merge, no rebase
git push origin main
```

Rebase falla con `CONFLICT (add/add)` en este caso porque ambos lados crearon el mismo archivo desde vacío.

**Private repo via curl/Python (when gh CLI is unavailable):**

```python
import yaml, requests

with open('/root/.config/gh/hosts.yml') as f:
    config = yaml.safe_load(f)
token = config['github.com']['oauth_token']

headers = {'Authorization': f'token {token}', 'Accept': 'application/vnd.github.v3+json'}

r = requests.post(
    'https://api.github.com/user/repos',
    headers=headers,
    json={
        'name': 'REPO_NAME',
        'description': 'Description',
        'private': True,      # ← CRITICAL: omit this → public repo
        'has_issues': True,
        'has_projects': True,
        'has_wiki': True
    }
)
```

**Git push with token from gh config (avoids special-char URL breakage):**

```python
import yaml, subprocess, os

with open('/root/.config/gh/hosts.yml') as f:
    config = yaml.safe_load(f)
token = config['github.com']['oauth_token']

subprocess.run(['git', '-C', '/path/to/repo', 'remote', 'add', 'origin',
    'https://github.com/OWNER/REPO.git'], capture_output=True)

env = os.environ.copy()
env['GIT_ASKPASS'] = '/dev/null'  # avoids embedded token in URL
result = subprocess.run(
    ['git', '-C', '/path/to/repo', 'push', '-u', 'origin', 'main'],
    capture_output=True, text=True,
    input=f'{token}\n\n',  # username + password on stdin
    timeout=30
)
```

**Why `GIT_ASKPASS` instead of `https://user:token@github.com/...`?**  
GitHub tokens often contain `'/'`, `'+'`, `'='` that break URL parsing even when URL-encoded. The askpass approach avoids this entirely.

## 3. Forking Repositories

```bash
gh repo fork owner/repo-name --clone
```

### Keeping a Fork in Sync

```bash
git fetch upstream && git checkout main && git merge upstream/main && git push origin main
gh repo sync $GH_USER/repo-name
```

## 4. Repository Information

```bash
gh repo view owner/repo-name
gh repo list --limit 20
gh search repos "machine learning" --language python --sort stars
```

For curl: `GET /repos/{owner}/{repo}`, `GET /user/repos`, `GET /search/repositories`.

## 5. Repository Settings

```bash
gh repo edit --description "Updated" --visibility public
gh repo edit --enable-wiki=false --enable-issues=true
gh repo edit --default-branch main --add-topic "machine-learning,python"
gh repo edit --enable-auto-merge
```

For curl: `PATCH /repos/{owner}/{repo}` for settings, `PUT /repos/{owner}/{repo}/topics` for topics.

## 6. Branch Protection

```bash
# View
curl -s -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$OWNER/$REPO/branches/main/protection

# Set up (requires curl PUT with JSON: required_status_checks, required_pull_request_reviews, enforce_admins)
```

## 7. Secrets Management (GitHub Actions)

```bash
gh secret set API_KEY --body "your-secret-value"
gh secret list
gh secret delete API_KEY
```

Note: `gh secret set` is dramatically simpler. Secrets via curl require encrypting with the repo's public key (PyNaCl). If `gh` isn't available, recommend installing it.

## 8. Releases

```bash
gh release create v1.0.0 --title "v1.0.0" --generate-notes
gh release create v2.0.0-rc1 --draft --prerelease --generate-notes
gh release create v1.0.0 ./dist/binary --title "v1.0.0" --notes "Release notes"
gh release list
gh release download v1.0.0 --dir ./downloads
```

For curl: `POST /repos/{owner}/{repo}/releases` with JSON body. Upload assets via `POST /repos/{owner}/{repo}/releases/{id}/assets`.

## 9. GitHub Actions Workflows

```bash
gh workflow list
gh run list --limit 10
gh run view <RUN_ID>
gh run view <RUN_ID> --log-failed
gh run rerun <RUN_ID>
gh run rerun <RUN_ID> --failed
gh workflow run ci.yml --ref main
```

For curl: `GET /repos/{owner}/{repo}/actions/workflows`, `GET /actions/runs`, `POST /actions/runs/{id}/rerun`, `POST /actions/workflows/{id}/dispatches`.

## 10. Gists

```bash
gh gist create script.py --public --desc "Useful script"
gh gist list
```

For curl: `POST /gists` with JSON body containing `description`, `public`, and `files`.

## Quick Reference Table

| Action | gh | git + curl |
|--------|-----|-----------|
| Clone | `gh repo clone o/r` | `git clone https://github.com/o/r.git` |
| Create repo | `gh repo create name --public` | `curl POST /user/repos` |
| Fork | `gh repo fork o/r --clone` | `curl POST /repos/o/r/forks` + `git clone` |
| Repo info | `gh repo view o/r` | `curl GET /repos/o/r` |
| Edit settings | `gh repo edit --...` | `curl PATCH /repos/o/r` |
| Create release | `gh release create v1.0` | `curl POST /repos/o/r/releases` |
| List workflows | `gh workflow list` | `curl GET /repos/o/r/actions/workflows` |
| Rerun CI | `gh run rerun ID` | `curl POST /repos/o/r/actions/runs/ID/rerun` |
| Set secret | `gh secret set KEY` | `curl PUT /repos/o/r/actions/secrets/KEY` (+ encryption) |
| Private repo + push | — | `references/token-extraction-push.md` |

## Linked Files

- `references/github-api-cheatsheet.md` — Full REST API endpoint reference
- `references/token-extraction-push.md` — Token extraction from gh config + private repo creation + git push with GIT_ASKPASS
- `references/patron-tracking-dieta.md` — Patrón de tracking de dieta y ejercicio: estructura de repo privado, flujo de registro diario con timestamp, tablas de peso/pasos/comidas

## When to Use

- User wants to create, clone, fork, or manage a GitHub repository
- Need to configure repo settings (branch protection, topics, auto-merge)
- Managing GitHub Actions secrets or workflow runs
- Creating releases with assets for a project

## When NOT to Use

- The user only needs to read public repo info → `curl` without auth is enough
- Managing repos on GitLab/Bitbucket → different APIs and workflows
- Bulk repo operations across organizations → consider `gh org` or API scripting
