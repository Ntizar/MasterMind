---
name: dieta
version: "1.0.0"
description: "Seguimiento de dieta y nutrición — cálculo de macros, registro de comidas en el repo /root/workspace/dieta/, estimación de kcal y macronutrientes a partir de descripciones o fotos de packaging."
tags: [dieta, nutrición, kcal, seguimiento, salud]
---

# Dieta — Seguimiento nutricional y deportivo

## Qué hace

Registro y seguimiento de comidas, entrenamiento, peso y alcohol en `/root/workspace/dieta/SEGUIMIENTO.md`. Generación de resúmenes diarios.

## Trigger del usuario

- **`Dieta.`** al inicio del mensaje → el usuario quiere registrar algo en su seguimiento de dieta. Si además cuenta qué comió, registrar las comidas. Si solo dice "Dieta." sin más, registrar el peso si está disponible. No necesita decir "actualiza mi dieta" — solo "Dieta." basta.

## Pasos

1. **Registrar comida:** leer SEGUIMIENTO.md → **verificar que la fila se añade con la fecha CORRECTA** (no confundir con días anteriores) → añadir fila con fecha, hora, tipo, descripción, kcal est., notas → commit
2. **Registrar entrenamiento:** leer SEGUIMIENTO.md → añadir entrada en sección entrenamiento → commit
3. **Registrar peso:** leer SEGUIMIENTO.md → actualizar tabla peso → commit
4. **Generar resumen diario:** leer SEGUIMIENTO.md → filtrar por fecha actual → extraer comidas, entrenamiento, alcohol, peso → calcular totales → presentar resumen visual

## Formato de comidas

Cada comida en SEGUIMIENTO.md sigue esta estructura:
```
| [fecha] | [hora] | [desayuno] | [almuerzo] | [comida] | [merienda] | [cena] | [kcal] | [notas] |
```

Los campos vacíos se dejan como `-`.

## Estimación de kcal (referencia rápida)

- 1 huevo grande: ~75 kcal
- 1 rodaja jamón cocido: ~30 kcal
- 100g queso: ~350 kcal
- 1 tomate mediano: ~20 kcal
- 1 melocotón: ~60 kcal
- 100g salteado rústico: ~200 kcal
- 2 filetes cerdo pequeños: ~150 kcal
- 1 vaso agua: 0 kcal
- Alcohol: 1 caña cerveza ~150 kcal, 1 copa vino ~120 kcal, 1 copa licor ~100 kcal

## Pitfalls

- **Confundir días:** AL añadir una fila, verificar SIEMPRE la columna de fecha. Error clásico: añadir comida del día actual en la fila del día anterior (ej: 5 de junio en la fila del 4). El usuario siempre nota esto. Antes de hacer el patch, leer las últimas 5 filas y confirmar la fecha.
- **Skill no carga:** si `skill_view(name='dieta')` falla pero `skills_list(category='health')` la muestra, el SKILL.md tiene formato corrupto. Recrear con `skill_manage(action='create')`
- **Formato tabla:** siempre usar `|` como delimitador, NO `|||`. El patch puede duplicar pipes si no se revisa. **CRÍTICO:** antes de aplicar cualquier patch a SEGUIMIENTO.md, verificar visualmente que NO se han introducido `||` dobles al inicio de las filas. Si el archivo ya tiene filas con `||`, corregir primero con un patch que elimine el pipe extra ANTES de añadir nuevas filas.
- **Commit siempre:** tras cada modificación del archivo, hacer `git add` + `git commit` con mensaje descriptivo en castellano
- **No modificar:** el cron de resumen SOLO lee, nunca escribe

## Cron job de resumen diario

Para crear un resumen diario automático a las 23:00 UTC:
```
cronjob action=create
  name: resumen-diario-dieta-deporte
  schedule: 0 23 * * *
  skills: [dieta]
  deliver: origin
  prompt: (ver templates/cron-resumen-diario.md)
```

## Archivos de soporte

- `templates/cron-resumen-diario.md` — prompt para cron job de resumen
- `references/cron-failures.md` — lecciones sobre fallos de cron jobs por tamaño de contenido