# Ejecución de auditoría v4.0 — Sistema Eléctrico Futuro

**Fecha:** 2026-06-01
**Proyecto:** SistemaElectricoFuturo
**Commit:** b7e0859 (tag v4.0.0)

## Hallazgos corregidos

### FC_HISTORICOS invertidos (CRÍTICO)
- Solar: 0.18 → 0.24 (factor real REE 2025: 52.5 TWh / 24.7 GW / 8760h)
- Eólica: 0.24 → 0.20 (factor real REE 2025: 55.6 TWh / 31.6 GW / 8760h)
- **Impacto:** Solar subestimaba autoconsumo FV ~25%

### _hidroEmbalseUsadoGWh sin reset
- **Problema:** Variable de instancia no se reseteaba entre llamadas a `simular()`
- **Fix:** `this._hidroEmbalseUsadoGWh = 0;` al inicio de `simular()`

### Factor 1.35 sin documentar
- **Problema:** Constante mágica en weather.js que inflaba perfil solar
- **Fix:** Comentario explicativo (compensación Beer-Lambert simplificado)

### Escenario 0 confuso
- **Problema:** Decía "Datos Reales 2025" pero usaba `anioObjetivo: 2026`
- **Fix:** Descripción aclarada: "Usa capacities de 2025 pero simula año 2026"

## Resultados de tests

| Archivo | Tests | Estado |
|---------|-------|--------|
| calibracion-2025.test.js | 15 | ✅ 15/15 |
| calibracion.test.js | 12 | ✅ 12/12 |
| orden-merito.test.js | 5 | ✅ 5/5 |
| almacenamiento.test.js | 10 | ✅ 10/10 |
| nuclear.test.js | 12 | ✅ 12/12 |
| trayectoria.test.js | 8 | ✅ 8/8 |
| regresion.test.js | 27 | ✅ 27/27 |
| unitarios.test.js | 27 | ✅ 27/27 |
| unitarios-modulos.test.js | 38 | ✅ 38/38 |
| **TOTAL** | **154** | **✅ 154/154** |

## Métricas del modelo vs mundo real

| Métrica | Modelo | Real (REE 2025) | Nota |
|---------|--------|-----------------|------|
| Solar | 50-55 TWh | 52.5 TWh | ✅ Rango correcto |
| Eólica | 50-60 TWh | 55.6 TWh | ✅ Rango correcto |
| Nuclear | 48-55 TWh | 51.9 TWh | ✅ Rango correcto |
| Demanda | 240-260 TWh | 248 TWh | ✅ Rango correcto |
| Precio medio | 285 €/MWh | 63 €/MWh | ⚠ Modelo simplificado |
| Emisiones | 5.5 Mt | 36 Mt | ⚠ Modelo subestima gas |

## Archivos creados

- `package.json` — ESM, scripts test/build/lint
- `vite.config.js` — Vitest config
- `eslint.config.js` — ESLint flat config
- `.gitignore` — node_modules, dist
- `.github/workflows/ci.yml` — CI Node 20+22
- `js/engine.js` — Entry point ESM headless
- `CONSTANTS.md` — Documentación de constantes con fuentes
- `METHODOLOGY.md` — Metodología completa (8 secciones)
- `CHANGELOG.md` — Changelog v4.0.0
- `tests/*.test.js` — 5 archivos de tests nuevos
