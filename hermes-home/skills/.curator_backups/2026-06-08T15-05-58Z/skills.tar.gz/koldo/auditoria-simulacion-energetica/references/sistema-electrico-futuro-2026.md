# Auditoría de Sistema Eléctrico Futuro — Referencia

> Proyecto auditado: https://ntizar.github.io/SistemaElectricoFuturo/
> Repositorio: Ntizar/SistemaElectricoFuturo (main)

## v3.4 (1 junio 2026) — Nota: 8/10

### Perfil
- Simulador sistema eléctrico español 2026-2035
- Stack: HTML estático + Vue 3 CDN + Plotly.js + CSS propio (Ntizar Aurora)
- Sin build, sin tests, sin CI
- **22 escenarios** (0-21), incluyendo 4 ceteris paribus nucleares (18-21)
- Despacho horario 8760h/año con orden de mérito SRMC real
- Monte Carlo multi-semilla (9 semillas, percentiles P5-P50-P95)
- Desplegado en GitHub Pages + NaN.builders

### Estado de hallazgos v3.1 → v3.4

| ID v3.1 | Problema | Estado v3.4 |
|---------|----------|-------------|
| S1 | Precio heurístico | ✅ Resuelto — SRMC real 12 tecnologías |
| S2 | Renovables sin calibrar | ✅ Resuelto — CF: solar 24%, eólica 20%, offshore 43% |
| S3 | PRNG Math.sin | ✅ Resuelto — Mulberry32 |
| D1 | Calendario ENRESA erróneo | ✅ Resuelto — Todos correctos |
| D2 | "Tiempo real" estático | ✅ Resuelto — Etiqueta correcta |
| D3 | Tope ibérico arbitrario | ⚠️ Documentado como hipotético (no corregido fórmula) |
| D4 | CfD una sola cara | ✅ Resuelto — Doble cara |

### Hallazgos residuales v3.4

| ID | Severidad | Problema |
|----|-----------|----------|
| H1 | Medio | Factor 1.35 en weather.js sin documentar (infla perfil solar, luego se compensa) |
| H2 | Medio | FC_HISTORICOS solar=0.18, eolica=0.24 desactualizados (real: 0.24, 0.20) — subestima autoconsumo ~25% |
| H3 | Bajo | _hidroEmbalseUsadoGWh no se resetea al inicio de simular() |
| H4 | Bajo | Escenario 0 "Datos 2025" usa anioObjetivo: 2026 |
| R4 | Alto | Sin test de calibración contra 2025 |
| A1 | Alto | Sin tests unitarios (Vitest) |
| A2 | Alto | Sin package.json / Vite |

### Escenarios ceteris paribus nucleares (IDs 18-21)

Mismos parámetros excepto política nuclear — comparación directa:
- 18: ENRESA oficial (sin prórroga)
- 19: Prórroga 10 años
- 20: Prórroga 20 años (60 años vida)
- 21: Cierre acelerado 2030

### Plan de acción v3.4

| Fase | Duración | Qué |
|------|----------|-----|
| 0 | 1 día | Actualizar FC_HISTORICOS, documentar weather.js, inicializar var hidro |
| 1 | 1 sem | Test calibración 2025, alinear constantes con fuentes |
| 2 | 2 sem | package.json + Vitest + CI + motor headless |
| 3 | Continuo | Vista comparativa UI, documentar constantes |

---

## v3.1 (mayo 2026) — Nota: 6/10

### Hallazgos críticos (ya corregidos en v3.4)

- S1: Precio heurístico (magic numbers sin orden de mérito real)
- S2: Renovables sin calibrar (factor 1.35 arbitrario)
- S3: PRNG Math.sin defectuoso
- D1: Calendario ENRESA erróneo (Ascó II, Vandellós II)
- D2: "Tiempo real" estático
- D3: Tope ibérico arbitrario
- D4: CfD una sola cara
