---
name: STEM-INDEX
version: "1.0.0"
---

# Índice de Skills STEM

**Creado:** 2026-06-15  
**Total:** 10 skills en 3 bloques

---

## BLOQUE 1 — Matemáticas (4 skills)

| # | Skill | Contenido principal | Tamaño |
|---|-------|-------------------|--------|
| 1 | `skill-math-foundations` | Álgebra, Geometría, Trigonometría, Cálculo diferencial básico | 7.3 KB / 149 líneas |
| 2 | `skill-math-statistics` | Estadística descriptiva, Probabilidad, Distribuciones | 8.6 KB / 169 líneas |
| 3 | `skill-math-linear-algebra` | Vectores, Matrices, Espacios vectoriales, Autovalores, SVD/PCA | 11.6 KB / 234 líneas |
| 4 | `skill-math-calculus` | Derivadas avanzadas, Integrales, EDOs, Optimización multivariable | 13.5 KB / 281 líneas |

## BLOQUE 2 — Física y Química (3 skills)

| # | Skill | Contenido principal | Tamaño |
|---|-------|-------------------|--------|
| 5 | `skill-physics-mechanics` | Cinemática, Dinámica, Trabajo/Energía, Termodinámica | 7.3 KB / 174 líneas |
| 6 | `skill-physics-electromagnetism` | Electrostática, Magnetismo, Circuitos, Ondas EM | 10.5 KB / 230 líneas |
| 7 | `skill-chemistry-basics` | Estructura atómica, Tabla periódica, Enlaces, Estequiometría, Reacciones | 17.1 KB / 331 líneas |

## BLOQUE 3 — Biología y Ciencias de la Tierra (3 skills)

| # | Skill | Contenido principal | Tamaño |
|---|-------|-------------------|--------|
| 8 | `skill-biology-cell` | Biología celular, Genética, Evolución, Ecología | 14.7 KB / 168 líneas |
| 9 | `skill-earth-sciences` | Geología, Meteorología, Oceanografía, Climatología | 24.6 KB / 265 líneas |
| 10 | `skill-scientific-method` | Método científico, Diseño experimental, Análisis de datos, Comunicación | 21.6 KB / 270 líneas |

---

## Resumen

- **Total de archivos creados:** 10
- **Tamaño total:** ~117 KB
- **Total de líneas:** 2,071
- **Idioma:** Español
- **Formato:** YAML frontmatter + Markdown

Todos los skills son autocontenidos, con instrucciones detalladas, ejemplos de uso y referencias académicas.
