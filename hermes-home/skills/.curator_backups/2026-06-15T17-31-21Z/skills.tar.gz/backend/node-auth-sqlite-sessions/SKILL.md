---
name: node-auth-sqlite-sessions
description: "Patrón completo de autenticación web con Node.js + SQLite + bcrypt + sesiones HTTP — registro, login, logout, middleware, y esquema de BD relacional."
version: 1.0.0
author: Ntizar
tags: [backend, auth, node, sqlite, bcrypt, sessions]

---

# Autenticación web con Node.js + SQLite + bcrypt + sesiones

Patrón para añadir registro de usuarios, login con contraseña hasheada, y sesiones persistentes a proyectos Node.js con Express y SQLite.

## Dependencias

```bash
npm install bcryptjs express-session cookie-parser
```

- **bcryptjs** — hasheo de contraseñas (pure JS, no necesita compilación nativa)
- **express-session** — sesiones del lado del servidor
- **cookie-parser** — parseo de cookies (necesario para session)

## Esquema de base de datos

```sql
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  display_name TEXT DEFAULT '',
  country_code TEXT DEFAULT 'default',
  is_admin INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS sessions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  token TEXT UNIQUE NOT NULL,
  expires_at DATETIME NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ⚠️ CRÍTICO: Usar CREATE INDEX IF NOT EXISTS (no olvidar el IF NOT EXISTS)
CREATE INDEX IF NOT EXISTS idx_sessions_token ON sessions(token);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);
```

> **PITFALL:** `CREATE INDEX IF NOT EXISTS` — es fácil escribir `CREATE INDEX IF NOT` (sin `EXISTS`) y SQLite lanza `SQLITE_ERROR`. Siempre verificar la sintaxis.

## Middleware de sesión

```javascript
const session = require('express-session');
const cookieParser = require('cookie-parser');

const SESSION_SECRET = process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex');

app.use(cookieParser());
app.use(session({
  secret: SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: 7 * 24 * 60 * 60 * 1000, // 7 días
  }
}));
```

## Middleware de autenticación

```javascript
// Proteger rutas (devuelve 401 si no hay sesión)
function requireAuth(req, res, next) {
  if (!req.session.userId) {
    return res.status(401).json({ error: 'No autenticado' });
  }
  next();
}

// Opcional: deja req.user si hay sesión, no bloquea
function optionalAuth(req, res, next) {
  if (req.session.userId) {
    const user = db.prepare('SELECT id, username, email, display_name, country_code, is_admin FROM users WHERE id = ?').get(req.session.userId);
    req.user = user || null;
  }
  next();
}
```

## Rutas de autenticación

### POST /api/auth/register

```javascript
app.post('/api/auth/register', async (req, res) => {
  try {
    const { username, email, password, displayName, countryCode } = req.body;

    // Validaciones
    if (!username || !email || !password) {
      return res.status(400).json({ error: 'Faltan campos obligatorios' });
    }
    if (username.length < 3 || username.length > 30) {
      return res.status(400).json({ error: 'El username debe tener entre 3 y 30 caracteres' });
    }
    if (!/^[a-zA-Z0-9_]+$/.test(username)) {
      return res.status(400).json({ error: 'El username solo puede contener letras, números y guión bajo' });
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return res.status(400).json({ error: 'Email no válido' });
    }
    if (password.length < 6) {
      return res.status(400).json({ error: 'La contraseña debe tener al menos 6 caracteres' });
    }

    // Comprobar duplicados
    const existing = db.prepare('SELECT id FROM users WHERE username = ? OR email = ?').get(username, email);
    if (existing) {
      return res.status(409).json({ error: 'El username o email ya está registrado' });
    }

    const hash = await bcrypt.hash(password, 10);
    const result = db.prepare(
      'INSERT INTO users (username, email, password_hash, display_name, country_code) VALUES (?, ?, ?, ?, ?)'
    ).run(username, email, hash, displayName || '', countryCode || 'default');

    // Crear sesión automáticamente tras registro
    req.session.userId = result.lastInsertRowid;

    res.json({
      ok: true,
      user: {
        id: result.lastInsertRowid,
        username,
        email,
        displayName: displayName || '',
        countryCode: countryCode || 'default',
      }
    });
  } catch (err) {
    console.error('[REGISTER ERROR]', err);
    res.status(500).json({ error: 'Error al registrar' });
  }
});
```

### POST /api/auth/login

```javascript
app.post('/api/auth/login', async (req, res) => {
  try {
    const { login, password } = req.body; // login = username o email

    if (!login || !password) {
      return res.status(400).json({ error: 'Faltan campos' });
    }

    const user = db.prepare(
      'SELECT id, username, email, password_hash, display_name, country_code, is_admin FROM users WHERE username = ? OR email = ?'
    ).get(login, login);

    if (!user) {
      return res.status(401).json({ error: 'Credenciales incorrectas' });
    }

    const match = await bcrypt.compare(password, user.password_hash);
    if (!match) {
      return res.status(401).json({ error: 'Credenciales incorrectas' });
    }

    req.session.userId = user.id;

    res.json({
      ok: true,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        displayName: user.display_name,
        countryCode: user.country_code,
        isAdmin: !!user.is_admin,
      }
    });
  } catch (err) {
    console.error('[LOGIN ERROR]', err);
    res.status(500).json({ error: 'Error al iniciar sesión' });
  }
});
```

### POST /api/auth/logout

```javascript
app.post('/api/auth/logout', (req, res) => {
  req.session.destroy();
  res.json({ ok: true });
});
```

### GET /api/auth/me

```javascript
app.get('/api/auth/me', optionalAuth, (req, res) => {
  if (!req.user) {
    return res.json({ authenticated: false });
  }
  res.json({
    authenticated: true,
    user: req.user,
  });
});
```

## Frontend: formularios de auth

### HTML (tabs login/register)

```html
<div class="auth-tabs">
  <button class="auth-tab active" data-tab="login">Iniciar sesión</button>
  <button class="auth-tab" data-tab="register">Registrarse</button>
</div>

<div class="auth-form auth-form--active" id="auth-form-login">
  <input type="text" id="login-email" placeholder="Usuario o email">
  <input type="password" id="login-password" placeholder="Contraseña">
  <button id="auth-login-btn">Entrar</button>
</div>

<div class="auth-form" id="auth-form-register">
  <input type="text" id="reg-username" placeholder="Nombre de usuario">
  <input type="email" id="reg-email" placeholder="Email">
  <input type="password" id="reg-password" placeholder="Contraseña (mín. 6 caracteres)">
  <button id="auth-register-btn">Crear cuenta</button>
</div>
```

### JS: tabs + fetch

```javascript
// Tabs
document.querySelectorAll('.auth-tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
    tab.classList.add('active');
    document.querySelectorAll('.auth-form').forEach(f => f.classList.remove('auth-form--active'));
    document.getElementById('auth-form-' + tab.dataset.tab).classList.add('auth-form--active');
  });
});

// Register
document.getElementById('auth-register-btn').addEventListener('click', async () => {
  const username = document.getElementById('reg-username').value.trim();
  const email = document.getElementById('reg-email').value.trim();
  const password = document.getElementById('reg-password').value;

  const res = await fetch('/api/auth/register', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, email, password }),
  });
  const data = await res.json();
  if (data.ok) {
    // Usuario registrado y con sesión iniciada
    currentUser = data.user;
    // Ocultar formularios, mostrar info de usuario
  }
});

// Login
document.getElementById('auth-login-btn').addEventListener('click', async () => {
  const login = document.getElementById('login-email').value.trim();
  const password = document.getElementById('login-password').value;

  const res = await fetch('/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ login, password }),
  });
  const data = await res.json();
  if (data.ok) {
    currentUser = data.user;
  }
});

// Check session on load
fetch('/api/auth/me')
  .then(r => r.json())
  .then(data => {
    if (data.authenticated) {
      currentUser = data.user;
    }
  });
```

## Pitfalls

1. **`CREATE INDEX IF NOT EXISTS`** — el typo `IF NOT` (sin `EXISTS`) causa `SQLITE_ERROR` silencioso. El server crashea al arrancar.
2. **bcryptjs vs bcrypt** — usar `bcryptjs` (pure JS) en entornos donde no se pueda compilar módulos nativos (alpine, NaN.builders). `bcrypt` requiere compilación C++.
3. **`npm ci` necesita package-lock.json sincronizado** — si añades nuevas dependencias, regenera el lockfile con `npm install` antes de commit. Si no, el build en producción falla.
4. **Sesiones en producción** — `secure: true` requiere HTTPS. NaN.builders ya sirve HTTPS, así que en producción usar `secure: process.env.NODE_ENV === 'production'`.
5. **No exponer el hash en respuestas** — nunca devolver `password_hash` al frontend. Seleccionar solo los campos necesarios.
6. **Validación en servidor y cliente** — las validaciones del frontend son cosmeticas; las del servidor son las que importan.