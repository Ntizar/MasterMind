---
name: node-sqlite-fullstack-app
description: "Guía completa para crear o migrar aplicaciones Node.js/Express a SQLite (sql.js) con auth simplificada (single-user o token) y frontend reestructurado."
version: 1.1.0
author: Mastermind
tags:
  - nodejs
  - express
  - sqlite
  - sql.js
  - authentication
  - migration
  - frontend-restructure
related_skills:
  - esios-nan-deploy
  - frontend-dashboard-patterns
---

# Node.js + SQLite Fullstack App

Patrón completo para construir aplicaciones web con Express, SQLite (vía `sql.js` para compatibilidad con contenedores sin binarios nativos) y un frontend moderno reestructurado.

## 1. Backend: SQLite con sql.js

En contenedores Docker (como NaN.builders) o entornos restringidos, `better-sqlite3` a veces falla por la compilación nativa. `sql.js` es la alternativa segura (SQLite en WASM puro JS).

### Patrón de inicialización
```javascript
const initSqlJs = require('sql.js');
let db = null;

async function initDB() {
  const SQL = await initSqlJs();
  const dbExists = fs.existsSync(DB_PATH);
  db = new SQL.Database(dbExists ? fs.readFileSync(DB_PATH) : null);
  
  // Crear tablas con CREATE TABLE IF NOT EXISTS
  db.run(`CREATE TABLE IF NOT EXISTS usuarios (...)`);
  
  // Migración desde JSON si es primera vez
  if (!dbExists && fs.existsSync(JSON_FALLBACK)) {
    await migrateFromJSON();
  }
  saveDB();
}

function saveDB() {
  const data = db.export();
  fs.writeFileSync(DB_PATH, Buffer.from(data));
}
```

### Helper Functions (CRÍTICO)
En `sql.js`, `db.prepare().run()` **NO acepta argumentos sueltos**, solo arrays. Para evitar errores, crea helpers:

```javascript
function sql_get(sql, params) {
  const stmt = db.prepare(sql);
  if (params) stmt.bind(params);
  let result = null;
  if (stmt.step()) {
    result = {};
    const cols = stmt.getColumnNames();
    const vals = stmt.get();
    cols.forEach((c, i) => result[c] = vals[i]);
  }
  stmt.free();
  return result;
}

function sql_run(sql, params) {
  db.run(sql, params || []);
}
```

**Pitfall:** `stmt.run(arg1, arg2)` falla silenciosamente o da `NOT NULL constraint`. Usa siempre `stmt.run([arg1, arg2])` o los helpers anteriores.

## 2. Auth: Nombre simple (Single-User)

Para apps personales donde no se necesita contraseña compleja, se puede usar solo el nombre como identificador.

### Lógica de Login
```javascript
app.post('/api/auth/login', (req, res) => {
  const { nombre } = req.body;
  let user = sql_get('SELECT id FROM usuarios WHERE nombre = ?', [nombre]);
  const count = sql_get('SELECT COUNT(*) as c FROM usuarios');
  
  if (!user && count.c >= 1) {
    return res.status(403).json({ error: 'Ya hay un usuario. Pon tu nombre exacto.' });
  }
  
  if (!user) {
    sql_run('INSERT INTO usuarios (nombre) VALUES (?)', [nombre]);
    // Obtener ID insertado
    const newId = db.exec('SELECT last_insert_rowid()')[0].values[0][0];
    user = { id: newId, nombre };
  }
  
  // Crear sesión (token de 7 días)
  const token = crypto.randomBytes(32).toString('hex');
  // ...
});
```

## 3. Frontend: Reestructuración por Prioridades

Cuando una app tiene demasiadas funciones (como 7 tabs), reestructurar en 3 tabs principales + overflow menu.

### Patrón de Navegación
1. **Registrar** — Acción rápida (el 80% del uso diario)
2. **Coach/IA** — Interacción principal (chat WhatsApp-style)
3. **Dashboard/Proyecciones** — Visualización de datos
4. **☰ Más** — Resumen, Historial, Progreso, Exportar, Config

### Implementación del "☰ Más"

```html
<!-- Tabs principales siempre visibles -->
<div class="tabs">
  <button class="active" data-tab="registrar">Registrar</button>
  <button data-tab="coach">Coach IA</button>
  <button data-tab="proyecciones">Proyecciones</button>
  <button class="menu-toggle" onclick="toggleMenu()">☰ Más</button>
</div>

<!-- Menú overlay para tabs secundarios -->
<div id="moreMenu" class="menu-overlay hidden">
  <button data-tab="resumen">Resumen del día</button>
  <button data-tab="historial">Historial</button>
  <button data-tab="progreso">Progreso</button>
  <button data-tab="exportar">Exportar</button>
  <button data-tab="config">Configuración</button>
</div>
```

**Pitfall:** Los tabs del menú "Más" son lazy-loaded — NO ejecutar `loadXxx()` al inicio. Solo cargar datos cuando el usuario hace click en ese tab. Si cargas todo al arrancar, la app se siente lenta.

### Persistencia de Sesión
Almacenar `sessionId` en `localStorage` y añadirlo a todas las llamadas fetch:
```javascript
headers: { 'X-Session-Id': localStorage.getItem('session_id') }
```

## 4. NaN Builders: Persistencia de Datos

Los contenedores en NaN pierden el filesystem al redeploy. 

### Patrón de Backup (GitHub Contents API)
Sincronizar la base de datos (binario) a GitHub tras cada mutación:
```javascript
async function syncGitHub() {
  const token = getGithubToken();
  const dbData = fs.readFileSync(DB_PATH);
  const b64 = dbData.toString('base64');
  // ... lógica de PUT a GitHub API ...
}
```
Añadir `syncGitHub()` al final de cada endpoint POST/PUT/DELETE.

## 5. Dockerfile para sql.js

```dockerfile
FROM node:20-alpine
WORKDIR /app
COPY package.json package-lock.json ./
RUN npm ci --omit=dev
COPY . .
RUN addgroup -S appgroup && adduser -S appuser -G appgroup
RUN chown -R appuser:appgroup /app
USER appuser
EXPOSE 5050
HEALTHCHECK --interval=30s --timeout=5s CMD wget -qO- http://localhost:5050/healthz || exit 1
CMD ["node", "server.js"]
```
Asegúrate de que `package-lock.json` esté en el repo (quitar de `.gitignore`).

## 6. Bug Patterns Comunes (MasterFit v4 Audit)

Estos bugs aparecen SISTEMÁTICAMENTE en apps Node+HTML+SQLite:

### Key Mismatch entre SQL y Frontend
Cuando el schema usa español (`rol`, `contenido`) pero el frontend usa inglés (`role`, `content`), el chat/historial aparece vacío.
```sql
-- ❌ MALO: el frontend no encuentra "rol"
SELECT rol, contenido FROM chat_mensajes WHERE usuario_id = ?
-- ✅ BUENO: alias en SQL
SELECT rol AS role, contenido AS content FROM chat_mensajes WHERE usuario_id = ?
```

### Singular vs Plural en DELETE
El frontend envía `comida` pero el backend espera `comidas`. Fix: mapear ambos en ALLOWED.
```javascript
const ALLOWED = { 
  peso:'peso', 
  comida:'comidas', comidas:'comidas',        // singular + plural
  entrenamiento:'entrenamientos', entrenamientos:'entrenamientos',  // singular + plural
  pasos:'pasos', agua:'agua' 
};
```

### Variables undefined en funciones de render
Una función `renderResumen()` usa `perfil` pero la variable real se llama `perfilData` en ese scope. Causa: ReferenceError → pestaña rota.
**Pitfall:** Cuando extrajes datos de `appState.datos`, verifica que el nombre de variable en cada función coincide con el destructuring local.

### JSON.parse sin try-catch
```javascript
// ❌ MALO: datos corruptos → 500
const items = rows.map(r => JSON.parse(r.data));
// ✅ BUENO
const items = rows.map(r => { try { return JSON.parse(r.data); } catch(e) { return null; } }).filter(Boolean);
```

### XSS en Chat/Markdown
`formatMarkdown()` convierte `**bold**` a HTML pero NO escapa el input primero. Un mensaje con `<script>` se ejecuta.
```javascript
// ❌ MALO
formatMarkdown(m.content)
// ✅ BUENO: escapeHtml ANTES de markdown
formatMarkdown(escapeHtml(stripThink(m.content)))
```

### initDB() sin mkdirSync
En deploys nuevos (Docker, NaN), la carpeta `data/` no existe y `fs.readFileSync(DB_PATH)` falla.
```javascript
async function initDB() {
  const SQL = await initSqlJs();
  const dataDir = path.dirname(DB_PATH);
  if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
  // ...
}
```

### SQL Injection en PUT dinámico
```javascript
// ❌ MALO: columnas de user input directo a SQL
db.run(`UPDATE ${table} SET ${col} = ? WHERE id = ?`, [val, id]);
// ✅ BUENO: whitelist por tabla
const ALLOWED_COLS = { peso:['peso_kg','fecha'], comidas:['kcal','proteinas_g',...] };
if (!ALLOWED_COLS[table]?.includes(col)) return res.status(400).json({error:'Columna no válida'});
```
