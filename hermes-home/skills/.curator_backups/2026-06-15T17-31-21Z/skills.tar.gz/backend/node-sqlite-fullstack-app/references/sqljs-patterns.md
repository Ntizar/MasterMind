# SQL.js Pitfalls and Patterns

`sql.js` is a WebAssembly port of SQLite. While it works everywhere (including restricted containers), it has some specific quirks compared to native bindings like `better-sqlite3`.

## 1. Parameter Binding (The #1 Pitfall)
`db.prepare(sql).run(param1, param2)` **DOES NOT WORK** correctly in `sql.js`. It often ignores the parameters or throws a `NOT NULL constraint failed` error because the parameters aren't bound.

**Solution:** Always use an array or a helper function.
```javascript
// ❌ WRONG
db.prepare('INSERT INTO users (name) VALUES (?)').run(userName);

// ✅ CORRECT
db.prepare('INSERT INTO users (name) VALUES (?)').run([userName]);
// OR use a helper
sql_run('INSERT INTO users (name) VALUES (?)', [userName]);
```

## 2. Getting the Last Inserted ID
`result.lastInsertRowid` is NOT available on the result of `db.run()`.

**Solution:** Query `last_insert_rowid()` manually.
```javascript
db.prepare('INSERT INTO users (name) VALUES (?)').run([userName]);
const userId = db.exec('SELECT last_insert_rowid()')[0].values[0][0];
```

## 3. Memory Management
If you use `db.prepare()`, the statement is not automatically freed, which can lead to memory leaks in long-running servers.

**Solution:** Always call `.free()` on prepared statements if you are manually stepping through them.
```javascript
const stmt = db.prepare('SELECT * FROM users');
while (stmt.step()) { /* ... */ }
stmt.free();
```
*Note: The helper functions `sql_get` and `sql_all` provided in the `node-sqlite-fullstack-app` skill handle this automatically.*

## 4. Saving to Disk
Unlike `better-sqlite3`, `sql.js` doesn't save automatically. You must manually export the database to a buffer and write it to disk after mutations.

```javascript
function saveDB() {
  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(DB_PATH, buffer);
}
```
Call this after every `INSERT`, `UPDATE`, or `DELETE` operation.
