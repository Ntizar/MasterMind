# Aurora Nightly — Configuración Actual

> **Última actualización:** 2026-05-29

## Cron Jobs Activos

| Job ID | Nombre | Schedule | Función |
|---|---|---|---|
| `47211a1f30f9` | Aurora Mejora Nocturna #1 — Investigación Web | `0 1 * * *` | Investigación web de tendencias |
| `eaa6b95a12a6` | Aurora Mejora Nocturna #2 — Mejora CSS #1 | `0 2 * * *` | Análisis gap + mejora #1 |
| `202bc3725ab2` | Aurora Mejora Nocturna #3 — Mejora CSS #2 | `0 3 * * *` | Mejora #2 |
| `5e476d3f015d` | Aurora Mejora Nocturna #4 — Mejora CSS #3 + Reaprendizaje | `0 4 * * *` | Mejora #3 + resumen |

## Estado del Repo

- **Repo:** `/root/workspace/Ntizar-Aurora`
- **CDN:** `https://cdn.jsdelivr.net/gh/Ntizar/Ntizar-Aurora@master/`
- **Último commit base:** `83f7782` (chore: iniciar sistema de mejora continua nocturna)
- **Logs:** `nightly/` directory con `README.md`, `iteration-log.md`

## Skill

- **Skill principal:** `aurora-nightly` en `/hermes-home/skills/aurora-nightly/SKILL.md`
- **Skill relacionada:** `liquid-glass-css` (patrones de diseño Aurora)

## Notas

- Git auth: token HTTPS via `credential.helper=store`
- User: `Mastermind <mastermind@ntizar.com>`
- TODO en castellano en commits y logs
