---
name: deploy-audit-nan
version: "1.0.0"
description: Procedimiento sistemático para auditar y verificar despliegues en NaN.builders — comparar local vs remoto, verificar integridad HTML, git sync y endpoints.
---

# Deploy Audit — Verificación de despliegues NaN.builders

## Trigger

Antes de cualquier deploy manual o tras un deploy automático en NaN.builders, ejecutar esta auditoría para verificar integridad.

## Pasos

1. **Descargar deploy y local:**
   ```bash
   curl -s -o /tmp/deploy-check.html https://<nan-url>/
   cp path/to/deployed.html /tmp/local-check.html
   ```

2. **Comparar tamaño (quick check):**
   ```bash
   wc -c /tmp/local-check.html /tmp/deploy-check.html
   ```
   Tamaños idénticos → probable sync correcto. Si difieren → `diff` obligatorio.

3. **Comparar contenido (definitivo):**
   ```bash
   diff /tmp/local-check.html /tmp/deploy-check.html
   ```
   Sin output → archivos idénticos. Con output → hay discrepancias.

4. **Verificar integridad HTML (grep -c por elemento clave):**
   ```bash
   # Verificar funciones principales
   grep -c "function loadData" dashboard.html
   grep -c "function renderDashboard" dashboard.html
   # Verificar hero elements
   grep -c "heroPeso" dashboard.html
   grep -c "heroPerdido" dashboard.html
   grep -c "heroRitmo" dashboard.html
   # Verificar navegación
   grep -c "switchTab" dashboard.html
   grep -c "tab-registrar" dashboard.html
   # Verificar display:none en tabs
   grep -c "display.*none" dashboard.html
   # Verificar código residual no deseado
   grep -ni "dark.*mode\|@media.*prefers-color\|dark-theme" dashboard.html
   ```
   Cada grep debe devolver >0. Si devuelve 0 → elemento faltante.

5. **Verificar deploy tiene mismos elementos:**
   Repetir los mismos `grep -c` sobre `/tmp/deploy-check.html`.

6. **Verificar git status:**
   ```bash
   git status  # debe estar clean o con cambios intencionales
   git log --oneline -5  # verificar últimos commits
   ```

7. **Si hay discrepancias (local != deploy):**
   ```bash
   git add . && git commit -m "fix: sync deploy"
   git pull --rebase && git push
   ```
   Esperar a que el deploy se actualice (1-2 min en NaN).

8. **Verificar endpoints secundarios:**
   ```bash
   curl -s -o /dev/null -w "%{http_code}" https://<nan-url>/data/database.json
   ```

## Checklist de integridad HTML

Para proyectos dashboard con tabs y hero:
- [ ] `loadData()` definida y llamada
- [ ] `renderDashboard()` definida
- [ ] Hero quick status (heroPeso, heroPerdido, heroRitmo)
- [ ] Botones de acción rápida con `switchTab`
- [ ] Tabs con `display:none` excepto tab activo
- [ ] Sin código de dark mode residual
- [ ] Sin código de debug (console.log masivo, alert())

## Pitfalls

- **NaN bloquea curl desde ciertas IPs:** si curl da 403, no significa que el deploy esté roto. Verificar desde el navegador o usar `curl -A "Mozilla"` para bypass.
- **Tamaños iguales ≠ contenido idéntico:** en HTML con timestamps o hashes, los tamaños pueden coincidir pero el contenido diferir. Usar `diff` para certeza.
- **express.static y .json:** `express.static(__dirname)` sirve archivos JSON, pero el 403 desde curl externo puede ser por permisos o configuración de NaN, no por el servidor.

## Reglas

- NO borrar nada del repo
- Si algo está bien, no tocarlo
- Si hay problema → fixear y re-deploy
- Registrar auditoría en `notes/auditoria-YYYY-MM-DD.md`

## Scripts

- `scripts/audit-html.sh` — Script de verificación rápida de integridad HTML.
  Uso: `bash scripts/audit-html.sh dashboard.html`
  Verifica automáticamente: loadData, renderDashboard, hero elements, switchTab,
  display:none en tabs, y código residual (dark mode, debug).
