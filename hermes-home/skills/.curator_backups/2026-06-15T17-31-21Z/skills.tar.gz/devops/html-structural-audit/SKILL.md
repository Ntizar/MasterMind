---
name: html-structural-audit
version: "1.0.0"
created: 2026-06-12
description: Audit and fix structural integrity of batch HTML files — CSS braces, div balance, style tags.
---

# HTML Structural Audit & Fix

## When to use

After generating, editing, or deploying a batch of HTML files (education projects, dashboards, docs sites). Also run before deploying if files were auto-generated or edited by AI agents.

## What it catches

1. **CSS braces mismatch** — `{` vs `}` count in `<style>` blocks. Even one extra `}` breaks all CSS after it.
2. **Unbalanced `<div>` tags** — open `<div>` vs closing `</div>`. Imbalance > 3 usually means layout breakage.
3. **Unclosed `<style>` tags** — `<style>` without matching `</style>`.

## Procedure

### Quick audit (recommended)

Copy the script to your project and run:

```bash
cp /hermes-home/skills/devops/html-structural-audit/scripts/audit.py .
python3 audit.py /path/to/html-dir
python3 audit.py /path/to/html-dir --fix   # auto-fix
```

### Inline audit (execute_code)

If you can't write files, run inline:

```python
import os, re

html_dir = "/path/to/html-dir"
html_files = [f for f in os.listdir(html_dir) if f.endswith('.html')]

for f in sorted(html_files):
    path = os.path.join(html_dir, f)
    with open(path, 'r') as fh:
        content = fh.read()
    
    issues = []
    
    # CSS braces
    css_start = content.find('<style>')
    css_end = content.find('</style>')
    if css_start >= 0 and css_end >= 0:
        css = content[css_start+7:css_end]
        if css.count('{') != css.count('}'):
            issues.append(f"CSS braces: {css.count('{')} open, {css.count('}')} close")
    
    # Divs
    div_open = len(re.findall(r'<div(?:\s[^>]*)?>', content))
    div_close = content.count('</div>')
    if abs(div_open - div_close) > 3:
        issues.append(f"divs: {div_open} open, {div_close} close")
    
    # Style tags
    if content.count('<style>') != content.count('</style>'):
        issues.append("unclosed <style>")
    
    if issues:
        print(f"❌ {f}: {'; '.join(issues)}")
    else:
        print(f"✅ {f}")
```

### Step 2: Fix CSS braces

If CSS braces are unbalanced, find the line where the balance goes negative and remove the stray `}`:

```python
css_start = content.find('<style>')
css_end = content.find('</style>')
css = content[css_start+7:css_end]
lines = css.split('\n')
balance = 0
bad_line = -1
for i, line in enumerate(lines):
    balance += line.count('{') - line.count('}')
    if balance < 0:
        bad_line = i
        break
if bad_line >= 0:
    lines[bad_line] = lines[bad_line].replace('}', '', 1)
    new_css = '\n'.join(lines)
    content = content[:css_start+7] + new_css + content[css_end:]
```

### Step 3: Fix unclosed style tags

```python
if content.count('<style>') > content.count('</style>'):
    style_close_pos = content.find('</style>')
    if style_close_pos > 0:
        content = content[:style_close_pos+8] + '</style>' + content[style_close_pos+8:]
```

### Step 4: Fix unbalanced divs

If `</div>` count < `<div` count by 1-6, append missing `</div>` before `</main>`:

```python
div_open = len(re.findall(r'<div(?:\s[^>]*)?>', content))
div_close = content.count('</div>')
missing = div_open - div_close
if 0 < missing <= 6:
    main_end = content.find('</main>')
    if main_end > 0:
        content = content[:main_end] + '</div>' * missing + content[main_end:]
```

## Pitfalls

- **Don't fix divs with imbalance > 6** — that's a structural problem, not a stray tag. Investigate manually.
- **Primaria files often use different class names** (`teoria`, `ejemplo`, `card`) — the CSS-brace check still applies but the div structure may be intentionally different.
- **Files > 20KB** should NOT be rewritten with `write_file`. Use `patch()` or Python `.replace()` in `execute_code`.
- **GitHub Pages caches aggressively** — after fixing, commit and push. If the web still looks broken, wait for Cloudflare cache purge (or force with `?v=` query param).

## Verification

After fixes, re-run the audit. All files should show `✅`.

## Related

- `aurora-nightly-pipeline` — nightly improvement pipeline for HTML projects
- `single-page-app-audit` — systematic audit of individual HTML apps
- `safe-refactoring-checklist` — safe refactoring procedure
