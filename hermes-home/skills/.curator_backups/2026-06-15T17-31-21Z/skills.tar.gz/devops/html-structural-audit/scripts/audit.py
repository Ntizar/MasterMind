#!/usr/bin/env python3
"""HTML Structural Audit — batch check CSS braces, div balance, style tags."""
import os
import re
import sys
import argparse

def audit_file(path):
    with open(path, 'r') as f:
        content = f.read()
    
    issues = []
    
    # CSS braces
    css_start = content.find('<style>')
    css_end = content.find('</style>')
    if css_start >= 0 and css_end >= 0:
        css = content[css_start+7:css_end]
        if css.count('{') != css.count('}'):
            issues.append(f"CSS braces: {css.count('{')} open, {css.count('}')} close")
    
    # Divs
    div_open = len(re.findall(r'<div(?:\s[^>]*)?>', content))
    div_close = content.count('</div>')
    if abs(div_open - div_close) > 3:
        issues.append(f"divs: {div_open} open, {div_close} close")
    
    # Style tags
    if content.count('<style>') != content.count('</style>'):
        issues.append("unclosed <style>")
    
    return issues

def main():
    parser = argparse.ArgumentParser(description='Audit HTML structural integrity')
    parser.add_argument('directory', help='Directory containing HTML files')
    parser.add_argument('--fix', action='store_true', help='Auto-fix issues')
    args = parser.parse_args()
    
    html_dir = args.directory
    if not os.path.isdir(html_dir):
        print(f"❌ {html_dir} is not a directory")
        sys.exit(1)
    
    html_files = [f for f in os.listdir(html_dir) if f.endswith('.html')]
    broken = 0
    fixed = 0
    
    for f in sorted(html_files):
        path = os.path.join(html_dir, f)
        issues = audit_file(path)
        
        if issues:
            broken += 1
            print(f"❌ {f}: {'; '.join(issues)}")
            
            if args.fix:
                with open(path, 'r') as fh:
                    content = fh.read()
                
                # Fix CSS braces
                css_start = content.find('<style>')
                css_end = content.find('</style>')
                if css_start >= 0 and css_end >= 0:
                    css = content[css_start+7:css_end]
                    if css.count('{') != css.count('}'):
                        lines = css.split('\n')
                        balance = 0
                        bad_line = -1
                        for i, line in enumerate(lines):
                            balance += line.count('{') - line.count('}')
                            if balance < 0:
                                bad_line = i
                                break
                        if bad_line >= 0:
                            lines[bad_line] = lines[bad_line].replace('}', '', 1)
                            new_css = '\n'.join(lines)
                            content = content[:css_start+7] + new_css + content[css_end:]
                
                # Fix unbalanced divs
                div_open = len(re.findall(r'<div(?:\s[^>]*)?>', content))
                div_close = content.count('</div>')
                missing = div_open - div_close
                if 0 < missing <= 6:
                    main_end = content.find('</main>')
                    if main_end > 0:
                        content = content[:main_end] + '</div>' * missing + content[main_end:]
                
                with open(path, 'w') as fh:
                    fh.write(content)
                fixed += 1
                print(f"   🔧 Auto-fixed")
        else:
            print(f"✅ {f}")
    
    print(f"\n📊 Results: {broken} broken, {fixed} auto-fixed, {len(html_files)-broken} OK")
    sys.exit(1 if broken > 0 else 0)

if __name__ == '__main__':
    main()
