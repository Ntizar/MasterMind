---
name: inventario-apis
description: "Leer y resumir el inventario de APIs procesado en /tmp/inventario-apis/. Incluye parsing de estado.json, resumen por categorías, progreso global, y actividad reciente."
version: 1.0.0
author: Hermes Agent
tags: [inventario, apis, resumen, cron, devops]
---

# Inventario de APIs — Lectura y Resumen

Procedimiento para leer y generar resúmenes del inventario de APIs almacenado en `/tmp/inventario-apis/`.

## Estructura del directorio

```
/tmp/inventario-apis/
├── estado.json          # Archivo maestro con métricas globales
├── README.md            # Resumen por categorías (markdown)
├── automatizacion/      # Subdirectorios por categoría
│   ├── README.md
│   └── <api-name>/      # Una carpeta por API
├── ia/
├── agentes-ia/
└── ...
```

## Lectura de estado.json

`estado.json` es la fuente de verdad. Estructura:

```json
{
  "version": "1.0",
  "creado": "2026-05-26",
  "fuente": "https://github.com/cporter202/API-mega-list",
  "total_estimado": 10498,
  "procesadas": 1744,
  "categorias": {
    "automatizacion": {
      "nombre": "Automatización",
      "total": 4825,
      "procesadas": 259,
      "ultima_actualizacion": "2026-06-07 21:40"
    }
  },
  "api_procesadas": ["API 1", "API 2", ...]
}
```

### Pasos para leer

1. **Leer estado.json** con `json.load()` en Python
2. **Extraer métricas globales**: `total_estimado`, `procesadas`, `categorias`
3. **Calcular progreso**: `procesadas / total_estimado * 100`
4. **Clasificar categorías**:
   - `>90%` → completadas
   - `50-90%` → en avance
   - `1-50%` → en progreso
   - `0%` → pendientes
5. **Filtrar actividad reciente**: buscar `ultima_actualizacion` que coincida con la fecha objetivo

### Código de referencia

Ver `references/lectura-estado.py` para el script completo de parsing.

## Formato de resumen

El resumen debe incluir:
- **Progreso global**: X/Y APIs, Z% avance
- **Categorías completadas** (>90%): con emoji 🏆
- **Categorías en avance** (50-90%): con emoji 🟢
- **Categorías en progreso** (1-50%): con emoji 🟡
- **Categorías pendientes** (0%): lista con conteo total
- **Actividad del día**: categorías actualizadas hoy
- **Historial**: últimas 3 actualizaciones

## Pitfalls

- **README.md puede tener texto corrupto**: el conteo de APIs en el README puede incluir texto formateado que no son APIs reales. Siempre confiar en `estado.json` como fuente de verdad.
- **Categorías con total=0**: algunas categorías (Finanzas, Clima) tienen `total: 0` y deben omitirse en los cálculos.
- **Directorios vs archivos**: cada API es un subdirectorio en la carpeta de categoría, no un archivo JSON. No buscar JSONs dentro de las carpetas de categoría.
- **Estado no se actualiza automáticamente**: si se procesaron APIs nuevas en el directorio pero `estado.json` no se actualizó, las métricas estarán desfasadas.

## Procesamiento (procesar-apis.py)

Script en `/opt/hermes-work/inventario-apis/procesar-apis.py` que procesa el catálogo API-mega-list de forma progresiva (5 APIs por ejecución).

### Pitfalls críticos del script

- **Token de GitHub no en entorno**: El script NO encuentra `GITHUB_TOKEN` en el entorno cron. Debe leerlo desde `/opt/hermes-work/.env` o `/hermes-home/.env` buscando la línea `GITHUB_TOKEN=...`.
- **Remote URL no inyectada**: El token se construye en la URL pero no se inyecta en el remote. Antes del push, hacer `git remote set-url origin https://TOKEN@github.com/...`.
- **Conflictos de push por múltiples cron jobs**: Siempre hacer `git pull origin main --no-edit` ANTES del push. Si falla, hacer `git reset --hard origin/main` y reaplicar commits locales con cherry-pick (skipando duplicados).
- **Estado corrupto por merge/rebase fallido**: Si el repo queda en estado de rebase en curso (`git status` muestra "rebasing main"), hacer `git rebase --abort` primero. El `estado.json` puede corromperse por conflictos — restaurar con `git checkout origin/main -- estado.json`.
- **No usar `pull --rebase`**: Genera conflictos masivos con archivos duplicados (README.md, datos.json). Usar `pull` normal (merge).

### Ejecución

```bash
mkdir -p /tmp/inventario-apis && cd /tmp/inventario-apis && python3 /opt/hermes-work/inventario-apis/procesar-apis.py 5
```

### Pitfalls de ejecución

- **Directorio no existe en cron fresh**: `/tmp/inventario-apis` puede no existir en sesiones nuevas. Siempre hacer `mkdir -p` antes.
- **Repo git sin inicializar**: Si el script falla con `fatal: not a git repository`, inicializar con `git init`, configurar user.email/user.name, y añadir el remote: `git remote add origin https://TOKEN@github.com/Ntizar/inventario-apis.git`.
- **Rama sin push inicial**: Si el repo local tiene commits pero el remoto está vacío (push dice "up-to-date" pero no hay contenido), hacer `git branch -M main && git push -u origin main` manualmente la primera vez.
- **Token de GitHub en curl/clone**: El token NO se puede pasar como variable shell inyectada (causa timeout silencioso, exit code -1). Si necesitas interactuar con GitHub vía curl o git clone desde un script, lee el token directamente con `TOKEN=$(grep '^GITHUB_TOKEN=' /hermes-home/.env | cut -d= -f2-)` dentro del mismo comando. Nunca hagas `export GITHUB_TOKEN=...` y luego uses `$GITHUB_TOKEN` — falla silenciosamente.
- **Repo remoto puede no existir**: Si el repo no existe en GitHub, crearlo antes de clonar: `TOKEN=$(grep '^GITHUB_TOKEN=' /hermes-home/.env | cut -d= -f2-) && curl -s -u "$TOKEN:" -X POST -H "Accept: application/vnd.github+json" https://api.github.com/user/repos -d '{"name":"inventario-apis","description":"Catálogo de APIs procesado","private":false}'`

### Flujo de push seguro

1. `git fetch origin`
2. `git pull origin main --no-edit` (si falla → `git reset --hard origin/main` + cherry-pick commits locales)
3. `git push origin main`

## Referencias

- `references/lectura-estado.py` — Script Python de parsing completo de `estado.json` con clasificación por categorías y detección de actividad reciente.
- `references/api-mega-list.md` — Referencia del catálogo API-mega-list: origen, categorías, proceso de procesamiento.
