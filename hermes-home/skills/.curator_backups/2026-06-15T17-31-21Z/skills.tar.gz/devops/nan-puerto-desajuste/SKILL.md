---
name: nan-puerto-desajuste
description: "Diagnóstico y fix del error 502 en NaN.builders causado por desajuste de puertos entre Dockerfile, server.js y Container Port de NaN"
version: 1.0.0
author: Ntizar
tags: [nan, deploy, docker, 502, troubleshooting, puertos]
related_skills: [esios-nan-deploy, nan-pending-root-cause]
---

# NaN: Error 502 por desajuste de puertos

## Síntoma

- Build Kaniko **exitoso** (se ve en Build History)
- Contenedor aparece como **"Running"** en el overview
- URL devuelve **502 Bad Gateway** (Cloudflare dice "Host: Error")
- `/healthz` también da 502
- El contenedor puede estar en **crash loop** (se reinicia cada ~30s)

## Causa raíz

NaN.builders tiene **3 lugares donde se define el puerto**, y deben coincidir:

| Lugar | Dónde está | Ejemplo |
|---|---|---|
| **Container Port** | UI de NaN → Settings del espacio | `6060` |
| **`EXPOSE`** | `Dockerfile` | `EXPOSE 6060` |
| **`process.env.PORT`** | `server.js` | `const PORT = process.env.PORT \|\| 6060` |

**Mecanismo de fallo:**

1. NaN **inyecta automáticamente** `PORT=<container-port>` como variable de entorno al contenedor
2. Si el Container Port es `6060`, NaN pasa `PORT=6060`
3. El servidor escucha en el puerto que recibe de `process.env.PORT`
4. **El HEALTHCHECK del Dockerfile** debe apuntar al MISMO puerto
5. Si el HEALTHCHECK apunta a otro puerto (ej: `localhost:4040/healthz`), falla
6. NaN detecta el contenedor como **unhealthy** → lo mata → 502

## Diagnóstico rápido

```bash
# 1. Verificar Container Port en NaN (desde la UI)
#    Ir a cloud.nan.builders → espacio → Settings

# 2. Verificar EXPOSE en Dockerfile
grep EXPOSE Dockerfile

# 3. Verificar puerto por defecto en server.js
grep 'PORT' server.js

# 4. Verificar HEALTHCHECK
grep -A2 HEALTHCHECK Dockerfile

# 5. Probar healthcheck directamente
curl -s https://<app>.apps.nan.builders/healthz
# Si da 502 → problema de puertos o healthcheck
```

## Fix

### Opción A (recomendada) — Alinear todo al Container Port de NaN

```bash
# 1. Dockerfile: cambiar EXPOSE
EXPOSE 6060  # ← mismo que Container Port

# 2. Dockerfile: cambiar HEALTHCHECK
HEALTHCHECK --interval=30s --timeout=5s --start-period=10s --retries=3 \
  CMD wget -qO- http://localhost:6060/healthz || exit 1

# 3. server.js: cambiar default
const PORT = parseInt(process.env.PORT || '6060');
```

### Opción B — Escuchar en ambos puertos (tolerante a cambios)

Útil cuando no sabes exactamente qué puerto inyecta NaN, o para evitar problemas futuros si cambia:

```javascript
// server.js
const PORT = parseInt(process.env.PORT || '6060');
const FALLBACK_PORT = 4040; // Puerto legacy

// Al final del archivo
app.listen(PORT, '0.0.0.0', () => {
  console.log(`🔮 App → http://0.0.0.0:${PORT}`);
});
app.listen(FALLBACK_PORT, '0.0.0.0', () => {
  console.log(`   Fallback → http://0.0.0.0:${FALLBACK_PORT}`);
});
```

```dockerfile
# Dockerfile — HEALTHCHECK tolerante
HEALTHCHECK --interval=30s --timeout=5s --start-period=10s --retries=3 \
  CMD wget -qO- http://localhost:6060/healthz || wget -qO- http://localhost:4040/healthz || exit 1
```

### Opción C — Cambiar Container Port en NaN

Si no puedes modificar el código (ej: proyecto heredado que escucha en 4040):

1. Ir a [cloud.nan.builders](https://cloud.nan.builders)
2. Espacio → Settings → Container Port → cambiarlo a 4040
3. NaN redeploya automáticamente

## Healthcheck: regla de oro

El HEALTHCHECK del Dockerfile **NUNCA debe apuntar a un endpoint protegido por auth**.

```javascript
// ✅ BIEN — endpoint público ANTES del middleware de auth
app.get('/healthz', (req, res) => {
  res.json({ status: 'ok', uptime: process.uptime() });
});

// Middleware de auth SOLO para /api
app.use('/api', basicAuth);
```

```dockerfile
# ✅ BIEN — healthcheck a endpoint público
HEALTHCHECK --interval=30s --timeout=5s --start-period=10s --retries=3 \
  CMD wget -qO- http://localhost:6060/healthz || exit 1
```

## Cómo forzar redeploy en NaN

NaN **NO tiene webhooks de GitHub**. Usa **polling cada 1-5 minutos**.

Si necesitas redeploy inmediato:
1. **Opción 1:** Ir a [cloud.nan.builders](https://cloud.nan.builders) → espacio → botón **Redeploy**
2. **Opción 2:** Hacer un push a `main` y esperar el polling (1-5 min)
3. **Opción 3:** `git commit --allow-empty -m "trigger redeploy" && git push` (fuerza un nuevo commit que NaN detectará en su próximo ciclo)

## Pitfalls adicionales

- **🔴 NaN containers AISLADOS del host** — No es solo un problema de puertos. Los contenedores no pueden ver procesos, crons, skills, sessions ni archivos del host. `ps aux` solo muestra PID 1. `/proc` limitado. ChromaDB no accesible. **Solución general:** Sincronizar datos vía Git (ver skill `dashboard-control-center` sección "Arquitectura v2").
- **NaN inyecta `PORT=<container-port>` automáticamente** — no necesitas configurarlo en Env
- **`EXPOSE` en Dockerfile es informativo** para NaN, pero el valor real lo determina Container Port en la UI
- **Si cambias el Container Port en la UI**, NaN redeploya automáticamente con el nuevo puerto
- **El healthcheck se ejecuta cada 30s** — si falla 3 veces seguidas, NaN mata el contenedor
- **Síntoma de healthcheck fallando:** contenedor "Running" pero 502, y el uptime del contenedor se resetea cada ~30s

## Referencias

- Skill relacionado: `esios-nan-deploy` — procedimiento completo de deploy en NaN (incluye sección 29 sobre restricciones de contenedores)
- Skill relacionado: `nan-pending-root-cause` — cuando el contenedor se queda en Pending
- **Caso real:** `references/mastermind-dashboard-caso-real.md` — reproducción completa del error 502 en Mastermind Dashboard con comandos exactos y diff de los archivos modificados