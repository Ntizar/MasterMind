# Caso real: Mastermind Dashboard — error 502 por desajuste de puertos

**Fecha:** 2026-06-11
**Proyecto:** Mastermind Dashboard (`Ntizar/Mastermind-Dashboard`)
**URL:** `mastermind-dashboard-ntizar-ntizar.apps.nan.builders`

## Timeline del diagnóstico

1. **Síntoma inicial:** URL devuelve 502 Bad Gateway. Cloudflare dice "Host: Error". Build Kaniko exitoso (commit `9a4785c`), contenedor "Running".

2. **Primera hipótesis:** Healthcheck apunta a puerto equivocado. Se verifica:
   - Container Port en NaN UI = **6060**
   - Dockerfile `EXPOSE` = **4040** ❌
   - Dockerfile `HEALTHCHECK` = `localhost:4040/healthz` ❌
   - server.js `PORT` default = `'4040'` ❌

3. **Mecanismo de fallo confirmado:**
   - NaN inyecta `PORT=6060` automáticamente
   - Servidor escucha en 6060 (por `process.env.PORT`)
   - HEALTHCHECK busca en `localhost:4040/healthz` → falla
   - NaN detecta contenedor unhealthy → lo mata → 502

4. **Fix aplicado (commit `7cc17c4`):**
   - Dockerfile: `EXPOSE 4040` → `EXPOSE 6060`
   - Dockerfile: HEALTHCHECK tolerante a ambos puertos
   - server.js: default `'4040'` → `'6060'`, escucha en ambos puertos

5. **Resultado:** Tras ~3 min de polling de NaN, el contenedor redeployó y responde 200.

## Comandos usados en diagnóstico

```bash
# Verificar healthcheck
curl -s https://mastermind-dashboard-ntizar-ntizar.apps.nan.builders/healthz

# Verificar código HTTP
curl -s -o /dev/null -w "%{http_code}" https://mastermind-dashboard-ntizar-ntizar.apps.nan.builders/

# Verificar API con auth
curl -s -u 'admin:$Nan603060' https://mastermind-dashboard-ntizar-ntizar.apps.nan.builders/api/system

# Verificar TLS y conectividad
curl -sv https://mastermind-dashboard-ntizar-ntizar.apps.nan.builders/ 2>&1 | head -40

# Esperar redeploy con polling
for i in $(seq 1 20); do
  code=$(curl -s -o /dev/null -w "%{http_code}" https://.../healthz)
  echo "[$((i*15))s] $code"
  [ "$code" = "200" ] && break
  sleep 15
done
```

## Archivos modificados

### Dockerfile (antes → después)
```diff
-EXPOSE 4040
+EXPOSE 6060

-HEALTHCHECK ... CMD wget -qO- http://localhost:4040/healthz || exit 1
+HEALTHCHECK ... CMD wget -qO- http://localhost:6060/healthz || wget -qO- http://localhost:4040/healthz || exit 1
```

### server.js (antes → después)
```diff
-const PORT = parseInt(process.env.PORT || '4040');
+const PORT = parseInt(process.env.PORT || '6060');
+const FALLBACK_PORT = 4040;

 // ... al final del archivo
 app.listen(PORT, '0.0.0.0', () => { ... });
+app.listen(FALLBACK_PORT, '0.0.0.0', () => { ... });
```

## Lecciones

- NaN **siempre** inyecta `PORT=<container-port>` — no es opcional
- El HEALTHCHECK es la causa #1 de 502 con contenedor "Running"
- Sin acceso al dashboard de NaN, el patrón de doble puerto es la única solución
- NaN tarda 1-5 min en detectar nuevos commits (polling, no webhooks)