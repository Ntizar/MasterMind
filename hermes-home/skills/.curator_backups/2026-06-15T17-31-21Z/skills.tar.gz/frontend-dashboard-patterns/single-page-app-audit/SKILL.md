---
name: single-page-app-audit
description: "Auditoría sistemática de aplicaciones web HTML individuales (SPA, herramientas 100% browser, dashboards autónomos): calidad de código, rendimiento, UX, privacidad, robustez y arquitectura."
version: 1.0.0
author: Mastermind
tags: [html, audit, quality, spa, frontend, code-review]
---

# Single Page App Audit — Auditoría de Aplicaciones Web Individuales

Procedimiento para auditar archivos HTML individuales que son aplicaciones web completas (no sitios multi-página). Cubre: calidad de código, rendimiento, UX, privacidad, robustez, y mejoras.

## Cuándo usar

- El usuario pide "audita este HTML" o "qué tal está este archivo"
- Herramienta 100% browser (sin servidor)
- Dashboard, comparador, visualizador, juego, utilidad en un solo HTML
- Código que mezcla HTML + CSS + JS en un solo archivo

## Diferencia con audit-html-project

`audit-html-project` es para **proyectos multi-archivo** (10+ HTML, navegación entre páginas, contenido educativo). Este skill es para **un solo archivo HTML autónomo** que es una aplicación completa.

## Pasos

### 1. Leer el archivo completo

Usar `read_file` con offset/limit si es grande. Identificar:

- **Librerías externas**: ¿CDN o inline? ¿Versión concreta o latest?
- **Estructura**: HTML semántico, CSS organizado, JS modular?
- **Algoritmos**: ¿En hilo principal o Web Worker? ¿Complejidad?
- **UX**: Drag & drop, feedback, manejo de errores, estados vacíos

### 2. Categorías de auditoría

Evaluar cada una con severidad:

#### 🔴 Rendimiento (Performance)

- **JS inline masivo**: Librerías empaquetadas en el HTML (>100KB) en vez de CDN
- **Algoritmo O(n*m) en hilo principal**: LCS, búsquedas, ordenación de arrays grandes sin Web Worker
- **Truncado silencioso**: Datos limitados sin avisar al usuario
- **DOM manipulation ineficiente**: innerHTML en loops, reflows múltiples

#### 🔴 Privacidad / Seguridad

- **innerHTML sin escapar**: XSS si se inserta contenido del usuario
- **Subida a servidor**: ¿Los datos salen del navegador?
- **Librerías de CDN sin integridad**: Sin atributo `integrity` ni `crossorigin`

#### � UX / Accesibilidad

- **Estados**: Loading, empty, error, success — ¿todos cubiertos?
- **Feedback visual**: Spinner, animaciones, mensajes claros
- **Instrucciones**: ¿El usuario sabe qué hacer?
- **Responsive**: ¿Funciona en móvil?
- **Atribución**: Footer con autor

#### � Calidad de código

- **Código muerto**: Secciones HTML/JS que no se usan
- **Funciones no definidas**: onclick que llaman a funciones inexistentes
- **Validación de entrada**: ¿Acepta formatos que no puede procesar?
- **Manejo de errores**: try/catch con mensaje al usuario

#### 💡 Mejoras

- **Exportar resultados**: Botón para copiar/descargar
- **Modo oscuro / preferencias**
- **Web Worker** para tareas pesadas
- **Carga diferida** de librerías grandes

### 3. Formato de salida

```markdown
# 🔍 AUDITORÍA — [Nombre de la App]

**Archivo:** [ruta]
**Tamaño:** [N] bytes ([N]KB JS inline + [N]KB CSS + [N]KB HTML)

---

## 📊 RESUMEN EJECUTIVO

| Categoría | Nota | Detalle |
|---|---|---|
| **Funcionalidad** | 🟢/🟡/🔴 N/10 | Qué hace y si lo hace bien |
| **UX** | 🟢/🟡/🔴 N/10 | Experiencia de usuario |
| **Rendimiento** | 🟢/�/🔴 N/10 | Velocidad y fluidez |
| **Privacidad** | 🟢/🟡/🔴 N/10 | Datos locales vs servidor |
| **Robustez** | 🟢/�/🔴 N/10 | Manejo de errores y casos borde |
| **Código** | 🟢/🟡/🔴 N/10 | Calidad y mantenibilidad |

---

## 🔴 PROBLEMAS CRÍTICOS

### 1. [Título del problema]
[Explicación clara, con ejemplos de código si aplica]

**Impacto:** [Qué le pasa al usuario]

**Solución:** [Cómo arreglarlo]

---

## 🟡 PROBLEMAS IMPORTANTES

[Similar formato]

---

## 💡 MEJORAS SUGERIDAS

[Similar formato]

---

## ✅ LO QUE FUNCIONA BIEN

- [Bullet points de aciertos]

---

## 🛠️ Prioridad de mejoras

1. **🔴 [Prioridad 1]** — [Acción]
2. **🔴 [Prioridad 2]** — [Acción]
3. **🟡 [Prioridad 3]** — [Acción]
...

---

¿Quieres que aplique alguna de estas mejoras?
```

### 4. Reglas

- **Siempre empezar con resumen ejecutivo** con notas y porcentajes
- **Cada problema debe tener**: descripción, impacto, solución
- **Sección "Lo que funciona bien"** — no todo son críticas
- **Terminar con "¿Quieres que aplique mejoras?"** — el usuario quiere acción. **Si responde "Arregla todo" / "Fix everything" → implementar TODOS los bugs en orden de prioridad SIN re-preguntar**
- **No asumir que el usuario sabe de código** — explicar impacto en lenguaje claro
- **Para apps con librerías inline >100KB**: siempre recomendar CDN como primera mejora
- **Preferencia de usuario detectada: acción sobre discusión** — frases cortas e imperativas ("Hazlo", "Vale") = ejecución directa sin pausas

## Pitfalls

- **🔴 No confundir con audit-html-project**: Este skill es para UN solo archivo HTML autónomo. Si hay 10+ archivos con navegación entre ellos, usar `audit-html-project`.
- **🔴 No asumir que el usuario quiere todas las mejoras**: Preguntar al final. Algunos quieren solo diagnóstico.
- **🔴 Librerías inline vs CDN**: Verificar si la librería inline es una versión modificada o estándar. Si es estándar, CDN es mejor. Si está modificada, mantener inline pero documentarlo.
- **🔴 Algoritmos O(n*m)**: No solo detectarlos, sino calcular el impacto: "con 5000 palabras × 5000 palabras = 25M iteraciones, el navegador se congela ~3-5 segundos".
- **🔴 Código muerto**: No asumir que es error — puede ser preparación para futura funcionalidad. Preguntar.
- **🔴 Aceptar formatos que no puede procesar**: Ej: input accept incluye `.doc` pero la librería solo lee `.docx`. Reportar como bug.
- **🔴⚠️ Implementar mejoras una a la vez**: Cuando el usuario dice "arregla todo", NO hacer todas las mejoras en un solo commit. Cada cambio (extraer JS, var→const/let, arrow functions, etc.) debe ser un commit separado con verificación intermedia. Si se hacen juntas y algo rompe, no se puede identificar cuál fue la causa. Ver `safe-refactoring-checklist` para el flujo completo.
- **🔴⚠️ Verificar que las mejoras no rompen funcionalidad**: Después de CADA mejora implementada, hacer `browser_vision` para confirmar que todo sigue visible. Un `var→const` mal hecho puede petar un tab completo sin error visible en consola.

## Referencias

Ver `references/auditoria-comparador-documentos.md` para un ejemplo completo de auditoría de una app de comparación de documentos Word.