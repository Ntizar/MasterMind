# Auditoría de Comparador de Documentos (comparar_docs.html)

**Fecha:** 10 junio 2026
**Archivo:** `/root/workspace/comparar_docs.html`
**Tamaño:** 665,963 bytes (~660KB JS inline + ~5KB CSS + ~1KB HTML)

## Resumen

App 100% browser que compara dos archivos .docx usando Mammoth.js para extraer texto y un algoritmo LCS (Longest Common Subsequence) para detectar diferencias palabra a palabra.

## Hallazgos clave

### 🔴 Críticos

1. **Mammoth.js inline = 665KB de bloat**
   - Librería + JSZip + sax-xml + bluebird + underscore + xmlbuilder2 empaquetados en un solo `<script>`
   - Solución: CDN (`https://cdnjs.cloudflare.com/ajax/libs/mammoth/1.6.0/mammoth.browser.min.js`)

2. **LCS O(n*m) en el hilo principal**
   - Con 5000 palabras × 5000 palabras = 25M iteraciones
   - El navegador se congela durante la comparación
   - Además, trunca silenciosamente a 5000 palabras (`MAX = 5000`)
   - Solución: Web Worker para el LCS

3. **Diff por palabras frágil**
   - Quita tildes (NFD + regex), puntuación, mayúsculas
   - "constitución" y "constitucion" se ven como iguales
   - Solución: diff por párrafos primero, palabras después

### 🟡 Importantes

4. **No hay modo "solo diferencias" exportable**
   - No se puede copiar/descargar el resultado

5. **Batch section fantasma**
   - HTML tiene `#batchSection` y `#batchResults` pero nunca se muestran

6. **Acepta .doc pero Mammoth no lo lee**
   - `accept=".docx,.doc"` pero Mammoth.js solo procesa .docx (Office Open XML)

### ✅ Aciertos

- 100% local, nada sale del navegador
- UI clara con drag & drop, feedback visual, cards de archivos
- Limpieza de ruido (firmas, headers CVE, URLs, numeración)
- Agrupación de cambios consecutivos en "frases"
- Manejo de errores con mensaje al usuario
- Paste desde portapapeles
- Footer de atribución correcto

## Patrón de auditoría usado

1. Leer archivo completo (read_file con offset)
2. Identificar: librerías, estructura, algoritmos, UX
3. Evaluar por categorías: rendimiento, privacidad, UX, código, mejoras
4. Formatear salida con: resumen ejecutivo → críticos → importantes → mejoras → aciertos → prioridades
5. Terminar con "¿Quieres que aplique mejoras?"

## Lecciones aprendidas

- **Librerías inline >100KB = siempre recomendar CDN** como primera mejora
- **Algoritmos O(n*m) en frontend**: calcular impacto real (ej: "25M iteraciones = 3-5s de congelación")
- **Truncado silencioso**: siempre detectar y reportar como bug de UX
- **Código muerto HTML/JS**: verificar si es vestigio o preparación para futuro
- **Aceptar formatos no soportados**: validar que el accept del input coincide con lo que la librería puede procesar