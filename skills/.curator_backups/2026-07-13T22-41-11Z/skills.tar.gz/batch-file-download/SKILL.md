---
name: batch-file-download
version: "1.0.0"
description: "Patrón para descargar masivamente archivos (PDFs, imágenes, etc.) de sitios web con rate limiting, retries, y verificación de integridad. Diseñado para 100+ archivos con delays anti-429."
tags: [batch, download, pdf, rate-limiting, resilience, background]
---

# Batch File Download — Patrón de descarga masiva resiliente

## Resumen

Patrón genérico para descargar cientos de archivos (PDFs, imágenes, etc.) de sitios web con rate limiting agresivo, retries con backoff, y verificación de integridad. Optimizado para Drupal/WordPress y sitios gubernamentales.

## Cuándo usarlo

- 100+ archivos a descargar de un sitio con rate limiting
- Sitios que devuelven 429 tras ~50 requests
- Descargas que tardan más de 5 minutos (no apto para cron con timeout corto)
- Necesidad de verificar integridad (archivos corruptos, HTML en vez de PDF)

## Arquitectura

### Dos fases: scrapeo → descarga (RECOMENDADO)

Separar el scrapeo (construir índice de URLs) de la descarga (bajar archivos). Ventajas:

- **Resume:** si el scrapeo tarda horas por rate limiting, guardar índice incremental permite reanudar tras timeout
- **Dry-run:** ejecutar `--dry-run` para ver el total antes de comprometerse a una descarga larga
- **Idempotencia:** el script de descarga salta archivos ya en disco, se puede re-ejecutar sin duplicar

```python
# FASE 1: Scrapeo — construir índice {unidad: {subgrupo: [urls]}}
indice = {}
# Cargar índice parcial previo si existe (resume tras timeout)
if INDEX_FILE.exists():
    indice = json.load(open(INDEX_FILE))

for unidad in unidades:
    if unidad in indice:  # saltar ya scrapeados
        continue
    datos = scrapear_unidad(unidad)
    indice[unidad] = datos
    # Guardar DESPUÉS de cada unidad (no al final)
    json.dump(indice, open(INDEX_FILE, "w"))

# FASE 2: Descarga — usar índice, saltar existentes
for unidad, subgrupos in indice.items():
    for subgrupo, urls in subgrupos.items():
        for url in urls:
            dest = DATA_DIR / unidad / subgrupo / nombre_archivo(url)
            if dest.exists() and dest.stat().st_size > 2000:
                continue  # idempotente
            descargar_archivo(url, dest)
```

### Conexión nueva por archivo (CRÍTICO)

```python
def descargar_archivo(url, dest_path):
    """Conexión nueva cada vez — sin session keep-alive."""
    for intento in range(8):
        try:
            # requests.get() directo — sin Session()
            resp = requests.get(url, timeout=120, allow_redirects=True)
            if resp.status_code == 200 and resp.content[:5] == b"%PDF-":
                return True
            elif resp.status_code == 429:
                delay = 30 * (intento + 1)  # 30, 60, 90...
                time.sleep(delay)
            else:
                return False  # error no reintentable
        except requests.exceptions.ConnectionError:
            time.sleep(10 * (intento + 1))
        except requests.exceptions.Timeout:
            time.sleep(15 * (intento + 1))
    return False
```

**Por qué NO usar Session():** Las conexiones keep-alive pueden romperse tras tiempos largos (segundos de inactividad, cambios de ruta, etc.). Nueva conexión = menos errores silenciosos.

### Delays y batches

```python
# Delay entre descargas (ajustar según el sitio)
DELAY = 1.0  # segundos

# Para sitios muy agresivos con rate limiting:
DELAY = 2.0

# Para sitios permisivos:
DELAY = 0.3
```

### Verificación de integridad

```python
# PDFs: verificar magic bytes
if resp.content[:5] == b"%PDF-":
    # archivo válido
else:
    # HTML en vez de PDF, o archivo corrupto

# Archivos genéricos: verificar tamaño mínimo
if path.exists() and path.stat().st_size > 2000:
    # ya existe y no es un error page
```

### Estructura del script

```python
#!/usr/bin/env python3
"""
batch-download.py — Descarga masiva de archivos
Uso: python3 batch-download.py --delay 1 [--dry-run]
"""
import json, sys, time, requests
from pathlib import Path

BASE = Path("/ruta/al/proyecto")
DELAY = 1.0
DRY_RUN = False

# Parse args
for arg in sys.argv[1:]:
    if arg == "--dry-run": DRY_RUN = True
    elif arg.startswith("--delay"):
        DELAY = float(arg.split("=")[1] if "=" in arg else sys.argv[sys.argv.index(arg) + 1])

# Cargar índices (JSON pre-cacheados)
indices = cargar_indices()

# Contar pendientes
total_pendientes = contar_pendientes(indices)

# Descargar
stats = {"exitosos": 0, "fallidos": 0, "saltados": 0}
for pais, reports in indices.items():
    for r in reports:
        fname = f"{pais}_{r['year']}_{r['title']}"
        path = BASE / "downloads" / pais / fname
        
        if path.exists() and path.stat().st_size > 2000:
            stats["saltados"] += 1
            continue
        
        if descargar_archivo(r["pdf_url"], path):
            stats["exitosos"] += 1
        else:
            stats["fallidos"] += 1
        
        time.sleep(DELAY)

# Resumen
print(f"✅ {stats['exitosos']} ❌ {stats['fallidos']} ⏭️ {stats['saltados']}")
```

## Patrón paralelo download+retry (OPTIMIZACIÓN CLAVE)

Cuando se descargan múltiples unidades (países, categorías, etc.) secuencialmente, **lanzar la siguiente unidad mientras se reintentan los fallos de la anterior** en paralelo:

```
# País N: descarga principal (background, notify_on_complete)
python3 script.py --pais FI --delay=1.5 | tee log_FI.txt &

# Cuando FI termina → lanzar en paralelo:
#   1. Reintentos de FI (background)
#   2. Descarga de FR (background)
python3 script.py --pais FI --reintentar --delay=2 | tee log_FI_reintentos.txt &
python3 script.py --pais FR --delay=1.5 | tee log_FR.txt &
```

**Ventajas:**
- El rate limiting del re-scrapeo (429s) no bloquea la descarga del siguiente país
- Se aprovecha el tiempo de espera de backoff para progreso real
- Los reintentos usan `--delay=2` (más conservador) mientras la descarga nueva usa `--delay=1.5`

**Monitorización de ambos procesos:**
```bash
# Contar PDFs descargados por país
find /path/Data/FI -name "*.pdf" | wc -l

# Ver progreso de cada log
tail -15 log_FI.txt
tail -15 log_FR.txt
```

## Tasa de fallos y efectividad de reintentos (datos reales ERA)

De 4 países completados (ES, FI, FR, HR — 920 PDFs índice total):

- **Primera pasada:** ~75-85% de éxito (fallos por 429, connection reset, 404)
- **Reintentos:** recuperan ~50-60% de los fallidos
- **Fallos persistentes:** ~3-5% del total (archivos probablemente inexistentes en servidor)

| País | Índice | 1ª pasada | Reintentos | Total | Fallando |
|------|--------|-----------|------------|-------|----------|
| FI | 314 | 277 (88%) | +31 | 308 | 5 (1.6%) |
| FR | 119 | 93 (78%) | +18 | 111 | 8 (6.7%) |
| HR | 111 | 90 (81%) | +15 | 105 | 5 (4.5%) |

**Conclusión:** 2 pasadas (descarga + reintento) son suficientes. Una 3ª pasada tiene rendimientos marginales.

## Pitfalls

- **🔥 Disk space exhaustion en `/root` (NaN.builders 20G partition):** El disco `/root` es una partición separada de 20G, independiente del `/` (que tiene 187G+). Descargas masivas de PDFs (cientos de archivos) pueden llenarlo. El error aparece como `OSError: [Errno 28] No space left on device` y mata el proceso Python. **Diagnóstico:** `df -h /root` (si dice 100%, es esto). **Fix:** limpiar caches:
  ```bash
  npm cache clean --force 2>/dev/null
  rm -rf /root/.npm/_cacache /root/.cache/pip /root/.cache/puppeteer
  # Verificar espacio recuperado
  df -h /root
  ```
  Típicamente libera 1-2G. **Prevención:** antes de lanzar descargas grandes (>200 PDFs), verificar `df -h /root` y limpiar caches si Use% > 85%. Considerar mover datos a `/` (que tiene mucho más espacio) con symlink: `ln -s /workspace/ERAVisor/Data /root/workspace/ERAVisor/Data`.
- **Stale lock file tras crash:** Si el proceso muere abruptamente (OOM, disco lleno, kill), el lock file (`descarga_activa.lock` con PID) queda en disco. El script debe verificar si el PID sigue vivo antes de respetar el lock. Si el PID no existe, eliminar el lock y continuar:
  ```bash
  # Limpiar lock stale manualmente
  rm -f Data/descarga_activa.lock
  # O en el script: os.kill(pid, 0) → ProcessLookupError si el PID no existe
  ```
- **Archivos movidos a almacenamiento externo → el script reinicia desde cero:** Si los archivos descargados se mueven a otro destino (disco local, NAS, etc.) y el script de progreso comprueba la existencia de archivos en disco para determinar qué chunks faltan, verá 0 archivos y reiniciará la descarga desde el principio. **Fix:** usar un marcador `.completado` (fichero vacío o con timestamp) en `Data/CHUNK/.completado`. El script de progreso comprueba primero el marcador antes de contar archivos:
  ```python
  def chunk_completo(chunk, indice):
      if chunk not in indice:
          return False
      marcador = DATA_DIR / chunk / ".completado"
      if marcador.exists():
          return True  # ya descargado y movido, no re-descargar
      # ... verificación normal por conteo de archivos ...
  ```
  Crear marcadores para los chunks ya procesados:
  ```bash
  for chunk in AT BE BG CH CZ DE; do
    mkdir -p "Data/$chunk"
    echo "Descargado y movido a local el $(date -u '+%Y-%m-%d %H:%M UTC')" > "Data/$chunk/.completado"
  done
  ```
- **`tee` en background SÍ funciona:** `python3 script.py 2>&1 | tee log.txt` en background mode funciona correctamente — se puede hacer `tail -f log.txt` para monitorizar. El pitfall anterior sobre truncado era incorrecto o específico de ciertas condiciones.
- **Timeout de cron:** No ejecutar en cron con timeout < 300s para tareas que tardan horas. Usar `nohup`, `&`, o background process.
- **Session keep-alive rompe conexiones:** Tras tiempos largos, las conexiones de `requests.Session()` pueden quedar huérfanas. Usar `requests.get()` directo.
- **429 con backoff exponencial:** No usar delay fijo — progresivo (30s, 60s, 90s...) es más efectivo.
- **Verificar magic bytes:** HTTP 200 no significa archivo válido. Verificar `content[:5]` para PDFs.
- **Nombres de archivo inconsistentes:** Verificar que el formato de nombre generado coincide con los existentes en disco. Un bug de naming puede hacer que el script re-descargue todo.
- **Patrones duales de URL en Drupal:** Los sitios Drupal sirven archivos desde `/sites/default/files/` (Drupal 8+) Y `/system/files/` (Drupal 7 y anterior). Un regex que solo captura uno pierde la mitad de los archivos. Usar patrón amplio: `href="(/[^"]*\.pdf[^"]*)"`.
- **No verificar server-side rendering:** Antes de usar browser tools (lento), hacer `curl -s URL | grep -oP 'href="[^"]*\.pdf"'`. Si devuelve resultados, el sitio es SSR y se puede scrapear con curl/requests directamente.
- **Guardar índice solo al final:** Si el script muere por timeout tras scrapear 20 países, se pierde todo. Guardar el índice incrementalmente después de cada unidad.
- **Delay entre peticiones de scrapeo:** No solo entre descargas. El scrapeo de páginas también recibe 429. Añadir `time.sleep(1.0)` entre peticiones de páginas.

## Pitfalls de naming

Los nombres de archivo generados pueden NO coincidir con los del índice:
- Minúsculas vs mayúsculas (`de-10413` vs `DE-10413`)
- Doble extensión (`.pdf.` al final)
- Caracteres especiales no escapados
- Espacios en títulos del índice

**Verificar siempre:** listar archivos en disco y comparar con el índice. Si hay discrepancia, los archivos pueden existir con nombres ligeramente distintos.

## Cron job para descargas largas (horas/días)

Cuando una descarga masiva tarda horas por rate limiting, usar un cron job recurrente que re-ejecuta el script idempotente. El script salta archivos ya descargados, así que cada ejecución solo descarga lo pendiente.

```python
# El script debe ser idempotente:
# 1. Cargar índice previo si existe (no re-scrapear)
# 2. Saltar archivos ya en disco (>2000 bytes)
# 3. Guardar índice incrementalmente
```

Configurar cron con `cronjob` tool:
- `schedule`: `30m` (cada 30 minutos)
- `repeat`: `-1` (forever — hasta que todo esté descargado)
- `enabled_toolsets`: `["terminal"]` (solo necesita terminal)
- El prompt debe ejecutar el script y reportar progreso brevemente

Cuando todo esté descargado, pausar o eliminar el cron con `cronjob action=remove`.

## Ejemplo: ERAVisor

Script completo en `/root/workspace/ERAVisor/scripts/descargar_todos_era.py`

Estado a 2026-07-10: 29 países, 4.715 PDFs en índice.
- **Completados (con marcador `.completado`):** AT, BE, BG, CH, CZ, DE, DK, EE, EL, ES, FI, FR, HR, HU, IE, SE, SI, SK — 18 países
- **Descargados en disco (sin mover):** IT (101), NL (8), PT (61), RO (182), Serbia (57), UK (~306 en curso)
- **Pendientes:** LT (8), LU (5), LV (24), NO (170), PL (128) — 5 países no iniciados
Estructura: `Data/PAIS/AÑO/archivo.pdf`

Ver `references/era-scraping.md` para detalles específicos del scraping de ERA, progreso de descarga, y workflow paralelo download+retry.

## Alternativas

- **`wget -c -i urls.txt`:** Para listas simples de URLs, sin verificación de integridad
- **`curl -O`:** Similar a wget, pero sin reintentos automáticos
- **`axel`/`aria2c`:** Descarga multi-hilo, pero no maneja 429 bien

## Archivos de apoyo

- `references/era-scraping.md` — Detalles específicos del scraping de ERA (29 países, patrones duales de URL, distribución de PDFs)
- `scripts/batch_download_template.py` — Plantilla genérica de script two-phase (scrapeo + descarga) con resume, dry-run, y rate limiting
