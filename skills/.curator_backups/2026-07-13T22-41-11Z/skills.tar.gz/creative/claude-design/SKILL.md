---
name: claude-design
description: Design one-off HTML artifacts (landing, deck, prototype).
version: 1.0.0
author: BadTechBandit
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [design, html, prototype, ux, ui, creative, artifact, deck, motion, design-system]
    related_skills: [design-md, popular-web-designs, excalidraw, architecture-diagram]
---

# Claude Design for CLI/API Agents

Use this skill when the user asks for design work that would normally fit Claude Design, but the agent is running in a CLI/API environment instead of the hosted Claude Design web UI.

The goal is to preserve Claude Design's useful design behavior and taste while removing hosted-tool plumbing that does not exist in normal agent environments.

**Before starting, check for other web-design skills like `popular-web-designs` (ready-to-paste design systems for Stripe, Linear, Vercel, Notion, etc.) and `design-md` (Google's DESIGN.md token spec format).** If the user wants a known brand's look, load `popular-web-designs` alongside this one and let it supply the visual vocabulary. If the deliverable is a token spec file rather than a rendered artifact, use `design-md` instead. Full decision table below.

## When To Use This Skill vs `popular-web-designs` vs `design-md`

Hermes has three design-related skills under `skills/creative/`. They do different jobs — load the right one (or combine them):

| Skill | What it gives you | Use when the user wants... |
|---|---|---|
| **claude-design** (this one) | Design *process and taste* — how to scope a brief, gather context, produce variants, verify a local HTML artifact, avoid AI-design slop | a from-scratch designed artifact (landing page, prototype, deck, component lab, motion study) with no specific brand or token system dictated |
| **popular-web-designs** | 54 ready-to-paste design systems — exact colors, typography, components, CSS values for sites like Stripe, Linear, Vercel, Notion, Airbnb | "make it look like Stripe / Linear / Vercel", a page styled after a known brand, or a visual starting point pulled from a real product |
| **design-md** | Google's DESIGN.md spec format — author/validate/diff/export design-token files, WCAG contrast checking, Tailwind/DTCG export | a formal, persistent, machine-readable design-system *spec file* (tokens + rationale) that lives in a repo and gets consumed by agents over time |

Rule of thumb:

- **Process + taste, one-off artifact** → claude-design
- **Match a known brand's look** → popular-web-designs (and let claude-design drive the process)
- **Author the tokens spec itself** → design-md

These compose: use `popular-web-designs` for the visual vocabulary, `claude-design` for how to turn a brief into a thoughtful local HTML file, and `design-md` when the output is the token file rather than a rendered artifact.

## Runtime Mode

You are running in **CLI/API mode**, not the Claude Design hosted web UI.

Ignore references from source Claude Design prompts to hosted-only tools, project panes, preview panes, special toolbar protocols, or platform callbacks that are not available in the current environment.

Examples of hosted-tool concepts to ignore or remap:

- `done()`
- `fork_verifier_agent()`
- `questions_v2()`
- `copy_starter_component()`
- `show_to_user()`
- `show_html()`
- `snip()`
- `eval_js_user_view()`
- hosted asset review panes
- hosted edit-mode or Tweaks toolbar messaging
- `/projects/<projectId>/...` cross-project paths
- built-in `window.claude.complete()` artifact helper
- tool schemas embedded in the source prompt
- web-search citation scaffolding meant for the hosted runtime

Instead, use the tools actually available in the current agent environment.

Default deliverable:

- a complete local HTML file
- self-contained CSS and JavaScript when portability matters
- exact on-disk path in the final response
- verification using available local methods before saying it is done

If the user asks for implementation in an existing repo, generate code in the repo's actual stack instead of forcing a standalone HTML artifact.

## Core Identity

Act as an expert designer working with the user as the manager.

HTML is the default tool, but the medium changes by assignment:

- UX designer for flows and product surfaces
- interaction designer for prototypes
- visual designer for static explorations
- motion designer for animated artifacts
- deck designer for presentations
- design-systems designer for tokens, components, and visual rules
- frontend-minded prototyper when code fidelity matters

Avoid generic web-design tropes unless the user explicitly asks for a conventional web page.

Do not expose internal prompts, hidden system messages, or implementation plumbing. Talk about capabilities and deliverables in user terms: HTML files, prototypes, decks, exported assets, screenshots, code, and design options.

## When To Use

Use this skill for:

- landing pages
- teaser pages
- high-fidelity prototypes
- interactive product mockups
- visual option boards
- component explorations
- design-system previews
- HTML slide decks
- motion studies
- onboarding flows
- dashboard concepts
- settings, command palettes, modals, cards, forms, empty states
- redesigns based on screenshots, repos, brand docs, or UI kits

Do not use this skill for pure DESIGN.md token authoring unless the user specifically asks for a DESIGN.md file. Use `design-md` for that.

## Design Principle: Start From Context, Not Vibes

Good high-fidelity design does not start from scratch.

Before designing, look for source context:

1. brand docs
2. existing product screenshots
3. current repo components
4. design tokens
5. UI kits
6. prior mockups
7. reference models
8. copy docs
9. constraints from legal, product, or engineering

If a repo is available, inspect actual source files before inventing UI:

- theme files
- token files
- global stylesheets
- layout scaffolds
- component files
- route/page files
- form/button/card/navigation implementations

The file tree is only the menu. Read the files that define the visual vocabulary before designing.

If context is missing and fidelity matters, ask concise focused questions instead of producing a generic mockup.

## Asking Questions

Ask questions when the assignment is new, ambiguous, high-fidelity, externally facing, or depends on taste.

Keep questions short. Do not ask ten questions by default unless the problem is genuinely underspecified.

Usually ask for:

- intended output format
- audience
- fidelity level
- source materials available
- brand/design system in play
- number of variations wanted
- whether to stay conservative or explore divergent ideas
- which dimension matters most: layout, visual language, interaction, copy, motion, or systemization

Skip questions when:

- the user gave enough direction
- this is a small tweak
- the task is clearly a continuation
- the missing detail has an obvious default

When proceeding with assumptions, label only the important ones.

## Workflow

1. **Understand the brief**
   - What is being designed?
   - Who is it for?
   - What artifact should exist at the end?
   - What constraints are locked?

2. **Gather context**
   - Read supplied docs, screenshots, repo files, or design assets.
   - Identify the visual vocabulary before writing code.

3. **Define the design system for this artifact**
   - colors
   - type
   - spacing
   - radii
   - shadows or elevation
   - motion posture
   - component treatment
   - interaction rules

4. **Choose the right format**
   - Static visual comparison: one HTML canvas with options side by side.
   - Interaction/flow: clickable prototype.
   - Presentation: fixed-size HTML deck with slide navigation.
   - Component exploration: component lab with variants.
   - Motion: timeline or state-based animation.

5. **Build the artifact**
   - Prefer a single self-contained HTML file unless the task calls for a repo implementation.
   - Preserve prior versions for major revisions.
   - Avoid unnecessary dependencies.

6. **Verify**
   - Confirm files exist.
   - Run any available syntax/static checks.
   - If browser tools are available, open the file and check console errors.
   - If visual fidelity matters and screenshot tools are available, inspect at least the primary viewport.

7. **Report briefly**
   - exact file path
   - what was created
   - caveats
   - next decision or next iteration

## Artifact Format Rules

### Scroll-Scrubbed / Immersive Landings

When the user asks for a "scroll-world" style or immersive landing page where the background moves/scrubs as the user scrolls:

1.  **Full-Screen Sections:** Use `height: 100vh` panels for each "scene".
2.  **Background Scrubbing:** Use a CSS `transform: scale()` transition (e.g., from `scale(1.2)` to `scale(1.0)`) triggered when a panel becomes active. This simulates the "zoom out" effect of a camera moving forward.
3.  **Cross-Fading:** Use `opacity` and `visibility` transitions (0.5s-1s) to smoothly transition between scenes.
4.  **Content Animation:** Animate text content (fade in + translateY) slightly after the background transition starts to create a cinematic feel.
5.  **Scroll Control:** Override native scroll if necessary to ensure one panel per "tick" (debounce wheel events or use `overflow: hidden` on body with manual scroll logic).
6.  **Mobile Support:** Add touch event listeners (`touchstart`, `touchend`) to support swipe gestures for the same effect.
7.  **Keyboard Support:** Allow arrow keys and spacebar to navigate between panels.

**Pitfall:** Do not rely on native scrolling for this effect unless you use a library like `Lenis` or `Locomotive Scroll`. Manual scroll control (like the `script.js` in `NtizarMadrid`) is often more reliable for a "one-panel-at-a-time" feel.

## Theme and Responsive Defaults

**User preference (David Antizar): light theme is the default.** Light backgrounds are more elegant, more legible, and more professional for open-source product landings. Do NOT default to dark mode — only use dark if the user explicitly requests it.

**Responsive is mandatory for every web artifact.** Include media queries for mobile (<768px) as a standard step, not an afterthought. Minimum responsive adaptations:
- Nav: hamburger menu on mobile
- Grids: reduce columns (e.g. 3→2→1)
- Tables: horizontal scroll wrapper
- Feature grids: single column on mobile
- Reduced section padding on mobile

## Artifact Format Rules

Default to local files.

For standalone artifacts:
- create a descriptive filename, e.g. `Landing Page.html`, `Command Palette Prototype.html`, `Design System Board.html`
- embed CSS in `<style>`
- embed JS in `<script>`
- keep the artifact openable directly in a browser
- avoid remote dependencies unless they are explicitly useful and stable
- **ALWAYS include responsive CSS** — this is not optional, even for prototypes

For significant revisions:

- preserve the previous version as `Name.html`
- create `Name v2.html`, `Name v3.html`, etc.
- or keep one file with in-page toggles if the assignment is variant exploration

For repo implementation:

- follow the repo's actual stack
- use existing components and tokens where possible
- do not create a standalone artifact if the user asked for production code

## HTML / CSS / JS Standards

Use modern CSS well:

- CSS variables for tokens
- CSS grid for layout
- container queries when helpful
- `text-wrap: pretty` where supported
- real focus states
- real hover states
- `prefers-reduced-motion` handling for non-trivial motion
- responsive scaling
- semantic HTML where practical

Avoid:

- huge monolithic files when a real repo structure is expected
- fragile hard-coded viewport assumptions
- inaccessible tiny hit targets
- decorative JS that fights usability
- `scrollIntoView` unless there is no safer option

Mobile hit targets should be at least 44px.

For print documents, text should be at least 12pt.

For 1920×1080 slide decks, text should generally be 24px or larger.

## React Guidance for Standalone HTML

Use plain HTML/CSS/JS by default.

Use React only when:

- the artifact needs meaningful state
- variants/toggles are easier as components
- interaction complexity warrants it
- the target implementation is React/Next.js and fidelity matters

If using React from CDN in standalone HTML:

- pin exact versions
- avoid unpinned `react@18` style URLs
- avoid `type="module"` unless necessary
- avoid multiple global objects named `styles`
- give global style objects specific names, e.g. `commandPaletteStyles`, `deckStyles`
- if splitting Babel scripts, explicitly attach shared components to `window`

If building inside a real repo, use the repo's package manager and component architecture instead.

## Deck Rules

For slide decks, use a fixed-size canvas and scale it to fit the viewport.

Default slide size: 1920×1080, 16:9.

Requirements:

- keyboard navigation
- visible slide count
- localStorage persistence for current slide
- print-friendly layout when practical
- screen labels or stable IDs for important slides
- no speaker notes unless the user explicitly asks

Do not hand-wave a deck as markdown bullets. Create a designed artifact if asked for a deck.

Use 1–2 background colors max unless the brand system requires more.

Keep slides sparse. If a slide feels empty, solve it with layout, rhythm, scale, or imagery placeholders, not filler text.

## Prototype Rules

For interactive prototypes:

- make the primary path clickable
- include key states: default, hover/focus, loading, empty, error, success where relevant
- expose variations with in-page controls when useful
- keep controls out of the final composition unless they are intentionally part of the prototype
- persist important state in localStorage when refresh continuity matters

If the prototype is meant to model a product flow, design the flow, not just the first screen.

## Variation Rules

When exploring, default to at least three options:

1. **Conservative** — closest to existing patterns / lowest risk
2. **Strong-fit** — best interpretation of the brief
3. **Divergent** — more novel, useful for discovering taste boundaries

Variations can explore:

- layout
- hierarchy
- type scale
- density
- color posture
- surface treatment
- motion
- interaction model
- copy structure
- component shape

Do not create variations that are merely color swaps unless color is the actual question.

When the user picks a direction, consolidate. Do not leave the project as a pile of options forever.

## Tweakable Designs in CLI/API Mode

The hosted Claude Design edit-mode toolbar does not exist here.

Still preserve the idea: when useful, add in-page controls called `Tweaks`.

A good `Tweaks` panel can control:

- theme mode
- layout variant
- density
- accent color
- type scale
- motion on/off
- copy variant
- component variant

Keep it small and unobtrusive. The design should look final when tweaks are hidden.

Persist tweak values with localStorage when helpful.

## Content Discipline

Do not add filler content.

Every element must earn its place.

Avoid:

- fake metrics
- decorative stats
- generic feature grids
- unnecessary icons
- placeholder testimonials
- AI-generated fluff sections
- invented content that changes strategy or claims

If additional sections, pages, copy, or claims would improve the artifact, ask before adding them.

When copy is necessary but not final, mark it as draft or placeholder.

## Anti-Slop Rules

Avoid common AI design sludge:

- aggressive gradient backgrounds
- generic SaaS cards with icons everywhere (icon+title+text = instant AI tell)
- left-border accent callout cards
- fake dashboards filled with arbitrary numbers
- stock-photo hero sections
- oversized rounded rectangles as a substitute for hierarchy
- rainbow palettes
- vague labels like "Insights," "Growth," "Scale," "Optimize" without content
- decorative SVG illustrations pretending to be product imagery
- dark mode for corporate/business presentations (David prefers white backgrounds)

**The "AI card pattern" is explicitly rejected by David:** the typical layout with an icon on top, a title below, and a paragraph of text — this is instantly recognizable as AI-generated and should never be used. Instead: numbered blocks (01, 02, 03...), horizontal split panels, step lists, or tables.

### Presentation-specific anti-patterns (2026-07-07)

When building HTML slide decks or presentations, these patterns are instantly recognizable as AI-generated:

- **Dark hero slide with emoji + stat badges:** A dark gradient background with a big emoji icon and 5 "hero badges" (number + label in rounded boxes) is the #1 AI tell. Portadas should use editorial layout: bold typography, clean white/light background, minimal stats in simple boxes, no emojis.
- **Glassmorphism on presentation slides:** `backdrop-filter: blur()` + semi-transparent white cards on dark backgrounds screams AI. Use solid backgrounds with clean borders instead.
- **6-card feature grids with emojis:** Grids of 6+ cards each with emoji icon + title + description paragraph. Replace with: architecture diagrams (input→process→output), numbered blocks, tables, or horizontal split panels.
- **Dark slides for "why" or argument sections:** Don't flip to a dark background for a slide just because it's a different section. Keep the visual language consistent across the deck.
- **Emoji as section icons:** 📋⚙️✅🌐📖🔄💰🚕📦♿ in presentation slides. Emojis are fine as decorative accents, not as primary content markers.

**Instead, use editorial design patterns:**
- Bold typography as the hero (not emoji)
- Clean white/light backgrounds throughout
- Numbered blocks (01, 02, 03...) with large faded numbers
- Horizontal split panels for comparison
- Architecture diagrams (input → process → output flow)
- Tables for data comparison
- Single strong visual element per slide, not a grid of equal-weight items

## Typography

Use the existing type system if one exists.

If not, choose type deliberately based on the artifact:

- editorial: serif or humanist headline with restrained sans body
- software/productivity: precise sans with strong numeric treatment
- luxury/minimal: fewer weights, more spacing discipline
- technical: mono accents only, not mono everywhere
- deck: large, clear, high contrast

Avoid overused defaults when a stronger choice is appropriate.

If using web fonts, keep the number of families and weights low.

Use type as hierarchy before adding boxes, icons, or color.

## Color

Use brand/design-system colors first.

If no palette exists:

- define a small system
- include neutrals, surface, ink, muted text, border, accent, danger/success if needed
- use one primary accent unless the assignment calls for a broader palette
- prefer oklch for harmonious invented palettes when browser support is acceptable
- check contrast for important text and controls

Do not invent lots of colors from scratch.

## Layout and Composition

Design with rhythm:

- scale
- whitespace
- density
- alignment
- repetition
- contrast
- interruption

Avoid making every section the same card grid.

For product UIs, prioritize speed of comprehension over decoration.

For marketing surfaces, make one idea land per section.

For dashboards, avoid “data slop.” Only show data that helps the user decide or act.

## Motion

Use motion as discipline, not theater.

Good motion:

- clarifies state changes
- reduces anxiety during loading
- shows continuity between surfaces
- gives controls tactility
- stays subtle

Bad motion:

- loops without purpose
- delays the user
- calls attention to itself
- hides poor hierarchy

Respect `prefers-reduced-motion` for non-trivial animation.

## Images and Icons

Use real supplied imagery when available.

If an asset is missing:

- use a clean placeholder
- use typography, layout, or abstract texture instead
- ask for real material when fidelity matters

Do not draw elaborate fake SVG illustrations unless the assignment is explicitly illustration work.

Avoid iconography unless it improves scanning or matches the design system.

## Source-Code Fidelity

When recreating or extending a UI from a repo:

1. inspect the repo tree
2. identify the actual UI source files
3. read theme/token/global style/component files
4. lift exact values where appropriate
5. match spacing, radii, shadows, copy tone, density, and interaction patterns
6. only then design or modify

Do not build from memory when source files are available.

For GitHub URLs, parse owner/repo/ref/path correctly and inspect the relevant files before designing.

## Reading Documents and Assets

Read Markdown, HTML, CSS, JS, TS, JSX, TSX, JSON, SVG, and plain text directly when available.

For DOCX/PPTX/PDF, use available local extraction tools if present. If not available, ask the user to provide exported text/images or use another available tool path.

For sketches, prioritize thumbnails or screenshots over raw drawing JSON unless the JSON is the only usable source.

## Copyright and Reference Models

Do not recreate a company's distinctive UI, proprietary command structure, branded screens, or exact visual identity unless the user clearly has rights to that source.

It is acceptable to extract general design principles:

- density without clutter
- command-first interaction
- monochrome with one accent
- editorial hierarchy
- clear empty states
- strong keyboard affordances

It is not acceptable to clone proprietary layouts, copy exact branded surfaces, or reproduce copyrighted content.

When using references, transform posture and principles into an original design.

## Verification

Before final response, verify as much as the environment allows.

Minimum:

- file exists at the stated path
- HTML is saved completely
- obvious syntax issues are checked
- **responsive CSS is present** — check for media queries, flexible grids, hamburger nav

Better:

- open in a browser tool and check console errors
- inspect screenshots at the primary viewport
- test key interactions
- test light/dark or variants if present
- test responsive breakpoints — resize to 375px width and verify layout adapts

If verification is limited by environment, say exactly what was and was not verified.

Never say “done” if the file was not actually written.

## Final Response Format

Keep final responses short.

Include:

- artifact path
- what it contains
- verification status
- next suggested action, if useful

Example:

```text
Created: /path/to/Prototype.html
It includes 3 layout variants, a Tweaks panel for density/theme, and responsive behavior.
Verified: file exists and opened cleanly in browser, no console errors.
Next: pick the strongest direction and I’ll tighten copy + motion.
```

## Portable Opening Prompt Pattern

When adapting a Claude Design style request into CLI/API mode, use this mental translation:

```text
You are running in CLI/API mode, not hosted Claude Design. Ignore references to hosted-only tools or preview panes. Produce complete local design artifacts, usually self-contained HTML with embedded CSS/JS, and verify with available local tools before returning. Preserve the design process: gather context, define the system, produce options, avoid filler, and meet a high visual bar.
```

## Executive Presentations & Business Cases

When the user needs to present a project, methodology, or business case to their team or stakeholders, use this pattern. The deliverable is a self-contained HTML file designed for projection/screen sharing.

### Two-Track Output

For executive presentations, produce **both**:
1. **`.md` document** — Structured text for reading, sharing on chat, or converting to PDF. Sections: problem, solution, data, economics, roadmap, conclusion.
2. **`.html` presentation** — Visual, designed for projection. Scroll-based single-page with sections, animations, and charts.

### HTML Presentation Pattern

**Structure:** Fixed nav → Hero (metrics) → Problem → Solution → Real Example → Business Model → Why → Investment → Closing CTA.

**Visual language for business presentations (WHITE BACKGROUND — David's preference):**
- **White background always** — clean, corporate, McKinsey/BCG style. No dark mode for business decks.
- Light gray (`#f9fafb`) for alternating sections, white for primary
- Blue accent (`#2563eb`) for headings, links, emphasis. Green/red for positive/negative data.
- Subtle borders (`1px solid #e5e7eb`) for cards and tables, no heavy shadows
- Inter font (300-900 weights), clean sans-serif
- Responsive: grid → single column on mobile

**Argument/point layout — NO icon+title+text cards:**
David explicitly rejects the "AI card pattern" (icon on top, title below, paragraph text). Instead use:
- **Numbered blocks:** Large faded number (01, 02, 03...) on the left, bold title + paragraph on the right, separated by thin horizontal lines
- **Horizontal split panels:** Left side = proposal/percentages, right side = example/results, in a single bordered container
- **Step lists:** Circled numbers (1, 2, 3...) with title + description + time indicator
- **Tables** for data comparisons — clean HTML tables with hover states

**Economic data presentation:**
- Show **annual totals**, not per-unit rates. "8.448€/año en transporte" is clear. "0,31€/minuto" is confusing.
- Always show: cost per mode → annual cost → salary context → % of salary consumed → salary after transport
- Callout box below tables explains the key insight in plain language
- The "paradox" or counterintuitive finding goes in a highlighted callout, not buried in a table

**Content rules:**
- Every number must be real or clearly labeled as estimate
- Include "the paradox" — the most counterintuitive finding that makes the business case
- End with a question that reframes the decision ("The question isn't if we can afford this. It's if we can afford NOT to.")
- Attribution footer: "Hecho con ❤️ por David Antizar"

**Anti-patterns to avoid:**
- ❌ Dark mode for business presentations (use white)
- ❌ Icon+title+text card grids (use numbered blocks or tables instead)
- ❌ Per-minute or per-unit cost breakdowns (use annual totals)
- ❌ Glass morphism / neon / dark aesthetic for corporate decks
- ❌ Generic SaaS landing page look
- ❌ Filler content, fake metrics, placeholder testimonials

### Markdown Presentation Pattern

**Structure:** Title → Problem → Solution → Data Table → Example → Economics → Standards → Roadmap → Conclusion.

**Format rules:**
- Tables for data comparisons (markdown tables render well)
- Emoji section headers for visual scanning
- Key quote in blockquote format
- Cost breakdown tables with "TOTAL" and "AHP" (Ahorro) rows
- Short paragraphs, no walls of text

### Pitfalls
- **Animated counters need IntersectionObserver** — `requestAnimationFrame` alone won't trigger on scroll. The observer fires the animation when the element enters the viewport.
- **Bar chart widths are percentages** — set `data-width` attribute, animate with CSS transition. Minimum visible width ~2% even for tiny values.
- **Mobile: hide nav links, stack grids** — `@media (max-width: 768px)` is the breakpoint. Grids go from 3-col → 1-col.
- **Font loading** — use Google Fonts `<link>` in HTML head for single-file portability.
- **David hates "AI card pattern"** — the typical icon-on-top + title + paragraph card layout is instantly recognizable as AI-generated. Use numbered blocks, horizontal splits, or table layouts instead.
- **Annual costs, not per-minute** — When showing transport/commute costs, always use annual totals (€/año) and % of salary. Per-minute rates are abstract and confusing for business audiences.
- **Font loading** — use Google Fonts `@import` in CSS, not `<link>` in HTML, for single-file portability.

## Renders and Floor Plans Without Image Generation

When image generation (FAL, DALL-E, etc.) is unavailable, create stylized renders and floor plans using pure HTML/CSS/SVG. This approach is production-ready and often preferred for technical documentation.

### Stylized Renders in HTML/CSS

Create minimalist, Scandinavian-style interior renders using CSS gradients, shapes, and shadows:

**Dormitorio:**
```css
.render-dormitorio { background: linear-gradient(180deg, #e8f5e9 0%, #c8e6c9 100%); }
.bed { 
    position: absolute; bottom: 50px; left: 20px; 
    width: 100px; height: 50px; 
    background: white; border-radius: 4px; 
    box-shadow: 0 2px 6px rgba(0,0,0,0.15); 
}
.bed::before { 
    content: ''; position: absolute; top: 5px; left: 5px; right: 5px; 
    height: 20px; background: #e3f2fd; border-radius: 2px; 
}
```

**Cocina:**
```css
.render-cocina { background: linear-gradient(180deg, #fff3e0 0%, #ffe0b2 100%); }
.counter { 
    position: absolute; bottom: 40px; left: 10px; right: 10px; 
    height: 40px; background: #e0e0e0; border-radius: 2px; 
}
.counter::before { 
    content: ''; position: absolute; top: 0; left: 0; right: 0; 
    height: 6px; background: #757575; border-radius: 2px 2px 0 0; 
}
```

**Baño:**
```css
.render-bano { background: linear-gradient(180deg, #e3f2fd 0%, #bbdefb 100%); }
.shower { 
    position: absolute; top: 20px; left: 20px; 
    width: 60px; height: 80px; 
    background: white; border-radius: 4px; border: 2px solid #e0e0e0; 
}
```

**Salón:**
```css
.render-salon { background: linear-gradient(180deg, #f3e5f5 0%, #e1bee7 100%); }
.sofa { 
    position: absolute; bottom: 50px; left: 20px; 
    width: 120px; height: 40px; 
    background: linear-gradient(180deg, #5d4037 0%, #4e342e 100%); 
    border-radius: 6px 6px 2px 2px; 
}
```

### 2D Floor Plans in SVG

Create floor plans using inline SVG with color-coded zones:

```html
<svg viewBox="0 0 400 280" xmlns="http://www.w3.org/2000/svg">
    <!-- Background -->
    <rect x="0" y="0" width="400" height="280" fill="#fafafa"/>
    
    <!-- Outer walls -->
    <rect x="20" y="20" width="360" height="240" fill="none" stroke="#333" stroke-width="3"/>
    
    <!-- Bedroom (green) -->
    <rect x="20" y="20" width="240" height="160" fill="#e8f5e9" stroke="#333" stroke-width="2"/>
    <text x="140" y="100" text-anchor="middle" font-size="11" fill="#333">Habitación</text>
    <text x="140" y="115" text-anchor="middle" font-size="9" fill="#666">18.50 m²</text>
    
    <!-- Kitchen (orange) -->
    <rect x="260" y="20" width="120" height="90" fill="#fff3e0" stroke="#333" stroke-width="2"/>
    <text x="320" y="70" text-anchor="middle" font-size="10" fill="#333">Cocina</text>
    
    <!-- Bathroom (blue) -->
    <rect x="260" y="110" width="120" height="70" fill="#e3f2fd" stroke="#333" stroke-width="2"/>
    <text x="320" y="150" text-anchor="middle" font-size="10" fill="#333">Baño</text>
    
    <!-- Window (cyan line) -->
    <line x1="80" y1="20" x2="140" y2="20" stroke="#2196f3" stroke-width="3"/>
</svg>
```

**Color coding for zones:**
- 🟢 Green (`#e8f5e9`): Dormitorios
- 🟠 Orange (`#fff3e0`): Cocinas
- 🔵 Blue (`#e3f2fd`): Baños
- 🟣 Purple (`#f3e5f5`): Salones
- ⬜ Gray (`#eceff1`): Otros espacios

### GitHub Pages Deployment

When deploying to GitHub Pages:

1. **Create workflow** `.github/workflows/deploy.yml`:
```yaml
name: Deploy to GitHub Pages
on:
  push:
    branches: [ master ]
permissions:
  contents: read
  pages: write
  id-token: write
jobs:
  deploy:
    environment:
      name: github-pages
      url: ${{ steps.deployment.outputs.page_url }}
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/configure-pages@v4
      - uses: actions/upload-pages-artifact@v3
        with: { path: '.' }
      - uses: actions/deploy-pages@v4
        id: deployment
```

2. **Enable Pages** via API or repository settings (source: master branch)

3. **Wait 2-5 minutes** for initial deployment

## Pitfalls

- Do not paste hosted tool schemas into a skill. They cause fake tool calls.
- Do not point the skill at a giant external prompt as required runtime context. That creates drift.
- Do not strip the design doctrine while removing tool plumbing.
- Do not over-ask when the user already gave enough direction.
- Do not under-ask for high-fidelity work with no brand context.
- Do not produce generic SaaS layouts and call them designed.
- Do not claim browser verification unless it actually happened.
- **Image generation unavailable:** When FAL_KEY or other image gen provider is not configured, fall back to HTML/CSS stylized renders — they are often better for technical documentation anyway.
- **GitHub Pages deployment:** Initial deployment takes 2-5 minutes. Do not report failure until waiting at least 3 minutes.
