---
name: gtfs-browser-parser
description: Parser GTFS completo en navegador + catalogo de operadores por ciudad, busqueda por proximidad, fuentes multiples (cache, ZIP subido, localStorage, proxy), integracion mapa, PDF, y v2.3 con parseo completo GTFS (calendar_dates, frequencies, transfers, feed_info), sin limites en stop_times, shapes completos (sin clip)
version: "2.3.0"
tags: [gtfs, transporte, parser, navegador, movilidad, isocronas]
---

# GTFS Browser Parser — Patrón completo de Integración GTFS

## Descripción

Patrón para integrar datos GTFS de transporte público en aplicaciones web del navegador: detección de ciudad y operadores, carga selectiva de paradas cercanas, visualización en mapa Leaflet, informe PDF y exportación GeoJSON.

## Origen

Derivado de [nap-dashboard](https://github.com/Ntizar/nap-dashboard) (API NAP España) y [TimeIneco](https://timeineco-ntizar-ntizar.apps.nan.builders/) v0.7 (isocronas de movilidad laboral).

## Arquitectura General

```
User input (address)
  → geocode → ciudad detectada
  → catálogo operadores → usuario selecciona
  → cargar GTFS (cache / upload / proxy / localStorage)
  → findStopsNear(punto, radio 2km) → filtrar por Haversine
  → UI: chips de rutas + marcadores mapa + tabla detalle
  → PDF: seccion "Rutas de transporte publico disponibles"
  → Export: GeoJSON de paradas cercanas
```

## Estrategia de Carga: Filtrar en Origen

**REGLAS DE ORO:**

1. **No descargar todo el GTFS** — un feed de ciudad puede pesar 50-200 MB. Solo extrae paradas cercanas al punto de interés del usuario.
2. **El usuario elige el operador** — muestra catálogo de operadores por ciudad, el usuario selecciona uno, solo entonces descargas/cargas su GTFS.
3. **Múltiples fuentes, por orden de prioridad:**
   - Cache simulado (JSON embebido para demo)
   - localStorage (datos previamente cargados)
   - ZIP subido por usuario (el método más práctico)
   - Proxy servidor (descarga desde URL pública)

## Patrón: Catálogo de Operadores por Ciudad

```javascript
const EMPRESAS = {
  madrid: [
    { id: 'emt-madrid', nombre: 'EMT Madrid', modo: 'bus', lineas: 217,
      cacheable: true,  // cacheable = datos simulados embebidos
      gtfsUrl: 'https://opendata.emtmadrid.es/GTFS/Madrid' },
    { id: 'metro-madrid', nombre: 'Metro de Madrid', modo: 'metro', lineas: 13,
      cacheable: false } // requiere subida de ZIP
  ],
  barcelona: [
    { id: 'tmb-bus', nombre: 'TMB (Autobus)', modo: 'bus', lineas: 107, cacheable: false }
  ],
  // ~12+ ciudades espanolas con operadores catalogados
};

function detectarCiudad(displayName) {
  // 1. Buscar en EMPRESAS
  // 2. Fallback: matchear contra lista de ~50 ciudades
  // 3. Si no hay match, mostrar opcion de subir GTFS manualmente
}
```

## Patrón: Búsqueda por Proximidad (Haversine)

Solo extraer paradas dentro de un radio del punto de origen (default 2 km):

```javascript
function findStopsNear(lat, lng, radiusKm = 2) {
  const results = [];
  for (const stop of stops) {
    const dist = haversine(lat, lng, stop.stop_lat, stop.stop_lon);
    if (dist <= radiusKm) {
      const routeIds = stopRoutes[stop.stop_id] || [];
      results.push({ stop, distanciaKm: dist, routes: routeIds });
    }
  }
  results.sort((a, b) => a.distanciaKm - b.distanciaKm);
  return results;
}

function haversine(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat/2)**2 +
    Math.cos(lat1*Math.PI/180) * Math.cos(lat2*Math.PI/180) * Math.sin(dLon/2)**2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}
```

## Patrón: Ruteo Inferido (sin stop_times)

Cuando no hay `stop_times.txt` ni `trips.txt`, inferir rutas por coincidencia semántica de nombres:

```javascript
// Modo 1: Coincidencia de palabras entre route_long_name y stop_name
for (const route of data.routes) {
  const routeWords = route.route_long_name.toLowerCase();
  for (const stop of data.stops) {
    for (const word of routeWords.split(/[\s/]+/)) {
      if (word.length > 3 && stop.stop_name.toLowerCase().includes(word)) {
        stopRoutes[stop.stop_id].add(route.route_id);
      }
    }
  }
}

// Modo 2: Fallback — paradas céntricas reciben rutas base
const centralStops = stops.filter(s =>
  s.stop_name.includes('Sol') || s.stop_name.includes('Gran Via') || ...);
```

## Patrón: Múltiples Fuentes de Datos

### 1. Cache simulado (JSON embebido)
```javascript
function cargarDesdeCache(cacheData, operador, ciudad) {
  // cacheData: { routes, stops, stop_times?, trips?, shapes?, _meta }
  construirIndiceStopRoutes(cacheData);
  guardarEstado(operador, ciudad);
  persistirEnLocalStorage(ciudad, operador, data);
}
```

### 2. ZIP subido por usuario
```javascript
async function cargarDesdeZip(file, operador, ciudad) {
  const zip = await JSZip.loadAsync(file);
  const stops = parsearCSV(await leerCSVZip(zip, 'stops.txt'));
  const routes = parsearCSV(await leerCSVZip(zip, 'routes.txt'));
  const trips = parsearCSV(await leerCSVZip(zip, 'trips.txt').catch(()=>''));
  const stopTimes = parsearCSV(await leerCSVZip(zip, 'stop_times.txt').catch(()=>''));
  // Construir indice stop→routes via trips+stopTimes
  // Cargar en estado y cachear en localStorage
}
```

### 3. Proxy servidor (para CORS)
```javascript
// server.mjs
if (req.url.startsWith('/gtfs-download') && req.method === 'POST') {
  const { url } = JSON.parse(body);
  https.get(url, { headers: { 'User-Agent': 'App/1.0' } }, (proxyRes) => {
    const chunks = [];
    proxyRes.on('data', chunk => chunks.push(chunk));
    proxyRes.on('end', () => {
      res.end(Buffer.concat(chunks)); // Streamear ZIP al cliente
    });
  });
}
```

## Patrón: Integración con Mapa Leaflet

```javascript
const iconoParada = L.divIcon({
  html: '<div style="width:10px;height:10px;background:#a855f7;border:2px solid #fff;border-radius:50%;box-shadow:0 1px 4px rgba(0,0,0,0.3)"></div>',
  iconSize: [10, 10], iconAnchor: [5, 5], className: ''
});

for (const item of stopsNear) {
  L.marker([item.stop.stop_lat, item.stop.stop_lon], { icon: iconoParada })
    .bindPopup(`${item.stop.stop_name} (${item.distanciaKm.toFixed(2)} km)<br>${item.routes.length} rutas`)
    .addTo(capaParadas);
}
```

## Patrón: Integración con PDF (jsPDF)

Sección en informes PDF con:
- Tabla de paradas cercanas (nombre, distancia, líneas que sirven)
- Líneas destacadas con paradas que cubren
- Operador, fuente de datos y modo predominante

```javascript
if (gtfsData && gtfsData.totalStops > 0) {
  // Tabla con autoTable: cabecera morada (#a855f7)
  // Columnas: Parada | Distancia | Lineas
  // Max 12 paradas, 10 lineas destacadas
}
```

## Patrón: Exportación GeoJSON

```javascript
function exportarParadasGeoJSON() {
  const features = stops.map(s => ({
    type: 'Feature',
    geometry: { type: 'Point', coordinates: [s.stop_lon, s.stop_lat] },
    properties: { stop_id: s.stop_id, stop_name: s.stop_name }
  }));
  return {
    type: 'FeatureCollection',
    features,
    properties: { fuente: `TimeIneco GTFS — ${operador}`, totalStops: features.length }
  };
}
```

## Patrón: Resumen para UI

```javascript
function getRouteSummary(stopsNear) {
  const rutasUnicas = new Map();
  for (const item of stopsNear) {
    for (const r of item.routes) {
      if (!rutasUnicas.has(r.id)) rutasUnicas.set(r.id, { ...r, paradas: [] });
      rutasUnicas.get(r.id).paradas.push(item.stop.stop_name);
    }
  }
  return {
    operador, ciudad,
    totalStops: stopsNear.length,
    totalRoutes: rutasUnicas.size,
    rutas: [...rutasUnicas.values()],
    modoPredominante, datosFuente
  };
}
```

## CSV Parser (con soporte de comillas + auto-detección de delimiter)

**CRÍTICO:** Algunos GTFS usan `\t` (tab) o `;` (punto y coma) en vez de `,`. Si hardcodeas `,`, las líneas se parsean como un solo campo → `stop.routes` siempre vacío → "0 rutas" en UI sin error visible.

```javascript
function detectDelimiter(headerLine) {
  const comma = (headerLine.match(/,/g) || []).length;
  const tab = (headerLine.match(/\t/g) || []).length;
  const semi = (headerLine.match(/;/g) || []).length;
  if (tab > comma && tab > semi) return '\t';
  if (semi > comma) return ';';
  return ',';
}

function parsearCSV(text) {
  const lines = text.trim().split('\n');
  if (lines.length < 2) return [];
  const delimiter = detectDelimiter(lines[0]);
  const headers = lines[0].split(delimiter).map(h => h.trim().replace(/^"|"$/g, ''));
  const result = [];
  for (let i = 1; i < lines.length; i++) {
    const values = parsearLineaCSV(lines[i], delimiter);
    if (values.length !== headers.length) continue;
    const row = {};
    for (let j = 0; j < headers.length; j++) row[headers[j]] = values[j] || '';
    result.push(row);
  }
  return result;
}

function parsearLineaCSV(line, delimiter = ',') {
  const result = []; let current = ''; let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    if (line[i] === '"') inQuotes = !inQuotes;
    else if (line[i] === delimiter && !inQuotes) { result.push(current.trim()); current = ''; }
    else current += line[i];
  }
  result.push(current.trim());
  return result;
}
```

**Pitfall: parseCSVLine sin delimiter causa "0 rutas" silencioso** — Si llamas `parsearLineaCSV(line)` sin pasar el delimiter, `delimiter` defaulta a `','` pero el archivo puede usar `\t`. El resultado es `vals = [línea_completa]` → `vals.length === 1` → se salta la fila. Todos los stop_times se ignoran → `stop.routes` siempre vacío. **FIX:** Siempre auto-detectar delimiter y pasarlo explícitamente a ambas funciones.

## Implementación Recomendada en Hermes

1. Usar `JSZip` (CDN en index.html) para descompresión ZIP del lado cliente
2. Catálogo de operadores como constante JS (con cacheable flag)
3. Motor GTFS: `gtfs-engine.js` con estado global, findStopsNear, getRouteSummary
4. Panel NAP: `nap.js` como facade de UI con manejo de eventos delegados
5. Mapa: marcadores Leaflet con divIcon y popups informativos
6. PDF: jsPDF + autoTable, colores #a855f7 para cabeceras GTFS
7. Cache en localStorage con prefijo `timeineco_gtfs_`
8. Evento `gtfs:loaded` para sincronizar carga de GTFS con mapa

## Scripts del skill

- `scripts/server-gtfs.py` — Servidor mínimo con /api/zips para auto-carga de ZIPs. `python server-gtfs.py` desde la raiz del proyecto.

## Patrón: Auto-carga de ZIPs desde servidor local (v3.0)

**NUEVO en 2026-06-23:** En vez de arrastrar ZIPs manualmente, el visor se conecta a un servidor mínimo que lista los ZIPs disponibles en `data/` y los carga automáticamente.

### Servidor mínimo (server.py)

```python
# visor/server.py — servidor mínimo HTTP con /api/zips
import http.server, json, os
from pathlib import Path

class GTFSServer(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/api/zips':
            self.serve_zips_list()
            return
        super().do_GET()
    
    def serve_zips_list(self):
        zips = []
        for root, dirs, files in os.walk(DATA_DIR):
            for f in files:
                if f.endswith('.zip'):
                    full_path = Path(root) / f
                    rel_path = full_path.relative_to(BASE_DIR)
                    zips.append({
                        "name": f, "path": str(rel_path).replace("\\", "/"),
                        "size": full_path.stat().st_size,
                        "size_human": f"{full_path.stat().st_size / 1024 / 1024:.1f} MB"
                    })
        zips.sort(key=lambda x: x["name"])
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(json.dumps(zips, indent=2).encode())
```

### Auto-carga en el cliente

```javascript
async function autoLoadZips() {
    let zipsList = [];
    try { const resp = await fetch('/api/zips'); if (resp.ok) zipsList = await resp.json(); } catch (e) {}
    if (zipsList.length === 0) return;
    
    const MAX_ZIPS = 25;
    const toLoad = zipsList.slice(0, MAX_ZIPS);
    for (const zf of toLoad) {
        const resp = await fetch('/' + zf.path);
        const blob = await resp.blob();
        const zip = await JSZip.loadAsync(blob);
        await processGTFS(zip, zf.name);
    }
}
```

### Launcher para Windows (.bat)

```bat
@echo off
chcp 65001 >nul
python --version >nul 2>&1 || (echo [ERROR] Python no encontrado & pause & exit /b 1)
cd visor
python server.py
```

### Patrón: Panel de horarios de parada (bottom slide)

Al hacer clic en una parada → panel deslizante desde abajo con rutas y horarios.

```javascript
function showSchedulePanel(stop) {
    const routesData = stop.routes.map(rid => allRoutes[rid]).filter(Boolean);
    // Filtros de ruta como botones clickeables
    // Cards expandibles por ruta con tabla de horarios
    const panel = document.getElementById('schedulePanel');
    panel.innerHTML = htmlContent;
    panel.classList.add('open');
}
```

CSS: `transform: translateY(100%)` → `.open { transform: translateY(0); }` con `transition: 0.3s ease`

### Patrón: Líneas clickeables + Panel de ruta detallado (v2.1)

**NUEVO en 2026-07-02:** Los polylines (shapes) de las rutas en el mapa son **clickeables**. Al hacer click se abre un **panel de ruta** deslizante desde la derecha con toda la info de la línea: paradas ordenadas, timetable completo, direcciones/headsigns. Derivado de GTFSSpain v2 (`github.com/Ntizar/GTFSSpain-v2`).

#### Arquitectura del panel de ruta

```
┌─────────────────────────────────────────────────────┐
│  Mapa Leaflet (shapes clickeables + hover)          │
│                                                     │
│  Click en polyline ──► Panel de ruta (slide right)  │
│                                                     │
├──────────────┬──────────────────────────────────────┤
│ Sidebar      │  ┌─── Panel de Ruta (420px) ──────┐  │
│ [Buscar]     │  │ Badge coloreado + Nombre       │  │
│ [Líneas]     │  │ KPIs: viajes | paradas | dirs  │  │
│ [Datos]      │  │ Filtro por dirección (tabs)    │  │
│              │  │ Paradas ordenadas (ol con num)  │  │
│              │  │ Timetable filtrable por dir     │  │
│              │  └────────────────────────────────┘  │
└──────────────┴──────────────────────────────────────┘
```

#### Polylines clickeables con hover

```javascript
const line = L.polyline(coords, {
    color: color, weight: 5, opacity: 0.7, smoothFactor: 2
});
// Click → abre panel de detalle de la ruta
line.on('click', (e) => { L.DomEvent.stop(e); openRouteDetail(routeId); });
// Hover → efecto visual
line.on('mouseover', function() { this.setStyle({ weight: 8, opacity: 1 }); });
line.on('mouseout', function() { this.setStyle({ weight: 5, opacity: 0.7 }); });
line.bindPopup(`<b>${route.shortName}</b> — ${route.longName}<br><small>Click para ver horarios</small>`);
```

**Pitfall:** `L.DomEvent.stop(e)` es OBLIGATORIO en el handler de click del polyline. Sin esto, el click se propaga al mapa y dispara el `map.on('click')` que busca paradas, cerrando el panel de ruta inmediatamente.

#### Panel de ruta deslizante (slide from right)

```css
.route-detail-panel {
    position: fixed; top: var(--header-height); right: 0; bottom: 0;
    width: 420px; background: white; border-left: 2px solid var(--azul);
    z-index: 1500; transform: translateX(100%);
    transition: transform 0.3s ease; overflow-y: auto;
}
.route-detail-panel.open { transform: translateX(0); }
```

#### Paradas ordenadas por stop_sequence

Para obtener las paradas de una ruta en orden correcto, buscar el viaje (trip) con más paradas:

```javascript
function getRouteStopsOrdered(routeId) {
    const tripStops = {};
    Object.entries(allStopTimes).forEach(([stopId, times]) => {
        times.forEach(st => {
            if (tripRouteMap[st.trip_id] === routeId) {
                if (!tripStops[st.trip_id]) tripStops[st.trip_id] = [];
                tripStops[st.trip_id].push({ stopId, sequence: st.stop_sequence });
            }
        });
    });
    // Pick trip with most stops (most complete route)
    let longestTrip = null, maxStops = 0;
    Object.entries(tripStops).forEach(([tid, stops]) => {
        if (stops.length > maxStops) { maxStops = stops.length; longestTrip = tid; }
    });
    if (!longestTrip) return [];
    return tripStops[longestTrip]
        .sort((a, b) => a.sequence - b.sequence)
        .map(s => allStops.find(st => st.id === s.stopId))
        .filter(Boolean);
}
```

#### Filtro de timetable por headsign/dirección

```javascript
function buildTimetableHTML(routeId, headsignsMap, filterHeadsign) {
    const groups = filterHeadsign === 'all'
        ? headsignsMap
        : { [filterHeadsign]: headsignsMap[filterHeadsign] || [] };
    // Render table per group with departure times
}
```

#### Explorador de líneas (sidebar tab)

Pestaña en el sidebar que lista todas las rutas cargadas con búsqueda:

```javascript
function updateRouteExplorer() {
    const routes = Object.values(allRoutes)
        .sort((a, b) => a.shortName.localeCompare(b.shortName, undefined, { numeric: true }));
    // Render route items with badge (colored), name, agency, trip count
}
function filterRoutes(query) {
    const q = query.toLowerCase();
    document.querySelectorAll('.route-item').forEach(item => {
        item.style.display = item.textContent.toLowerCase().includes(q) ? '' : 'none';
    });
}
```

#### Link desde parada → detalle de ruta

En el panel de horarios de cada parada, incluir botón "Ver ruta completa":

```html
<button class="link-to-route" onclick="openRouteDetail('${routeId}')">📋 Ver ruta completa</button>
```

#### Highlight de ruta en mapa

Al abrir detalle de ruta, resaltar la polyline y hacer zoom:

```javascript
function highlightRoute(routeId) {
    const shapeId = routeShapeMap[routeId];
    if (shapeId && allShapeCoords[shapeId]) {
        highlightLayer = L.polyline(allShapeCoords[shapeId], {
            color: color, weight: 8, opacity: 1
        }).addTo(map);
        map.fitBounds(highlightLayer.getBounds(), { padding: [50, 50] });
    }
}
```

#### Estado global necesario para rutas

```javascript
let routeShapeMap = {};    // route_id → shape_id (first shape found)
let routeTripCount = {};   // route_id → count of trips
let tripRouteMap = {};     // trip_id → route_id
// Construir en processGTFS(): recorrer trips.txt para enlazar
```

## GTFS — Archivos opcionales que DEBES parsear (v2.2)

**NUEVO 2026-07-02:** Muchos visores solo parsean stops, routes, trips, stop_times y shapes. Esto deja información crítica sin usar. Los siguientes archivos son opcionales pero MUY valiosos:

### calendar_dates.txt (CRÍTICO — algunos feeds SOLO tienen esto)
```javascript
// EMT Fuenlabrada NO tiene calendar.txt, solo calendar_dates.txt
const calDatesFile = zip.file('calendar_dates.txt');
if (calDatesFile) {
    const calData = parseCSV(await calDatesFile.async('string'));
    calData.forEach(c => {
        if (!allCalendarDates[c.service_id]) allCalendarDates[c.service_id] = [];
        allCalendarDates[c.service_id].push({
            date: c.date,  // "20260626"
            exception_type: parseInt(c.exception_type)  // 1=added, 2=removed
        });
    });
}
```

### frequencies.txt (frecuencias por tramo horario)
```javascript
const freqFile = zip.file('frequencies.txt');
if (freqFile) {
    const freqData = parseCSV(await freqFile.async('string'));
    freqData.forEach(f => {
        allFrequencies.push({
            trip_id: f.trip_id, start_time: f.start_time,
            end_time: f.end_time, headway_secs: parseInt(f.headway_secs)
        });
    });
}
```

### transfers.txt (transbordos entre paradas)
```javascript
const transfersFile = zip.file('transfers.txt');
if (transfersFile) {
    const tData = parseCSV(await transfersFile.async('string'));
    tData.forEach(t => {
        const fromId = t.from_stop_id + '_' + zipName;
        const toId = t.to_stop_id + '_' + zipName;
        if (!allTransfers[fromId]) allTransfers[fromId] = [];
        allTransfers[fromId].push({
            to_stop_id: toId,
            transfer_type: parseInt(t.transfer_type),  // 0=timed, 1=min time, 2=boarding, 3=none
            min_transfer_time: parseInt(t.min_transfer_time || '0')
        });
    });
}
```

### feed_info.txt (info del proveedor)
```javascript
const feedInfoFile = zip.file('feed_info.txt');
if (feedInfoFile) {
    const feedData = parseCSV(await feedInfoFile.async('string'));
    if (feedData.length > 0) allFeedInfo.push({
        publisher: feedData[0].feed_publisher_name,
        version: feedData[0].feed_version,
        start_date: feedData[0].feed_start_date,
        end_date: feedData[0].feed_end_date
    });
}
```

### Variables globales necesarias
```javascript
let allCalendarDates = {};   // service_id -> [{date, exception_type}]
let allFrequencies = [];     // [{trip_id, start_time, end_time, headway_secs}]
let allTransfers = {};       // stopId -> [{to_stop_id, transfer_type, min_transfer_time}]
let allFeedInfo = [];        // [{publisher, version, start_date, end_date}]
let tripDirectionMap = {};   // tripId -> direction_id (0=IDA, 1=VUELTA)
```

## Regla de rendering: Shapes COMPLETOS en mapa (v2.3)

**Preferencia de David (2026-07-02):** Las rutas se muestran **completas** desde el primer momento, sin clip al círculo de búsqueda. El círculo solo indica el área de interés; las rutas que la atraviesan se ven enteras para dar contexto de cobertura real.

**MAL (v2.1 — clippeado):**
```javascript
const clippedCoords = clipShapeToSearchArea(allShapeCoords[shapeId], nearStopCoords, radius);
if (!clippedCoords || clippedCoords.length < 2) return;
const line = L.polyline(clippedCoords, { color: color, weight: 5, opacity: 0.85 });
```

**BIEN (v2.3 — ruta completa):**
```javascript
const fullCoords = allShapeCoords[shapeId];
const line = L.polyline(fullCoords, { color: color, weight: 5, opacity: 0.85, smoothFactor: 2 });
// El círculo de búsqueda sigue visible como referencia visual
// Al hacer click → highlightRoute() con fitBounds para zoom a la ruta completa
```

**¿Por qué?** El usuario quiere ver la ruta entera para entender por dónde pasa realmente. El círculo de búsqueda muestra qué paradas están cerca; las líneas muestran la infraestructura completa. No hay razón práctica para ocultar la parte "fuera" del círculo.

**Si se necesita clip** (caso raro: decenas de rutas superpuestas que saturan el mapa), usar `clipShapeToSearchArea()` pero con un buffer generoso (400m+) para mantener continuidad visual. Ver función en el código fuente de GTFSSpain v2.
```javascript
// Línea de fondo que dibuja la ruta COMPLETA — ELIMINAR
const bgLine = L.polyline(allShapeCoords[shapeId], {
    color: color, weight: 2, opacity: 0.15, smoothFactor: 2, dashArray: '4,6'
});
```

**BIEN (v2.3):** Ruta completa con el círculo como referencia visual:

## Regla: stop_times.txt sin límite artificial

**NUEVO 2026-07-02:** El v2.1 tenía `Math.min(lines.length, 200000)` que truncaba stop_times. El v2.2 quitó esto y procesa TODAS las líneas. Consequence: algunos feeds grandes (Cataluña completa: 249MB stop_times) tardan más en parsear pero dan datos completos.

**Decisión:** Si el feed es >500MB stop_times, considerar Web Worker o streaming. Pero para la mayoría de feeds del NAP (10-100MB), el parseo directo funciona bien.

### Convención: Mejorar proyecto existente sin romperlo

**Regla de David:** Cuando un proyecto funciona y se quiere mejorar, **nunca modificar el repo original**. Crear un v2 en un repositorio nuevo, compartir datos via symlink.

```
proyecto-v2/
├── data → ../proyecto-v1/data/   # symlink (no copia)
├── index.html                    # HTML en RAÍZ (necesario para Pages)
├── visor/index.html              # Cópia de backup en subdirectorio
└── README.md                     # Informe de cambios
```

**Git:** El symlink `data` NO se commitea (pesado). El `.gitignore` excluye `data/`. El v2 referencia datos del v1 sin duplicar.

### Pitfall CRÍTICO: GitHub Pages sirve README en vez de la app

**Causa:** GitHub Pages configurado con source path `/` solo busca archivos en la raíz del repo. Si tu `index.html` está en un subdirectorio (como `visor/index.html`), Pages no lo encuentra y sirve el `README.md` en su lugar.

**Síntoma:** La URL `https://usuario.github.io/repo/` muestra el README renderizado en vez de la aplicación.

**FIX:** Copiar `visor/index.html` a la raíz del repo:
```bash
cp visor/index.html ./index.html
git add index.html
git commit -m "fix: index.html en raíz para que GitHub Pages lo sirva correctamente"
git push origin main
```

**Verificación post-fix:**
```bash
curl -s "https://usuario.github.io/repo/" | head -5
# Debe mostrar <!DOCTYPE html> del visor, NO el README en markdown
curl -s -o /dev/null -w "%{http_code}" "https://usuario.github.io/repo/index.html"
# Debe devolver 200
```

**Por qué ocurre:** Pages con source `/` prioriza `index.html` sobre `README.md` cuando ambos existen en la raíz. Pero si solo hay `README.md` en la raíz (y tu app está en `visor/`), Pages renderiza el README.

**Prevención:** Siempre colocar el `index.html` principal en la raíz del repo cuando se usa GitHub Pages. Mantener la copia en el subdirectorio para organización local.

## Pitfalls

- **Ficheros grandes** (>15 MB descomprimidos) pueden tardar varios segundos — el parsing ocurre en el hilo principal
- **stop_times masivo** — NO limitar el parseo de stop_times.txt (no artificial caps). Si el feed tiene 500K+ líneas, procesar todas. El límite anterior de 200K causaba datos truncados en feeds grandes como EMT Fuenlabrada (101K stop_times). Para feeds extremadamente grandes (>1M), usar Web Worker o streaming parsing.
- **stop_times sin trips** — si tienes stop_times pero no trips, no puedes enlazar paradas a rutas
- **Ruteo inferido impreciso** — la coincidencia semantica de nombres es heuristica y puede fallar
- **localStorage lleno** — datos GTFS grandes (>5 MB) pueden exceder el limite (~5-10 MB)
- **JSZip no disponible** — asegurarse de cargar la CDN ANTES del modulo principal
- **CORS en descargas GTFS** — la mayoria de feeds publicos no permiten CORS; usar proxy servidor
- **Coordenadas de paradas** — stop_times no lleva coordenadas; siempre referenciar a stops.txt
- **Dedup de paradas** — al filtrar por proximidad, agrupar paradas a menos de ~100m para no saturar el mapa
- **Encoding corrupto** — detectar caracteres U+FFFD y fallback a Windows-1252
- **calendar_dates sin calendar.txt** — algunos feeds usan solo calendar_dates, hay que soportarlo
- **CSV delimiter incorrecto causa "0 rutas" silencioso** — Si el parser hardcodea `,` como delimiter pero el GTFS usa `\t` o `;`, TODOS los stop_times se ignoran (vals.length === 1). stop.routes queda vacío → UI muestra "0 rutas" sin error. SIEMPRE auto-detectar delimiter del header antes de parsear. Ver función `detectDelimiter()` en la sección CSV Parser de este skill.
- **Síntoma "0 rutas"** — Cuando stop_times no se parsean correctamente, la cadena stop→trip→route se rompe. Si ves "0 rutas" en una parada que debería tener líneas, el primer sospechoso es el parser CSV: verificar que detectDelimiter devuelve el delimiter correcto y que parsearLineaCSV recibe el delimiter como segundo argumento.

## Pitfall CRÍTICO: Embebido de JSZip inline

**NUNCA** embebas JSZip como `var jszip = 'contenido';` dentro de un `<script>` tag. El contenido de JSZip contiene comillas y caracteres que rompen el string y el HTML.

**MÉTODO CORRECTO:** Insertar JSZip como un `<script>` inline independiente ANTES del script principal:

```html
<script>/* JSZip v3.10.1 minified content here */</script>
<script>
// Tu código del visor que usa JSZip
</script>
```

**MÉTODO INCORRECTO (roto):**
```html
<script>var jszip = '...contenido JSZip...';</script>
```

**Verificación post-embebido:**
1. `document.querySelectorAll('script').length` debe ser 3 (Leaflet CDN + JSZip inline + visor)
2. `typeof JSZip !== 'undefined'` debe ser `true`
3. `typeof window.initMap !== 'undefined'` debe ser `true`
4. Si `initMap` es `undefined`, el script del visor NO se ejecutó — revisa cierres `</script>`

**Patrón de fallo conocido:** Si al hacer un `replace` en el HTML se pierden los cierres `</script>`, `</body>`, `</html>`, el navegador no renderiza el mapa. Siempre verificar que el HTML tiene los 3 cierres.

## Pitfall: Script inline no se ejecuta

Si un `<script>` inline tiene funciones `async`/`await`, `eval()` y `new Function()` fallan con "Unexpected identifier". Esto NO significa que el script tenga error de sintaxis — el navegador ejecuta scripts inline con async/await correctamente. Para depurar, verificar `typeof window.initMap` en la consola del navegador (no usar `eval`).

## Referencias

**Nuevo 2026-06-25:** GBFS v3.0 tiene diferencias estructurales importantes con v2.x. Ver `references/gbfs-v3-parsing.md` para:
- Discovery feeds en `data.data.feeds` (no `data.feeds`)
- `num_vehicles_available` en vez de `num_bikes_available`
- `name` como array `[{text, language}]` (no string)
- Booleanos vs enteros para `is_installed`/`is_renting`
- Patrones de health check por plataforma

## GTFS Sintético Realista (generación programática)

Cuando no se puede descargar un GTFS real, generar uno sintético con datos realistas:

**Script de referencia:** `scripts/generate-gtfs-synthetic.py` (ver skill `timeineco` sección GTFS Multi-Ciudad)

**Características del GTFS sintético:**
- Paradas con nombres reales de la ciudad (centros, barrios, estaciones)
- Rutas basadas en líneas reales del operador
- Coordenadas geográficas reales (lat/lng de la ciudad)
- Shapes con interpolación entre paradas
- Horarios con intervalos realistas (2-5 min entre paradas)
- Trips de ida y vuelta por cada ruta
- Calendario weekday/saturday/sunday

**Estructura mínima necesaria para búsqueda de paradas:**
- `routes[]` + `stops[]` + `route_stops{}` → suficiente para `findStopsNear()`
- `trips[]` + `stop_times[]` → necesario para isocronas basadas en GTFS (BFS)
- `shapes[]` → necesario para visualizar trazados en mapa

**Pitfall:** Un GTFS sintético con solo `stops[]` y `route_stops{}` funciona para búsqueda de paradas cercanas pero NO para simulación de isocronas basadas en rutas GTFS (motor BFS necesita `stop_times[]` y `trips[]`).

## GTFS Pre-caching en servidor (patrón Time v2.0)

**Nuevo 2026-06-25:** Cuando se dispone de GTFS raw (ZIPs de NAP), crear un cache compacto JSON en el servidor que el frontend cargue automáticamente sin upload manual.

### Flujo

```
GTFS raw (ZIP de NAP)
  → Script Python pre-procesador (extrae stops, routes, trips, stop_times)
  → JSON compacto por ciudad (data/gtfs-cache/{ciudad}.json)
  → Endpoint servidor: /gtfs-cache/:city
  → Frontend: auto-detecta ciudad → fetch JSON →Motor GTFS
```

### Script pre-procesador Python

```python
# scripts/procesar-gtfs-cache.py
import json, csv, zipfile, io, sys, os

def procesar_gtfs(zip_path, city_name):
    data = {'stops': [], 'routes': [], 'trips': [], 'stop_times': [], '_meta': {}}
    with zipfile.ZipFile(zip_path) as z:
        # stops.txt
        with z.open('stops.txt') as f:
            reader = csv.DictReader(io.TextIOWrapper(f, encoding='utf-8-sig'))
            for row in reader:
                data['stops'].append({
                    'stop_id': row['stop_id'],
                    'stop_name': row['stop_name'],
                    'stop_lat': float(row['stop_lat']),
                    'stop_lon': float(row['stop_lon'])
                })
        # routes.txt
        with z.open('routes.txt') as f:
            reader = csv.DictReader(io.TextIOWrapper(f, encoding='utf-8-sig'))
            for row in reader:
                data['routes'].append({
                    'route_id': row['route_id'],
                    'route_short_name': row.get('route_short_name', ''),
                    'route_long_name': row.get('route_long_name', ''),
                    'route_type': row.get('route_type', '3')
                })
        # trips.txt (opcional)
        if 'trips.txt' in z.namelist():
            with z.open('trips.txt') as f:
                reader = csv.DictReader(io.TextIOWrapper(f, encoding='utf-8-sig'))
                for row in reader:
                    data['trips'].append({
                        'trip_id': row['trip_id'],
                        'route_id': row['route_id']
                    })
        # stop_times.txt (opcional, limitar a 100k)
        if 'stop_times.txt' in z.namelist():
            with z.open('stop_times.txt') as f:
                reader = csv.DictReader(io.TextIOWrapper(f, encoding='utf-8-sig'))
                for i, row in enumerate(reader):
                    if i >= 100000: break
                    data['stop_times'].append({
                        'trip_id': row['trip_id'],
                        'stop_id': row['stop_id'],
                        'departure_time': row.get('departure_time', '')
                    })

    data['_meta'] = {
        'city': city_name,
        'stops_count': len(data['stops']),
        'routes_count': len(data['routes']),
        'trips_count': len(data['trips']),
        'stop_times_count': len(data['stop_times'])
    }
    return data
```

### Endpoint servidor (server.mjs)

```javascript
// /gtfs-cache/list → lista ciudades disponibles
app.get('/gtfs-cache/list', (req, res) => {
    const cacheDir = path.join(__dirname, 'data', 'gtfs-cache');
    const files = fs.readdirSync(cacheDir).filter(f => f.endsWith('.json'));
    const cities = files.map(f => {
        const data = JSON.parse(fs.readFileSync(path.join(cacheDir, f)));
        return { city: f.replace('.json', ''), ...data._meta };
    });
    res.json(cities);
});

// /gtfs-cache/:city → devuelve JSON compacto
app.get('/gtfs-cache/:city', (req, res) => {
    const cacheFile = path.join(__dirname, 'data', 'gtfs-cache', `${req.params.city}.json`);
    if (!fs.existsSync(cacheFile)) return res.status(404).json({ error: 'Ciudad no encontrada' });
    res.setHeader('Cache-Control', 'public, max-age=86400'); // 24h cache
    res.json(JSON.parse(fs.readFileSync(cacheFile)));
});
```

### Frontend: auto-carga por ciudad

```javascript
// En nap.js o main.js
async function cargarDesdeServidor(ciudad) {
    try {
        const resp = await fetch(`/gtfs-cache/${ciudad}`);
        if (!resp.ok) return null;
        const data = await resp.json();
        // Alimentar el motor GTFS existente
        construirIndiceStopRoutes(data);
        return data;
    } catch (e) {
        console.warn('Cache GTFS no disponible:', e);
        return null;
    }
}

// Auto-detectar ciudad y cargar
async function autoLoadGTFS(displayName) {
    const ciudad = detectarCiudad(displayName);
    if (!ciudad) return;
    const cacheData = await cargarDesdeServidor(ciudad);
    if (cacheData) {
        console.log(`GTFS pre-cargado: ${cacheData._meta.stops_count} paradas`);
        renderizarPanelGTFS(cacheData);
    }
}
```

### Tamaños típicos

| Ciudad | Paradas | Rutas | Tamaño JSON |
|--------|---------|-------|-------------|
| Bilbao | 533 | 58 | 153 KB |
| Málaga | 1126 | 45 | 315 KB |
| Sevilla | 1038 | 41 | 212 KB |
| Valencia | 1155 | 68 | 336 KB |
| Zaragoza | 996 | 33 | 287 KB |

### Pitfall: no confundir con cache del navegador

Este patrón es un cache **en el servidor** (archivos JSON en `data/gtfs-cache/`), NO el cache del navegador (`localStorage`). El cache del servidor:
- Se actualiza con un script Python (no con upload del usuario)
- Se sirve vía HTTP con cache headers
- Es el mismo para todos los usuarios
- No depende de que el usuario suba un ZIP

El cache del navegador (`localStorage`) sigue siendo útil como fallback offline.

## Pitfall: Catálogo embebido duplicado rompe fallback file://

Cuando un HTML embebe datos inline para funcionar con `file://` (sin servidor), una línea duplicada en la asignación crea un array anidado que rompe el fallback:

**BUG (línea duplicada):**
```javascript
window.GBFS_SYSTEMS_DATA = [
    window.GBFS_SYSTEMS_DATA = [  // ← ESTA LÍNEA ROMPE TODO
  { "name": "Sistema1", ... },
  { "name": "Sistema2", ... }
]
```

**Resultado:** `window.GBFS_SYSTEMS_DATA` es `[[sistema1, sistema2...]]` (anidado), no `[sistema1, sistema2...]`.

**Síntoma:** "No se encontraron sistemas" al abrir con doble clic, pero funciona al servir con `python3 -m http.server`.

**Causa:** La expresión `window.GBFS_SYSTEMS_DATA = [...]` retorna el array, que se envuelve en otro array por el corchete exterior.

**FIX:** Eliminar la línea duplicada. Verificar que solo hay UNA asignación.

**Verificación:** En consola del navegador: `Array.isArray(window.GBFS_SYSTEMS_DATA[0])` debe ser `false` (no `true`).

## Pitfall CRÍTICO: Embebido de JSZip inline

**NUNCA** embebas JSZip como `var jszip = 'contenido';` dentro de un `<script>` tag. El contenido de JSZip contiene comillas y caracteres que rompen el string y el HTML.

**MÉTODO CORRECTO:** Insertar JSZip como un `<script>` inline independiente ANTES del script principal:

```html
<script>/* JSZip v3.10.1 minified content here */</script>
<script>
// Tu código del visor que usa JSZip
</script>
```

**MÉTODO INCORRECTO (roto):**
```html
<script>var jszip = '...contenido JSZip...';</script>
```

**Verificación post-embebido:**
1. `document.querySelectorAll('script').length` debe ser 3 (Leaflet CDN + JSZip inline + visor)
2. `typeof JSZip !== 'undefined'` debe ser `true`
3. `typeof window.initMap !== 'undefined'` debe ser `true`
4. Si `initMap` es `undefined`, el script del visor NO se ejecutó — revisa cierres `</script>`

**Patrón de fallo conocido:** Si al hacer un `replace` en el HTML se pierden los cierres `</script>`, `</body>`, `</html>`, el navegador no renderiza el mapa. Siempre verificar que el HTML tiene los 3 cierres.

## Pitfall: Script inline no se ejecuta

Si un `<script>` inline tiene funciones `async`/`await`, `eval()` y `new Function()` fallan con "Unexpected identifier". Esto NO significa que el script tenga error de sintaxis — el navegador ejecuta scripts inline con async/await correctamente. Para depurar, verificar `typeof window.initMap` en la consola del navegador (no usar `eval`).

## Referencias

- `references/nap-api-v2.md` — API oficial del Punto de Acceso Nacional de transporte (España)
- `references/nap-volumen-real.md` — Volumen real de datos NAP: 161 datasets, 662 MB, 2M viajes
- `references/timeineco-gtfs-integration.md` — Implementación completa en TimeIneco v0.7
- `references/tmb-barcelona-gtfs-sources.md` — Fuentes GTFS TMB Barcelona y URLs probadas
- `references/visor-leaflet-pattern.md` — Patrón de visor con mapa Leaflet interactivo
- `references/gtfsspain-v2-implementation.md` — Implementación GTFSSpain v2: clickable lines, route detail panel, route explorer, timetable
- `references/gtfsspain-v2-layers.md` — Sistema de capas v2.2: GBFS, Parkings, ZBE vía Overpass API
- `references/gtfs-python-cli-architecture.md` — **NUEVO:** Arquitectura Python CLI (GTFStoCSV), parseo con stdlib, exportación CSV/GeoJSON/SHP/HTML, generación de visor Kaizen
- `references/visor-stop-timetable-pattern.md` — **NUEVO 2026-07-03:** Patrones de visor v2.0: routesByStop (índice inverso parada→rutas), stop timetable panel (gtfs-to-html style), catálogo de operadores NAP embebido, export CSV de horarios, getOrderedStops

## Patrón: Capas de datos externos en mapa Leaflet (v2.2)

**NUEVO 2026-07-02:** Añadir capas adicionales al mapa (GBFS bicicletas, parkings, ZBE) con toggles en el sidebar. Cada capa se carga dinámicamente según el viewport del mapa.

### Arquitectura de capas

```
┌──────────────┬──────────────────────────────────────┐
│ Sidebar      │  Mapa Leaflet                        │
│ [Buscar]     │                                      │
│ [Líneas]     │  ┌─ Capas activas ──────────────┐   │
│ [Datos]      │  │ 🚲 GBFS (API)                 │   │
│ [Capas]  ◄──│  │ 🅿️ Parkings públicos (OSM)    │   │
│              │  │ 🏢 Parkings privados (OSM)     │   │
│              │  │ 🚫 ZBE / Regulado (OSM)        │   │
│              │  └────────────────────────────────┘   │
│              │  🔵 Rutas GTFS (por defecto)          │
└──────────────┴──────────────────────────────────────┘
```

### Toggle de capas (CSS + HTML)

```css
.layer-toggle{display:flex;align-items:center;gap:10px;padding:10px 12px;
  background:var(--kz-gris-50);border:1px solid var(--kz-gris-200);
  border-radius:8px;cursor:pointer;transition:all .2s}
.layer-toggle.active{background:var(--kz-azul-50);border-color:var(--kz-azul-400)}
.layer-switch{width:36px;height:20px;background:var(--kz-gris-300);
  border-radius:10px;position:relative;transition:background .2s}
.layer-toggle.active .layer-switch{background:var(--kz-azul)}
.layer-switch::after{content:'';position:absolute;width:16px;height:16px;
  background:white;border-radius:50%;top:2px;left:2px;
  transition:transform .2s;box-shadow:0 1px 2px rgba(0,0,0,.2)}
.layer-toggle.active .layer-switch::after{transform:translateX(16px)}
```

```html
<div class="layer-toggle" id="layer-gbfs" onclick="toggleLayer('gbfs')">
  <div class="layer-icon">🚲</div>
  <div class="layer-info">
    <div class="layer-name">Bicicletas GBFS</div>
    <div class="layer-desc">Estaciones de bicicletas públicas</div>
    <div class="layer-count" id="gbfs-count"></div>
  </div>
  <div class="layer-switch"></div>
</div>
```

### Estado de capas (JS)

```javascript
const layerState = {
  'gbfs':            { active: false, layer: null, data: null, loading: false },
  'parking-public':  { active: false, layer: null, data: null, loading: false },
  'parking-private': { active: false, layer: null, data: null, loading: false },
  'zbe':             { active: false, layer: null, data: null, loading: false }
};

async function toggleLayer(layerId) {
  const state = layerState[layerId];
  state.active = !state.active;
  const el = document.getElementById('layer-' + layerId);
  if (state.active) {
    el.classList.add('active');
    if (!state.data && !state.loading) await loadLayerData(layerId);
    if (state.layer) state.layer.addTo(map);
  } else {
    el.classList.remove('active');
    if (state.layer) map.removeLayer(state.layer);
  }
}
```

### GBFS — Estaciones de bicicletas

Carga el catálogo desde el repo GBFSSpain y fetcha estaciones de cada sistema vía API GBFS:

```javascript
const GBFS_CATALOG_URL = 'https://raw.githubusercontent.com/Ntizar/GBFSSpain/main/data/systems.json';

async function loadGBFSLayer() {
  const catalog = await (await fetch(GBFS_CATALOG_URL)).json();
  // Filtrar sistemas dentro de España
  const nearbySystems = catalog.filter(s => s.lat >= 35.5 && s.lat <= 44.0 && s.lon >= -10 && s.lon <= 5);
  
  const allStations = [];
  for (const sys of nearbySystems) {
    if (!sys.discovery_url) continue;
    const gbfs = await (await fetch(sys.discovery_url)).json();
    const feeds = (gbfs.data && gbfs.data.feeds) || gbfs.feeds || [];
    const infoFeed = feeds.find(f => (f.name || f.file || '').includes('station_information'));
    if (!infoFeed) continue;
    const info = await (await fetch(infoFeed.url)).json();
    const stations = (info.data && info.data.stations) || [];
    allStations.push(...stations.map(st => ({ ...st, system: sys.name })));
  }
  // Crear marcadores Leaflet
  layerState.gbfs.layer = L.layerGroup(allStations.map(st => 
    L.marker([st.lat, st.lon]).bindPopup('🚲 ' + st.name + '<br>' + st.system)
  ));
}
```

### Overpass API — Parkings y ZBE

Usar Overpass API de OpenStreetMap para datos de parkings y zonas de bajas emisiones:

```javascript
async function loadOSMLayer(layerId, type) {
  const bbox = map.getBounds().toBBoxString(); // "south,west,north,east"
  
  let query = '[out:json][timeout:25];(';
  if (type === 'parking') {
    const access = layerId === 'parking-public' ? '!"private"' : '"private"';
    query += `node["amenity"="parking"]["access"${access}](${bbox});`;
    query += `way["amenity"="parking"]["access"${access}](${bbox});`;
  } else if (type === 'zbe') {
    query += `way["boundary"="low_emission_zone"](${bbox});`;
    query += `relation["boundary"="low_emission_zone"](${bbox});`;
  }
  query += ');out center body;';
  
  const resp = await fetch('https://overpass-api.de/api/interpreter', {
    method: 'POST', body: 'data=' + encodeURIComponent(query)
  });
  const data = await resp.json();
  // Crear marcadores desde data.elements
}
```

### Auto-refresh al mover mapa

```javascript
let layerRefreshTimer = null;
map.on('moveend', () => {
  if (layerRefreshTimer) clearTimeout(layerRefreshTimer);
  layerRefreshTimer = setTimeout(() => {
    Object.keys(layerState).forEach(id => {
      if (layerState[id].active && layerState[id].data) loadLayerData(id);
    });
  }, 1000); // Debounce 1s
});
```

**Pitfall:** Overpass API tiene rate limits (~2 req/s). Si se mueve el mapa rápidamente, el debounce de 1s evita saturar la API. Para capas GBFS (datos estáticos), no es necesario refrescar al mover — solo la primera carga.

## Patrón: Python GTFS Parser & Exporter (CLI tool)

**NUEVO 2026-07-03:** Alternativa al parseo en navegador. Herramienta CLI en Python puro (stdlib: `zipfile`, `csv`, `json`) que procesa GTFS sin depender del navegador.

### Cuándo usar cada enfoque

| Escenario | Enfoque |
|-----------|---------|
| Visor web interactivo, drag & drop | **Browser-side** (JSZip + parser JS) |
| Generar CSVs/GeoJSON/SHP para GIS | **Python CLI** |
| Pipeline ETL nocturno (cron) | **Python CLI** |
| Usuario quiere abrir HTML sin servidor | **Browser-side** (HTML autocontenido) |
| Necesitas exportar a formatos GIS (SHP) | **Python CLI** (pyshp) |

### Clase `GTFSParser` — Uso básico

```python
from gtfstocsv.parser import GTFSParser
parser = GTFSParser("ruta/gtfs.zip")
parser.parse()
# Datos como atributos: parser.routes, parser.stops, parser.trips...
# Índices: parser.stops_by_id, parser.routes_by_id, parser.shapes_coords...
# Métodos: parser.summary_text(), parser.get_route_shape(id)
```

### Exportación

```python
from gtfstocsv.exporter import export_csv, export_all_geojson, export_shp_zip
export_csv(parser.routes, "routes.csv")
export_all_geojson(parser, "output/")
export_shp_zip(parser, "todas_las_rutas.shp.zip")  # requiere pyshp
```

### Generación de visor HTML

```python
from gtfstocsv.templater import generar_visor
generar_visor(parser, output_dir="output/")
# → output/visor.html + output/data.json
```

El visor incluye: mapa IGN (Leaflet), rutas clickeables con panel detalle, tablas GTFS exportables a CSV, GeoJSON por ruta, búsqueda en tiempo real. Se abre con doble clic.

### Pitfall: f-string escaping con template literals JS

⚠️ **CRÍTICO cuando generas HTML desde Python:** Las template literals de JavaScript usan `${...}`. Dentro de un f-string de Python, `{...}` se interpreta como expresión.

**MAL:** `f"showToast(\`📦 Cargando ${file.name}...\`);"`
**BIEN:** `f"showToast(\`📦 Cargando ${{file.name}}...\`);"`

**Verificación:** Buscar `\$\{[a-z]` en el f-string. Si encuentra match sin doble llave, está sin escapar.

### Proyecto de referencia

**GTFStoCSV** en `/root/workspace/GTFStoCSV/` — herramienta completa con:
- CLI: `python run.py data/gtfs.zip`
- Módulos separados: parser, exporter, templater
- Documentación de uso (README.md) y mantenimiento (MAINTENANCE.md)
- Diseño Kaizen Design System v4.0 en visor

### Verificación rápida

```bash
python run.py data/gtfs.zip -o output/
# Archivos: visor.html, data.json, todas_las_rutas.geojson
# CSV en output/csv/ (agency, routes, trips, stops, stop_times...)
# SHP en output/todas_las_rutas.shp.zip (si pyshp instalado)
```

## Patrones relacionados

- **`routing-isochrones` > GBFS** — Catálogo de 68 sistemas de bicicletas compartidas en España con feeds GBFS públicos. Repo: `github.com/Ntizar/GBFSSpain`.
- **`nap-data-pipeline`** — Pipeline de descarga y actualización de datos NAP/GTFS desde la API de transportes.gob.es.
- **`frontend-dashboard-patterns`** — Patrones para dashboards HTML (nota: pitfall de f-string escaping).