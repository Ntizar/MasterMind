---
name: deep-learning-patterns
description: Ecosistema completo de patrones de deep learning — inference optimization, model architectures, training techniques, generation methods
version: "1.0.0"
author: mastermind
---

# Deep Learning — Patrones y Técnicas

## Categorías

### Inference-Time Optimization
- **Test-Time Scaling (TTC/TTS)** — Dynamic compute allocation during inference
  - Subcategories: CoT, Self-Consistency, Best-of-N, Beam Search, MCTS, Self-Correction
  - Verifiers: ORM (outcome) vs PRM (process)
  - Key insight: Performance = f(Parámetros × Datos × Cómputo de Inferencia)
  - See: references/test-time-scaling.md

- **Speculative Decoding** — Fast autoregressive generation with draft models
- **Quantization** — FP32 → FP16 → INT8 → INT4 compression
- **KV Cache Optimization** — PagedAttention, continuous batching

### Model Architectures
- **Transformers** — Standard, Sparse, Longformer, BigBird
- **Vision Transformers (ViT)** — Patches, hybrid, Swin
- **Diffusion Models** — U-Net, DiT, Rectified Flow, Consistency Models
- **State Space Models** — Mamba, S4, Mamba-2
- **Mixture of Experts (MoE)** — Switch, GShard, Mixtral
- **Graph Neural Networks** — GNN, GAT, GraphSAGE
- **World Models** — Generative simulation, Sora, Gen-2
- **Neural Operators** — FNO, DeepONet, TFNO, X-FNO, iFNO, MFNO. Learn mappings between infinite-dimensional function spaces. Resolution-independent, PDE solvers at inference speed.

### Training Techniques
- **Fine-Tuning** — Full, LoRA, QLoRA, DoRA, AdaLoRA
- **RLHF / RLAIF** — PPO, DPO, GRPO, Constitutional AI
- **Self-Supervised** — Contrastive, Masked, Self-Distillation
- **Knowledge Distillation** — LLM → small model, cross-modal

### Multimodal
- **CLIP** — Image-text alignment
- **Vision-Language Models** — LLaVA, BLIP, Flamingo

## Writing Deep Learning Notes (cron job workflow)

When writing deep learning notes for the cron learning job:

1. **Choose topic** — pick from uncovered topics, check `/hermes-home/notes/deep-learning/`
2. **Research** — search arxiv, papers, tutorials for recent developments
3. **Write note** — save to `/hermes-home/notes/deep-learning/YYYY-MM-DD-titulo.md`
4. **Size target** — 15-30KB with code, diagrams ASCII, references

### 🔥 Pitfall: Large write_file via execute_code can stall

When writing notes >15KB, **DO NOT use `execute_code` with a `write_file` call inside** — the `code` parameter gets very large and the tool can stall mid-execution with no feedback.

**Correct approach:**
1. Use `write_file` directly (not via `execute_code`) for the note
2. If you need to prepare content first, use `execute_code` only for small prep steps
3. For very large content (>10KB), consider `patch` in chunks or split into multiple files

**Why:** `write_file` is a dedicated tool with its own transport. `execute_code` → `write_file` adds an extra serialization layer that breaks with large payloads.

### Topic selection priority

1. **Practical implementations** over abstract theory
2. **Topics relevant to current stack** (NaN.builders, ESIOS, portfolio)
3. **Complementary to existing coverage** (check what's NOT in `notes/deep-learning/`)
4. **Include working code** — PyTorch/TensorFlow snippets, not pseudocode
5. **References** — papers, repos, tutorials with links

## Usage

When working on a deep learning task:
1. Identify the category (inference, architecture, training, multimodal)
2. Load specific sub-skills with `skill_view(name='dl-<specific>')`
3. Consult `references/` for detailed notes from past sessions
4. Check `references/test-time-scaling.md` for TTC/TTS comprehensive guide
