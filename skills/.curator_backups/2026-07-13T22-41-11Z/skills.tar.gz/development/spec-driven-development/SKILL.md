---
name: spec-driven-development
version: "1.0.0"
description: "Spec-Driven Development — metodología para construir software basado en specs (PRD, planes, constituciones) en vez de 'vibe coding'. Basado en el toolkit de GitHub spec-kit (113K⭐)."
tags: [development, methodology, spec, prd, planning, github, copilot]
---

# Spec-Driven Development (SDD)

## Resumen

SDD invierte el orden tradicional de desarrollo: **spec primero → código después**. En vez de comenzar codificando, empiezas con un documento de especificación que define:

- **Qué** construir (product scenario)
- **Por qué** (business value / user need)
- **Cómo medir** (success criteria)
- **Restricciones** (non-goals, constraints)

## Toolkit: `specify-cli`

El paquete `github/spec-kit` provee:

```bash
# Inicializar un proyecto SDD
specify init

# Crear una spec
specify new spec

# Crear un plan de trabajo
specify new plan

# Crear tareas desde la spec
specify new tasks

# Ver estado
specify status
```

## Estructura de un proyecto SDD

```
project/
├── CONTRACT.md          # Acuerdo entre stakeholders
├── PLANNING.md          # Plan de trabajo
├── tasks/               # Tareas desglosadas
│   ├── spec-001.md
│   └── spec-002.md
├── specs/               # Especificaciones
│   ├── SPEC-001.md     # Feature spec
│   └── SPEC-002.md     # API spec
├── constitution.md      # Reglas del equipo
├── .specify/
│   └── cache/
└── README.md
```

## Ventajas

| Aspecto | Vibe Coding | SDD |
|---------|-------------|-----|
| **Predictibilidad** | Baja | Alta |
| **Revisión** | Post-hoc | Pre-commit |
| **Calidad** | Variable | Consistente |
| **Documentación** | Escasa | Obligatoria |
| **IA-ready** | No | Sí (prompts estructurados) |
| **Despliegue** | Caótico | Orquestado |

## Integración con IA

Spec Kit soporta:

- **GitHub Copilot** — specs como contexto
- **Claude Code** — plans como prompt
- **Cursor, Codex, Windsurf** — SDD como workflow
- **Any LLM**: Las specs son prompts perfectos

## Flujo típico con Mastermind

1. **Spec primero** → `specify new spec`
2. **Plan** → `specify new plan`
3. **Tasks** → `specify new tasks`
4. **Implementar** → usar skills de Mastermind
5. **Review** → `specify status` (checklist)

## Machine-Readable Specs (YAML-Driven)

Una extensión de SDD donde la spec NO es solo un documento humano, sino también **machine-readable**: definiciones en YAML/JSON que las herramientas (generadores, validadores, parsers) consumen directamente.

### Cuándo usarlo

- Ecosistemas multi-herramienta (convertidor + validador + parser comparten reglas)
- Perfiles sobre estándares (NeTEx, GTFS, OpenAPI)
- Proyectos donde 3+ herramientas necesitan la misma información de estructura

### Arquitectura

```
spec/
├── spec-humano.md          ← Documento humano (opcional)
├── enums.yaml              ← Enumeraciones (fuente de verdad)
├── elements.yaml           ← Estructura de elementos/árboles
├── frames.yaml             ← Definiciones de contenedores
└── id-patterns.yaml        ← Patrones de IDs

packages/
└── mi-proyecto-spec/       ← Paquete Python compartido
    ├── pyproject.toml
    └── src/mi_proyecto_spec/
        ├── __init__.py      ← Re-exporta todo
        ├── models.py        ← Modelo de datos compartido
        ├── enums.py         ← Lee enums.yaml, expone clases tipadas
        ├── elements.py      ← Lee elements.yaml, define árboles
        ├── frames.py        ← Lee frames.yaml, define contenedores
        └── validators.py    ← Validación compartida

tools/
├── tool-a/                 ← Consume mi-proyecto-spec
├── tool-b/                 ← Consume mi-proyecto-spec
└── tool-c/                 ← Consume mi-proyecto-spec
```

### Flujo de cambios

```
1. Cambiar YAML en spec/  ← ÚNICA fuente de verdad
2. Los tools actualizan automáticamente (referencian el paquete)
3. El paquete Python se regenera (pip install -e .)
4. Validación: herramientas siguen el spec, no al revés
```

### Beneficios

| Aspecto | SDD tradicional | SDD + Machine-Readable |
|---------|----------------|----------------------|
| **Fuente de verdad** | Documento humano | Documento + YAML |
| **Herramientas** | Implementan la spec manualmente | Consumen la spec automáticamente |
| **Cambios** | Actualizar N herramientas | Actualizar 1 YAML |
| **Desincronización** | Alta (cada tool copia la spec) | Cero (todos leen del mismo YAML) |
| **Onboarding nuevos perfiles** | Reescribir herramientas | Añadir YAMLs |

### Pitfalls específicos

- **Subagent truncation:** Si delegas la refactorización de un archivo grande (>1000 líneas) a un subagente, puede truncarse si el timeout alcanza mientras escribe. Prefiere hacer ediciones tú mismo con patch (cambio por cambio) o dividir el archivo grande en módulos más pequeños primero.
- **YAML runtime:** El paquete Python debe leer los YAMLs en tiempo de ejecución, no embeberlos. Si embeber, los tools se desincronizan al cambiar el YAML.
- **No sobre-modelar:** No todo necesita estar en YAML. La lógica de negocio compleja sigue siendo código. El YAML define estructura, enumeraciones, y reglas declarativas.
- **Instalación:** Asegurar que el paquete compartido está instalado editable (`pip install -e .`) en el mismo entorno que los tools.

## Pre-moda: Leer TODAS las entradas antes de modificar

**Regla crítica para sistemas modulares de specs (2+ archivos interconectados):**

Antes de modificar CUALQUIER archivo en un proyecto de specs modulares, debes:

1. **Listar todos los archivos relacionados** — `search_files` + `ls` para encontrar TODO el archivo del proyecto
2. **Leer TODOS los archivos de entrada** — cada sección que referencia o consume datos
3. **Mapear dependencias** — qué sección produce qué dato y qué sección lo consume
4. **Validar coherencia** — verificar que las salidas de las secciones leídas coinciden con lo que espera la sección a modificar
5. **Solo después de leer todo** → proceder a modificar

**Señal de alerta:** Si un proyecto tiene `01-`, `02-`, `03-`... o archivos con `flujo-datos.md`/`README.md` con diagrama de flujo, ESTO ES UN SISTEMA MODULAR — aplica la regla.

**Pitfall clásico:** Modificar la sección 08 sin leer las 01-07 produce inconsistencias: campos que no existen, formatos que no coinciden, datos duplicados.

**Excepción:** No aplica para archivos únicos o scripts simples sin dependencias cruzadas.

## Pitfalls

- No sobre-documentar — las specs deben ser **ejecutables**, no ensayos
- SDD funciona mejor con **proyectos > 1 semana** (para proyectos de 1 día, plan en README)
- La `constitution.md` del repo define reglas de IA (no override)
- **Machine-Readable SDD requiere inversión inicial** — crear el YAML + paquete compartido lleva 1-2 días. Merece la pena si hay 3+ herramientas que comparten la misma spec.

## Referencia

- Repo: `github/spec-kit`
- CLI: `specify` (Python, pip install)
- Docs: https://github.github.io/spec-kit/
- **Machine-Readable SDD:** Caso real netex-es: monorepo + YAML specs + paquete compartido `netex_es_spec` (3 tools, 4 repos fusionados). Ver `references/netex-es-monorepo-case-study.md`