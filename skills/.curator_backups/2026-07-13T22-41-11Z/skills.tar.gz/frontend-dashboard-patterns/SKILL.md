---
name: frontend-dashboard-patterns
description: "Patrones completos para dashboards frontend vanilla JS: cliente API robusto, orquestación de carga, error boundaries, tabs con navegación, persistencia, fechas, colores, sparklines, Web Workers y debugging. Todo lo que necesitas para construir dashboards resilientes sin bundler."
version: "1.9.0"
author: Hermes Agent
tags: [frontend, dashboard, patterns, vanilla-js, resilience, geodatos, leaflet, choropleth]
related_skills: []
---

# Frontend Dashboard Patterns — Colección Completa

Patrones reutilizables para dashboards frontend vanilla JS sin bundler. Inspirados en ESIOS Dashboard y Ntizar Aurora.

## Tabla de Contenidos

1. [Cliente API Robusto](#1-cliente-api-robusto) — reintentos, circuit breaker, timeouts
2. [Orquestación de Carga](#2-orquestación-de-carga) — Promise.allSettled, anti-doble-carga, cache fallback
3. [Error Boundaries](#3-error-boundaries) — overlay global, errores por sección, retry, fallback en cascada para APIs externas
4. [Tabs con Navegación](#4-tabs-con-navegación) — hash routing, lazy render, lazy data
5. [Persistencia de Estado](#5-persistencia-de-estado) — localStorage, debounce, versionado
6. [Fechas y Formateo](#6-fechas-y-formateo) — locale ES, rangos, countdowns
7. [Colores y Paletas](#7-colores-y-paletas) — gradients, status colors, CSS vars
8. [Sparklines y Mini Charts](#8-sparklines-y-mini-charts) — SVG inline, Canvas, micro-charts
9. [Web Workers](#9-web-workers) — offload CPU, Comlink, chunked processing
10. [Leaflet Map Patterns](#10-leaflet-map-patterns) — GeoJSON, choropleth, markers, popups, tile layers
11. [Leaflet Layers + Pages Deploy + Shapes](references/leaflet-layers-and-deploy.md) — capas activables, Overpass, GBFS, polígonos OSM, GitHub Pages, shapes completos
12. [Debugging Patterns](#12-debugging-patterns) — console, breakpoints, performance, memory
15. [Three.js Engine Pitfalls](references/threejs-engine-pitfalls.md) — Quaternion chain, MeshStandardMaterial, Object.assign read-only, RAF debugging, embedded single-file deploy
13. [Taxonomy Hierarchical Filters](references/taxonomy-hierarchical-filters.md) — taxonomía estática + checkboxes jerárquicos + matching padre→descendiente
14. [Docs HTML Responsive](references/docs-html-responsive-pattern.md) — patrón de página de documentación responsive con tabs para explicar proyectos técnicos completos
17. [Scroll Cinematic Landing](references/scroll-cinematic-landing.md) — landings inmersivas con scroll-to-panel, zoom cinemático, full-screen images, y transiciones suaves (estilo scroll-world)
18. [Scripts Indentados — Falso IIFE](references/pitfalls-html-dashboards.md#scripts-indentados-con-4-espacios) — archivos indentados con 4 espacios que parecen IIFE pero no lo son. Causa común de `ReferenceError` en refactor modular.
19. [Caché Navegador vs CDN](references/pitfalls-html-dashboards.md#cache-del-navegador-vs-cdn) — diagnóstico cruzado cuando `curl` muestra contenido correcto pero el browser no lo refleja.
20. [`defer` Scope Pitfall](references/defer-scope-pitfall.md) — `<script defer>` crea scope léxico separado por script; variables `const`/`let` no accesibles entre módulos. Incluye verificación de falso IIFE por indentación.
21. [TDZ + Window Sync](references/tdz-window-sync-pitfall.md) — Temporal Dead Zone (`window.X = X` antes de `const X`), `let` vs `window.map` desincronizado, script-level cache busting.