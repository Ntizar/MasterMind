---
name: aurora-design-system
description: Design System Ntizar Aurora v5.2 — CSS puro, 11 packs opt-in, namespaced .nz, dos modos (Núcleo default con colores sólidos azul+naranja, Glass opcional con liquid glass). CDN público en jsDelivr. Derivado de Ntizar-Aurora.
version: "5.2.0"
tags: [css, design-system, aurora, nucleo, liquid-glass, ntizar]
---

# Aurora Design System — Patrón Ntizar CSS v5.2

## Descripción

Design System CSS puro sin dependencias, sin build step, namespaced bajo `.nz`. 1 archivo core + 10 packs opt-in. CDN público en jsDelivr.

**Dos modos de diseño:**

- **Núcleo (DEFAULT)** — colores sólidos puros azul `#2563eb` + naranja `#f97316`, blanco y negro `#0a0a0a`. CERO gradientes azul→naranja. Bento grid asimétrico, stats bar, CSS-only charts, Three.js opcional para hero visual. Es el estilo por defecto para todo artefacto generado.
- **Glass (OPCIONAL)** — liquid glass real con 4 capas. Solo cuando el usuario pida explícitamente "glass" o "liquid glass".

**Aurora es el sistema por defecto para:** dashboards, visores de mapas, landings creativas, herramientas de transporte, apps personales. **NO usar Aurora para:** presentaciones corporativas/consulting (usar fondo blanco estilo McKinsey) ni design systems de equipo corporativo (usar `design-system-scaffold` con colores oficiales de marca).

## Estilo Núcleo (DEFAULT)

El estilo Núcleo es lo que David pidió definitivamente (2026-07-02): "colores sólidos puros, evitar gradientes, naranjas y azules puros".

### Paleta

| Color | Hex | Uso |
|---|---|---|
| Azul | `#2563eb` | Color principal, bloques sólidos, botones brand |
| Azul profundo | `#1e40af` | Hover/active del azul |
| Azul claro | `#60a5fa` | Barras de chart, acentos sutiles |
| Naranja | `#f97316` | Color secundario, bloques sólidos, CTA |
| Naranja profundo | `#ea580c` | Hover/active del naranja |
| Naranja claro | `#fdba74` | Barras de chart, acentos sutiles |
| Blanco | `#ffffff` | Fondo limpio, texto sobre color |
| Negro | `#0a0a0a` | Texto principal, bloques dark |

### Reglas visuales del Núcleo

1. **CERO gradientes azul→naranja.** La interpolación sRGB entre `#2563eb` y `#f97316` produce gris morado (`rgb(143,107,128)`) en el punto medio. Usar bloques de color sólido con separación clara. Si se necesita un gradiente, que sea monocromo (azul→azul-claro).
2. **Bento grid asimétrico** — bloques de color sólido (azul, naranja, blanco, negro) con tamaños irregulares. No grid de cards iguales. Usar `nz-bento-grid` con `__cell--span-*`.
3. **Stats bar** — bloques alternando azul/naranja, fondo sólido, texto blanco. 4 stats en desktop (2x2 en móvil).
4. **CSS-only charts** — barras con `div` + `height:%`, ring con `conic-gradient`, progress bars de 4-6px. Sin librerías de chart para visualizaciones simples.
5. **Three.js opcional para hero visual** — importmap + módulo ES. Partículas azul/naranja, geometría wireframe (icosaedro), anillos orbitales. Fondo negro `#0a0a0a` dentro del canvas. Solo cuando el proyecto sea creativo/landing.
6. **Nav sólida** — `background: rgba(255,255,255,0.85)` + `backdrop-filter: blur(12px)` sutil. NO glass-liquid. Border-bottom `1px solid #f3f4f6`.
7. **Mobile-first OBLIGATORIO** — base 1 columna (≤600px), tablet 2 columnas (601–900px), desktop 3+ columnas (901px+). Usar `@media (min-width)` progresivo, NO `max-width`.
8. **Touch targets mínimo 44px** en móvil para botones, links, inputs, tabs.

### Ejemplo de referencia

Ver `/root/workspace/nucleo-panel.html` — demo completo del estilo Núcleo con bento, stats, CSS charts y Three.js.

## Estilo Glass (OPCIONAL)

**Solo cuando el usuario pida explícitamente "glass" o "liquid glass".** Por defecto, usar Núcleo.

### Reglas del Glass

- **glass-liquid con 4 capas:** (1) base translúcida `rgba(255,255,255,0.72→0.62)`, (2) `backdrop-filter: blur(24px) saturate(180%)`, (3) dual inset shadow (luz arriba + profundidad abajo), (4) borde cromático `::before` (specular) + `::after` (chromatic edge).
- **SIN violeta en chromatic edge** — los hue OKLCH deben ser 250 (azul) y 50 (naranja), NO 280/340 (violeta/rosa). Fix aplicado en `ntizar.next.css`.
- **Fondo blanco limpio** `#ffffff` — sin mesh intrusivo, sin orbs flotantes decorativos que cubran la pantalla.
- **Números compactos** — KPIs de 1.1–1.25rem, no 2.5rem+.
- **Sin bordes glass decorativos visibles** en la parte superior de cards para outputs a stakeholders externos (David los asocia con "estética IA").

### Cuándo Glass vs Núcleo

| Señal del usuario | Modo |
|---|---|
| "colores sólidos", "sin gradientes", "azul y naranja puros" | **Núcleo** |
| "glass", "liquid glass", "cristal" | **Glass** |
| Sin señal explícita | **Núcleo** (default) |
| Presentación corporativa / consulting | Ninguno (usar estilo blanco limpio) |

## Packs CDN

CDN base: `https://cdn.jsdelivr.net/gh/Ntizar/Ntizar-Aurora@master/`

| Pack | Qué proporciona | Cuándo cargar |
|---|---|---|
| `ntizar.css` | Core: tokens, base, botones, cards, badges, fields, layout | **Siempre** (obligatorio) |
| `ntizar.themes.css` | 5 skins (aurora, sunset, midnight, ocean, citrus) + fix violeta | Si se quiere cambiar paleta |
| `ntizar.next.css` | glass-liquid, OKLCH, multi-axis theming, mesh | Solo modo Glass |
| `ntizar.nucleo.css` | **NUEVO:** colores sólidos, bento, stats bar, three.js stage, CSS-only charts | Modo Núcleo (default) |
| `ntizar.data.css` | KPIs, progress, meter, skeleton, avatar, timeline | Dashboards / datos |
| `ntizar.maps.css` | Leaflet/Mapbox/MapLibre con look Ntizar | Visores de mapas |
| `ntizar.charts.css` | Wrappers para Chart.js/Apex/D3, sparkline, donut CSS-only | Gráficos con librería |
| `ntizar.motion.css` | Reveal, glow-pulse, shimmer, marquee, hover-lift | Animaciones |
| `ntizar.forms.css` | Switch, OTP, range, file drop, stepper | Formularios complejos |
| `ntizar.ui.css` | Modal, drawer, tabs, accordion, dropdown, toast, tooltip | Interactividad |
| `ntizar.patterns.css` | App-shell, hero, pricing, features, FAQ, footer, auth | Páginas completas |

**Cargar solo los packs que se usan.** Si usas `nz-chart` sin cargar `ntizar.charts.css`, los estilos no aplican.

### CDN mínimo (modo Núcleo, landing/simple)

```html
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/Ntizar/Ntizar-Aurora@master/ntizar.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/Ntizar/Ntizar-Aurora@master/ntizar.nucleo.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/Ntizar/Ntizar-Aurora@master/ntizar.ui.css">
```

### CDN dashboard completo (modo Núcleo)

```html
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/Ntizar/Ntizar-Aurora@master/ntizar.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/Ntizar/Ntizar-Aurora@master/ntizar.nucleo.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/Ntizar/Ntizar-Aurora@master/ntizar.data.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/Ntizar/Ntizar-Aurora@master/ntizar.charts.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/Ntizar/Ntizar-Aurora@master/ntizar.ui.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/Ntizar/Ntizar-Aurora@master/ntizar.patterns.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/Ntizar/Ntizar-Aurora@master/ntizar.motion.css">
```

### HTML base

```html
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Mi App</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/Ntizar/Ntizar-Aurora@master/ntizar.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/Ntizar/Ntizar-Aurora@master/ntizar.nucleo.css">
</head>
<body class="nz" data-nz-skin="aurora" data-nz-theme="light">
  <!-- contenido -->
</body>
</html>
```

## Patrones por tipo de proyecto

David hace estos 5 tipos de proyecto. Cada uno tiene un patrón recomendado.

### 1. Visor de mapas (Leaflet)

**Proyectos:** GTFSSpain, GBFSSpain, ISOTime

- Packs: `core + nucleo + maps + data + ui`
- Claves: `nz-map--solid` con `nz-map__pin--accent` (naranja) / `--success` (azul), `nz-map__overlay--top-left` para leyenda, `nz-map__legend`, `nz-line-badge--azul/--naranja` para líneas de transporte
- Pins azul/naranja sólidos, overlays con fondo blanco + sombra sutil (usar `nz-map--solid`, no `--glass`)
- Stats bar arriba con KPIs del mapa (vehículos activos, líneas, etc.)
- Leyenda con bloques de color sólido

### 2. Dashboard de datos (APIs)

**Proyectos:** DataHubEspana

- Packs: `core + nucleo + data + charts + ui + patterns + motion`
- Claves: `nz-bento` asimétrico, `nz-kpi-solid`, `nz-stats-bar`, `nz-bars`, `nz-ring`, `nz-table-solid`
- Bento grid con bloques de color sólido (`nz-bento__cell--azul/--naranja/--dark/--white`)
- Stats bar con 4 KPIs alternando azul/naranja (`nz-stat--azul/--naranja`)
- CSS-only charts (`nz-bars`, `nz-ring` conic-gradient) para métricas simples; Chart.js para series complejas
- Tablas estilizadas con `nz-table-solid`

### 3. Landing creativa

- Packs: `core + nucleo + patterns + motion`
- Claves: `nz-hero` + Three.js canvas (importmap, partículas, icosaedro wireframe), `nz-feature-grid`, `nz-footer`
- Hero split: texto a la izquierda, canvas Three.js a la derecha (fondo negro)
- Features grid con cards de color sólido
- Stats bar opcional
- Footer con atribución

### 4. Herramienta de transporte

**Proyectos:** horarios, líneas, rutas

- Packs: `core + nucleo + maps + data + ui + forms`
- Claves: `nz-map--solid` con rutas, `nz-table-solid` para horarios, `nz-tabs` para líneas, `nz-search` para buscar, `nz-schedule` + `nz-line-badge`
- Mapa con pins azul/naranja por tipo de línea
- Tabla de horarios compacta, mobile-first
- Search bar prominente

### 5. Editorial / fiscal (NTA Spain style)

- Packs: `core + patterns` (sin nucleo, sin glass)
- Fondo cálido `#f2eee5`, tipografía serif (Georgia/Source Serif), sin glass, sin mesh
- Layout editorial: columna estrecha de lectura, márgenes generosos
- Tablas de datos financieros con `nz-table`
- Estilo sobrio, profesional, no "tech/startup"

## Reglas de oro

1. **`body class="nz"` siempre.** Sin `.nz` en el body, nada funciona. Es la regla número 1.
2. **`data-nz-skin="aurora"` + `data-nz-theme="light"` por defecto.** David prefiere fondos claros. Dark solo si se pide explícitamente.
3. **Sin gradientes azul→naranja.** Usar `ntizar.nucleo.css` para colores sólidos. La interpolación sRGB genera morado. Si hace falta un gradiente, monocromo.
4. **Mobile-first obligatorio.** Base 1 col (≤600px), tablet 2 col (601–900px), desktop 3+ col (901px+). Touch targets 44px mínimo.
5. **Footer:** `Hecho con ❤️ por David Antizar` (emoji real U+2764, sin variantes, sin "via Mastermind", sin "Analisis por").

## Brand Identity (kit de marca)

Aurora tiene un kit de marca completo desde v5.2 (commit `4bc05f9`). Todos los recursos viven en el repo `Ntizar/Ntizar-Aurora`.

### Símbolo

**"A" geométrica** (de Antizar) — trazo izquierdo azul `#2563eb`, trazo derecho naranja `#f97316`, barra horizontal negra `#0a0a0a`. ViewBox 100×100, apex en `(50,12)`.

- SVG paths: `LEFT_HALF = M50,12 L14,88 L38,88 L50,42 Z`, `RIGHT_HALF = M50,12 L86,88 L62,88 L50,42 Z`, `CROSSBAR = M34,55 L66,55 L66,62 L34,62 Z`
- 5 variantes de símbolo (color, blanco, negro, azul, naranja) + 5 variantes de logotipo (símbolo + "aurora") en SVG y PNG
- Favicon: SVG + ICO + PNG (32/180/512px)
- Ubicación: `assets/simbolo/`, `assets/logo/`, `assets/favicon/`

### Antetítulo (eyebrow)

Convención de marca: `› SECCIÓN` usando `.nz-eyebrow` (clase en `ntizar.css`, layer `ntizar.components`).

- `::before { content: "\203A\00a0" }` — U+203A + nbsp
- Font mono, uppercase, letter-spacing 0.12em, color brand
- Variantes: `--accent` (naranja), `--muted` (gris)

### Presupuesto de acento (accent budget)

Reglas explícitas en `DESIGN.md`:

- **Máximo 5 momentos saturados de color por página** (scope: página entera, no por sección)
- **NUNCA** acento en: texto de cuerpo, iconos decorativos, separadores finos, fondos grandes de sección
- **Dual rule:** azul y naranja no se mezclan en la misma sección — elegir uno
- **Texto de acento** como token separado que cumple WCAG 4.5:1

### Voz de marca

- `BRAND.md` — posicionamiento ("CSS-only, sin build, sin dependencias, namespaced"), boilerplate copiar-pegar, 5 keywords, "Aurora NO es", tono do/don't
- `brandbook.md` — guía descargable (símbolo, variantes, espacio libre, tamaño mínimo, reglas "NUNCA", paleta con hex+oklch, tipografía, voz)
- `AGENTS.md` — contrato para IAs (5 reglas duras, reglas de acento, anti-patterns, decision tree)

### Página de marca viva

`brand.html` — página completa con Three.js:

- Hero: "A" extruded 3D (azul + naranja + cruz blanca), 600 partículas con glow additive blending, 3 anillos orbitales, mouse parallax, fog
- 7 secciones: Logo, Color, Tipografía, Forma, Componentes, Voz, Descargas
- Dogfooding: usa clases Aurora (`nz-btn`, `nz-badge`, `nz-eyebrow`)
- Dark mode `#0a0a0a`, scroll progress bar, fade-in on scroll, nav con blur
- Importmap three@0.164 desde jsDelivr

### Regla de atribución

Footer obligatorio: `Hecho con ❤️ por David Antizar` (emoji U+2764 real, sin variantes, sin "via Mastermind").

## Verificación pre-entrega

Checklist de 8 items. Verificar antes de dar por terminado cualquier artefacto HTML:

1. [ ] `body class="nz"` presente
2. [ ] `data-nz-skin="aurora"` + `data-nz-theme="light"` en el body
3. [ ] CDN links correctos y solo los packs necesarios cargados
4. [ ] Mobile-first: base 1 col, escalado progresivo con `min-width`. Touch targets 44px
5. [ ] Sin gradientes azul→naranja (colores sólidos del Núcleo)
6. [ ] CSS custom < 30 líneas (usar componentes Aurora de INDEX.md)
7. [ ] Sin hex hardcodes en CSS custom (usar `var(--nz-*)` o tokens del Núcleo)
8. [ ] Footer dice exactamente: `Hecho con ❤️ por David Antizar`

## Pitfalls

1. **Violeta en gradientes:** la interpolación sRGB entre azul `#2563eb` y naranja `#f97316` genera gris morado en el punto medio, aunque no haya parada violeta. Solución: colores sólidos puros, nunca gradientes azul→naranja. (Cubre el fix de `ntizar.themes.css` y el barrido de violeta en `ntizar.next.css` chromatic edge.)
2. **CSS custom > 30 líneas:** síntoma de que se está recreando Aurora en vez de usarlo. Cargar `INDEX.md` del repo y usar solo componentes documentados. Si necesitas un shell visual, máx 100-200 líneas de contexto, pero los componentes van dentro.
3. **Olvidar `.nz` en body:** sin `class="nz"`, ninguna clase Aurora aplica. Es el fallo más común y más silencioso.
4. **Inventar clases:** `nz-btn--glass-liquid-secondary`, `nz-tabs__tab`, `nz-card--glass-liquid-brand` NO existen. Si no está en `INDEX.md`, no existe. Usar un token `var(--nz-*)` en inline style o buscar la clase equivalente documentada.
5. **Cargar packs que no se usan:** cada pack es CSS completo sin tree-shaking. Cargar solo lo necesario. Si usas `nz-chart` sin `ntizar.charts.css`, se ve roto. Si cargas `ntizar.next.css` sin usar glass, añades peso innecesario.

## Workflow para agentes

1. **Cargar `INDEX.md`** del repo Ntizar-Aurora (`/root/workspace/Ntizar-Aurora/INDEX.md`) — es la fuente de verdad de la API de clases.
2. **Decidir modo:** Núcleo (default) o Glass (solo si se pide explícitamente).
3. **Cargar packs CDN** según el tipo de proyecto (ver tabla de patrones).
4. **Generar HTML** usando solo clases de `INDEX.md`. CSS custom máximo 30 líneas.
5. **Verificar checklist** de 8 items antes de entregar.

### Uso con LLMs de poco contexto

**NO pegar el CSS en el prompt** (~170 KB ≈ 50.000 tokens). El CSS vive en el HTML del usuario vía CDN.

**SÍ hacer:**
1. Cargar `LLM.md` del repo (~9 KB) — guía de decisión "necesito X → packs Y → clases Z".
2. Linkar el CSS vía CDN en el HTML generado.
3. Decir al agent: "Generate HTML only. The CSS is already linked. Use Aurora classes from INDEX.md."

### Repo local

El repo Ntizar-Aurora debe estar en `/root/workspace/Ntizar-Aurora/`:
- `INDEX.md` — API completa de clases por pack (fuente de verdad)
- `LLM.md` — Guía de decisión rápida
- `AGENTS.md` — Reglas duras (5 hard rules)
- `gallery.html` — Referencia visual completa
- `examples/` — 5 ejemplos completos (login, dashboard, landing, UI, forms)

### Auditoría automática

Cuando se pida revisar/auditar un HTML contra Aurora, ejecutar SIEMPRE el script antes de auditar a mano:

```bash
python3 /hermes-home/skills/frontend-dashboard-patterns/aurora-design-system/scripts/audit-aurora.py /path/al/index.html
# o desde URL:
curl -s <url> | python3 /hermes-home/skills/frontend-dashboard-patterns/aurora-design-system/scripts/audit-aurora.py -
```

Métricas clave: CSS custom líneas (límite 30), clases custom (ideal ≤5), hex hardcodes (ideal 0), clases Aurora únicas (mínimo 100), packs cargados vs necesarios.

### Referencias incluidas

- `templates/nucleo-base.html` — **Template base del estilo Núcleo**: nav sólida, stats bar, bento grid con CSS charts, activity list. Copiar y modificar para empezar rápido.
- `references/aurora-clean-style.md` — Patrón Glass limpio: fondo blanco, glass 4 capas, mobile-first
- `references/audit-checklist.md` — Checklist de 21 componentes premium + veredictos
- `references/dark-mode-migration-pattern.md` — Migración de dark mode custom → `data-nz-theme`
- `references/mobile-compact-pattern.md` — Compactación progresiva de hero/KPIs en móvil
- `references/contradiction-audit-gradient-aurora.md` — Auditoría del violeta en gradientes
- `references/shell-patterns.md` — 5 patrones de shell CSS (login, dashboard, landing, UI, forms)
- `references/multi-project-audit-unification.md` — Auditar y unificar diseño de múltiples proyectos
- `references/helmcode-brand-comparison.md` — Comparativa Aurora vs Helmcode brand kit. Los 5 gaps identificados (voz, kit descargas, acento, antetítulo, forma) fueron RESUELTOS en commit `4bc05f9`.
- `references/brand-kit-implementation.md` — Técnica de generación del kit de marca: logos SVG geométricos, conversión PNG con cairosvg, página brand.html con Three.js, estructura de archivos.
