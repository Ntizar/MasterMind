# Preferencias de David — Diseño de Dashboards

## Anti-patrones (NUNCA hacer)

### 1. ❌ Gradientes azul→naranja (interpolación morada)
- CSS interpola en sRGB entre `#2563eb` y `#f97316` → el punto medio es `rgb(143,107,128)` (gris morado)
- David lo rechazó enfáticamente: "Es una mierda. Quiero colores sólidos puros"
- **Correcto:** colores sólidos puros en bloques. Usar `ntizar.nucleo.css` (pack Núcleo de Aurora v5.2). CERO gradientes azul→naranja. Si hace falta un gradiente, monocromo (azul→azul-claro).
- Glass/liquid-glass solo si David lo pide explícitamente. Por defecto: Núcleo (colores sólidos).

### 2. ❌ Circle markers para choropleth geográfico
- David: "los cp en vez de puntos deberían ser áreas"
- Para datos geográficos SIEMPRE polígonos reales (GeoJSON/TopoJSON)
- Referencia de oro: EspañaAtlas (espanatlas.es) — 8.132 municipios con choropleth real + Canvas renderer
- Canvas renderer obligatorio para >500 polígonos

### 3. ❌ Dark theme para datos públicos
- David odia fondos oscuros y colores neón
- **Correcto:** fondo blanco/gris claro (#f8fafc o #fafafa), texto oscuro (#1e293b o #1a1a2e), acentos en borders
- **Excepción:** Si David lo pide explícitamente (ej: hero sections, effectos nocturnos)

### 3b. ❌ Clustering en centroid para treemaps/mosáicos
- David: "los agrupa todos en el mismo punto por lo que no queda tan bonito"
- Si agrupas elementos (calles, bloques, items) por su centroide → todo colapsa a un punto
- **Correcto:** Shelf-packing — empaquetar densamente como libros en estantería. Cada celda del treemap debe estar REPLETA de elementos, no tener un puntito en el centro
- Referencia: CallesDinamicas v2 — squarified treemap + shelf-packing por ángulo

### 4. ❌ Cards "de IA"
- Cards con gradientes de color en cada una → genérico
- Iconos grandes sin contexto → confuso
- Números sin explicar qué miden → inútil
- `border-left: 4px solid #color` → "se nota mucho que es IA" (David, 2026-06-30)
- **Correcto:** KPI tiles limpios con fondo blanco, gradientes sutiles de fondo, hover elevación, sin border-left

### 5. ❌ Datos inventados o aproximados
- David verifica manualmente cada dato del mapa
- Nunca inventar coordenadas, valores, ni nombres
- Si la API falla: mostrar "N/D" o "—", nunca fake data

## Patrones correctos

### Choropleth
- Polígonos reales (GeoJSON/TopoJSON), nunca approximations
- Canvas renderer para >500 features (Leaflet: `preferCanvas: true, renderer: L.canvas()`)
- TopoJSON para compresión (~70% menos que GeoJSON)
- Lazy loading de datasets temáticos
- Pane system para z-index controlado

### Layout
- Mapa como estrella: 70%+ del viewport
- Sidebar colapsable con datos/controles
- Click provincia → zoom + panel detalle con datos locales (clima, población, etc.)
- Footer: "Hecho con ❤️ por David Antizar"

### Datos
- APIs públicas reales: ESIOS/REE, Open-Meteo, IGN, DGT, BOE/BORME, embalses
- Fallback graceful: si API falla → "N/D", nunca inventar
- Timestamps de actualización visibles

### Chart.js
- Limpio, sin过多 decoración
- Etiquetas claras
- Colores consistentes con la paleta del dashboard
- Responsive

## Referencia visual: EspañaAtlas
- Fondo dark navío (para contrastar con David's preference de fondo claro)
- Choropleth interactivo con Canvas
- Sidebar colapsable con rankings, correlaciones, índices
- Búsqueda con autocompletado
- URL state para compartir vistas
