## 10. Panel vacío sin contenido
Si un panel tiene `<div class="tab-panel" id="tab-X">` pero no tiene KPIs, canvas ni selects, está vacío y el usuario lo detecta al instante. Verificar que cada panel tiene al menos 500 bytes de contenido HTML.

## 11. Mapa/Panel de otra pestaña visible al cambiar de tab

**Problema:** Al cambiar de pestaña (ej: Terremotos), el mapa o panel de detalle de otra pestaña (ej: Población) sigue visible.

**Causas posibles:**
1. **`#map-container` no se oculta** — Está fuera de `#sidebar` en el layout flex. Cuando cambias de tab, el sidebar se actualiza pero el mapa no.
   - **Fix:** En el event listener de las tabs, añadir lógica para mostrar/ocultar `#map-container` según la tab activa:
   ```javascript
   const mapTabs = ['panel', 'poblacion', 'gbfs', 'puertos', 'calidad-aire', 'aireext', 'polen', 'suelo', 'tempsuelo', 'presion', 'visibilidad', 'nubosidad', 'rocio', 'termica', 'lluvia', 'inundaciones', 'nieve', 'evapo', 'rafagas', 'eolica', 'sol', 'uv', 'radiacion', 'fuego', 'cape', 'mar', 'mareas'];
   if (mapTabs.includes(tab)) {
       if (mapContainer) mapContainer.style.display = 'block';
   } else {
       if (mapContainer) mapContainer.style.display = 'none';
   }
   ```
2. **`#province-detail` abierto** — El panel de detalle de provincia tiene `position: absolute` y `z-index: 800`. Si está abierto (`class="open"`), se superpone a cualquier tab.
   - **Fix:** Al cambiar de tab, cerrar el panel: `document.getElementById('province-detail')?.classList.remove('open')`
3. **`#map-container` no existe en el DOM** — HTML corrupto. Verificar con `document.getElementById('map-container')`.
4. **CSS `display` no aplica** — Si el mapa tiene `position: fixed`/`absolute`, verificar con `getComputedStyle()`.

**Diagnóstico rápido:**
```javascript
JSON.stringify({
    mapContainer: document.getElementById('map-container') ? { display: getComputedStyle(document.getElementById('map-container')).display } : 'NOT FOUND',
    provinceDetail: document.getElementById('province-detail') ? { open: document.getElementById('province-detail').classList.contains('open') } : 'NOT FOUND',
    activeTab: document.querySelector('.tab-btn.active')?.getAttribute('data-tab')
})
```

## 12. GitHub Pages deploy: "Deployment failed, try again later"

**Síntoma:** El workflow de GitHub Pages falla en el paso "Deploy to GitHub Pages" con `##[error]Deployment failed, try again later`. Los pasos anteriores (Checkout, Setup Pages, Upload artifact) son exitosos.

**Causa:** Error transitorio de GitHub Pages, NO problema del código.

**Solución:**
1. Re-dispatch el workflow manualmente (ver script en `scripts/gh-pages-retry.sh`)
2. Esperar 5-10 minutos y reintentar
3. **NO modificar el código** — si el deploy anterior fue exitoso, el código es correcto
4. Descargar logs: `curl -L -H "Authorization: token $GITHUB_TOKEN" "https://api.github.com/repos/Ntizar/DataHubEspana/actions/runs/$RUN_ID/logs" -o deploy-logs.zip && unzip -o deploy-logs.zip -d /tmp/deploy-logs && grep '##\[error\]' /tmp/deploy-logs/0_deploy.txt`

**Verificación:**
```bash
curl -s -H "Authorization: token $GITHUB_TOKEN" \
  "https://api.github.com/repos/Ntizar/DataHubEspana/actions/runs?per_page=5" \
  -H "Accept: application/vnd.github+json" | python3 -c "
import json,sys
data=json.load(sys.stdin)
for run in data.get('workflow_runs',[]):
    print(f\"#{run['run_number']}: {run['status']} {run.get('conclusion','N/A')} {run['created_at'][:19]}\")
"
```