# Pitfalls para Dashboards HTML Vanillas (DataHub España + similares)

## DOM Nesting en HTML Masivo (>2000 líneas)

Cuando se añaden tab-panels nuevos a un `.tab-content`, DEBEN ser hermanos (no hijos) de los paneles existentes.

**Error típico:** Añadir un `<div class="tab-panel" id="tab-nuevo">` sin cerrar el panel anterior → el nuevo panel queda como hijo del anterior → rompe TODO el layout.

**Verificación obligatoria:**
```bash
python3 -c "
import re
content = open('file.html').read()
tc = content.find('class=\"tab-content\"')
mc = content.find('id=\"map-container\">')
seg = content[tc:mc]
o = len(re.findall(r'<div[ >]', seg))
c = len(re.findall(r'</div>', seg))
print(f'Balance: {o-c}')  # Debe ser -1
"
```

**Patrón correcto de cierre:**
```html
                    </div>  <!-- cierra fuentes -->
                </div>      <!-- cierra tab-panel anterior -->
                <div class="tab-panel" id="tab-nuevo">
                    ...
                </div>      <!-- cierra tab-panel nuevo -->
```

## GitHub Pages CDN Caching

Después de `git push`, GitHub Pages sirve versiones cacheadas durante 2-5 minutos. **Pero en GitHub Pages legacy (sin Jekyll, con index.html directo en root), el CDN es mucho más agresivo** — los query params de cache busting (`?v=N`) NO siempre funcionan en el HTML embebido inline.

**Síntomas (DronRacer, 2026-07-08):**
- `curl -s https://site.com/?v=9 | grep "fixed_line"` → muestra la línea corregida ✅
- Browser carga la página → consola muestra el error de la versión vieja ❌
- `requestAnimationFrame` wrapper detecta 1000+ errores/frame desde el código antiguo

**Causa:** GitHub Pages CDN cachea el HTML completo (inline JS incluido) por URL. El query param varía la URL pero el CDN puede ignorarlo para el HTML principal si el contenido es "similar". El `curl` funciona porque no usa el mismo caché que el browser.

**Workarounds (en orden de preferencia):**
1. **Verificar con `raw.githubusercontent.com`** que el archivo SÍ tiene los cambios:
   ```bash
   curl -s "https://raw.githubusercontent.com/OWNER/REPO/main/index.html" | grep "fixed_line"
   ```
2. **Hard refresh:** `Ctrl+Shift+R` (Chrome/Firefox) o `Cmd+Shift+R` (Mac)
3. **Timestamp query param:** `?v=<unix_timestamp>` (más efectivo que `?v=N`)
4. **Commit empty para forzar redeploy:**
   ```bash
   git commit --allow-empty -m "chore: force Pages redeploy" && git push
   ```
5. **GitHub Pages manual:** Settings → Pages → "Clear cache" (si disponible)
6. **Esperar 5-15 minutos** — el CDN invalida eventualmente

**Regla crítica:** No diagnosticar "bugs" hasta verificar que el CDN está sirviendo la versión correcta. Si `curl` muestra contenido correcto pero el browser no lo refleja → es problema de cache del CDN, no del código.

## Subagentes en Archivos Grandes (>3000 líneas)

`delegate_task` con 50 tool calls máximas no alcanza para editar un HTML monolítico de 3000+ líneas. El subagente se queda sin iteraciones.

**Regla:** 
- Archivos <1500 líneas → subagente OK
- Archivos >1500 líneas → usar `execute_code` o `patch` directamente
- Archivos >3000 líneas → SIEMPRE directo, nunca subagente

## Leaflet Choropleth Toggle

Para hacer toggleable un choropleth existente:

1. Crear `L.layerGroup()` ANTES de `L.control.layers()`
2. Añadirlo a los overlays: `L.control.layers(baseLayers, {...overlays, 'Provincias': provincesOverlay})`
3. Después de `renderChoropleth()`: `geoLayer.addTo(provincesOverlay)`
4. El `geoLayer` debe ser un layer hijo del overlay, NO añadido directamente al mapa

```javascript
let provincesOverlay = L.layerGroup();
L.control.layers(baseLayers, {
    'Provincias': provincesOverlay,
    'Parques': parksOverlay
}).addTo(map);

// Después de crear geoLayer:
function renderChoropleth(data) {
    geoLayer = L.geoJSON(data, {...}).addTo(provincesOverlay);
    // NO: geoLayer.addTo(map);
}
```

## Map Navigation on Click

Para navegar al mapa al hacer click en una lista:

```javascript
function selectItem(item) {
    map.flyTo([item.lat, item.lon], 12, { duration: 1.5 });
    // Cargar datos adicionales...
}
```

Funciona con Leaflet sin API externa. `duration: 1.5` = animación suave de 1.5 segundos.

## Datos Estáticos vs APIs Gobernamentales

Si una API gubernamental devuelve 403/HTML/error:
- Usar datos hardcodeados como fallback (ej: ESIOS renewables → 45.2%)
- NO intentar arreglar la API — el usuario quiere ver datos, no errores
- Documentar la fuente: "Fuente: [API] (datos 2023)" o "Fallback: datos hardcodeados"

## Diseño: Eliminar "Look de IA"

David Antizar rechaza explícitamente:
- **NO:** `border-left: 4px solid color` en cards (se nota IA)
- **NO:** Liquid glass, dark themes, gradientes excesivos
- **NO:** Fuentes grandes (>16px para KPIs)
- **SÍ:** Fondo blanco, sombras sutiles, hover elevación
- **SÍ:** Fuentes compactas (12-14px para labels, 14-17px para values)
- **SÍ:** Datos reales, no mockups

## Subida de Datos por Pantalla

David prefiere pantallas densas con más información visible:
- Tabs en barra horizontal arriba (no sidebar lateral)
- KPIs compactos en fila
- Charts pequeños pero informativos
- Listas clickeables que navegan al mapa
- Cada pestaña debe tener mínimo 4-6 KPIs + 1-2 charts

## Two Functions, Same API, Different DOM Targets

Cuando dos funciones hacen la misma llamada API pero actualizan elementos DOM diferentes, un error en los parámetros de la API puede causar que UNA funcione y la OTRA no — aunque la lógica sea idéntica.

**Síntoma:** "El clima funciona en la pestaña pero no en el panel de detalle"
**Causa real:** `fetchProvinceWeather()` pedía `sunrise,sunset` en `current` (error 400 silencioso), mientras `updateClimateForProvince()` no los pedía.

**Debug:**
```javascript
// Verificar qué función actualiza qué elemento
document.querySelectorAll('[id^="weather-"]').forEach(el => {
    console.log(el.id, '=', el.textContent);
});
document.querySelectorAll('[id^="detail-"]').forEach(el => {
    console.log(el.id, '=', el.textContent);
});
```

**Prevención:** Cuando hay dos funciones con API similar, comparar los parámetros fetch lado a lado antes de asumir que "la API funciona".

## Commits Corruptos → REVERT, no parchear

Cuando un commit breaka un HTML/JS monolítico (>3000 líneas) con **3+ corrupciones estructurales** (líneas fusionadas, declaraciones truncadas, braces/parens desbalanceados), intentar parchear cada línea individualmente **no funciona** — cada fix revela más corrupción.

**Síntomas de commit masivamente corrupto:**
- `SyntaxError: Unexpected token 'const'` (const sin nombre de variable)
- `});` fusionado con texto (`});nubo-cities');`)
- Comentarios fusionados con código (`// ===== CHART:eolica-parques');`)
- Balance de braces/parens desbalanceado tras fixes incrementales

**Patrón correcto — REVERT:**
```bash
git log --oneline -5                    # encontrar el commit corrupto
git revert --no-commit <commit_hash>   # revert sin crear commit aún
# Verificar syntax
node -e "const fs=require('fs');const vm=require('vm');const html=fs.readFileSync('index.html','utf8');const m=html.match(/<script>([\\s\\S]*?)<\\/script>/);try{new vm.Script(m[1]);console.log('OK')}catch(e){console.log('ERROR:',e.message)}"
# Si OK, commit
git commit -m "Revert: commit corrupto"
git push
```

**Regla:** Si tras 2 intentos de fix la situación empeora o el balance no cuadra → revert. No intentar un tercero.

## Validación JS Pre-Commit Obligatoria

Para HTML con `<script>` inline, **SIEMPRE** validar syntax antes de push:
```bash
node -e "const fs=require('fs');const vm=require('vm');const html=fs.readFileSync('index.html','utf8');const m=html.match(/<script>([\\s\\S]*?)<\\/script>/);try{new vm.Script(m[1]);console.log('✅ JS syntax OK')}catch(e){console.log('❌',e.message)}"
```

Captura: truncated variables, merged lines, brace imbalance, missing semicolons en destructuring.

## Cron-Based Feature Building

Para dashboards grandes que necesitan muchas features nuevas, usar cron jobs one-shot espaciados 10-15 min. Ver `references/cron-based-dashboard-building.md` para el patrón completo.

## Hardcoded Data Array Sobreescribe Datos Reales (ERAVisor)

**Síntoma:** Un visor HTML con datos en `datos.js` muestra solo 15 registros cuando el CSV tiene 600+. Los gráficos están vacíos, el mapa muestra un solo punto.

**Causa:** Un bloque `window.DATOS = [...]` HARDCODEADO en el `<script>` inline del `index.html` que se ejecuta DESPUÉS de la carga de `datos.js`, sobreescribiendo los datos reales con 15 accidentes de ejemplo.

**Patrón de fallo:**
```html
<!-- datos.js se carga primero y tiene los 399 datos reales -->
<script src="datos.js"></script>
<script>
  // ... código del visor ...
  
  /* DATOS DE EJEMPLO (15 accidentes simulados) */
  window.DATOS = [  // ← ¡SOBREESCRIBE los datos de datos.js!
    { id_accidente:'ES-2024-001', ... },
    ...
  ];
</script>
```

**Debug:**
```bash
# 1. Contar datos reales en datos.js
grep -c '"pais"' visor/datos.js

# 2. Verificar si hay redefinición de window.DATOS
grep -n 'window.DATOS' visor/index.html

# 3. Verificar qué array usa la variable `datos` en runtime
# (busca la línea `let datos = window.DATOS;`)
grep -n 'let datos' visor/index.html
```

**Solución:**
1. Eliminar completamente el bloque `window.DATOS = [...]` HARDCODEADO
2. Reemplazar con un fallback seguro:
```javascript
if (!window.DATOS) {
  window.DATOS = [];
}
```
3. Asegurar que `datos.js` se carga ANTES del script inline

**Prevención:** Nunca poner datos de ejemplo inline en archivos HTML que consumen datos externos. Si se necesitan datos de ejemplo, usar un flag de desarrollo (`?dev=true`) que cargue un JSON separado.

## Scripts Indentados con 4 Espacios — Falso IIFE

**Fecha:** 2026-07-12
**Proyecto:** DataHub España refactor modular

### El problema

Cuando un dashboard monolítico se refactoriza a módulos (32+ archivos JS), el extractor puede copiar el código **con la indentación original del bloque**. El resultado: TODAS las líneas empiezan con 4 espacios, pero **NO hay un IIFE real** envolviendo el contenido.

**Síntomas:**
- `window.setTxt` no existe → `ReferenceError: setTxt is not defined`
- `typeof CCAA_NAMES === 'undefined'`
- `typeof LLUVIA_CITIES === 'undefined'`
- El archivo `curl` muestra `window.setTxt = setTxt` en la línea 237, pero en el navegador no existe
- Todos los archivos JS tienen indentación de 4 espacios, pero NO tienen `(function` ni `{` al inicio

**Diagnóstico:**
```bash
# Verificar si TODAS las líneas de código están indentadas
curl -s 'https://site.com/js/state.js' | python3 -c "
import sys
txt = sys.stdin.read()
lines = txt.split('\n')
code_lines = [l for l in lines if l.strip() and not l.strip().startswith('//')]
all_indented = all(l.startswith('    ') for l in code_lines)
print('TODAS indented:', all_indented)
print('Tiene IIFE:', '(function' in txt)
print('Primera línea de código:', repr(code_lines[0][:80]))
"
```

**Causa:** El extractor de código copia el bloque con su indentación original. En JavaScript, la indentación **NO afecta el scope** — un `const` en un `<script>` tag es siempre scope global sin importar la indentación. El problema real suele ser **caché del navegador** que sirve la versión anterior del archivo.

**Solución:**
1. **Des-indentar los archivos** para que no confundan a futuros devs:
   ```bash
   sed -i 's/^    //' js/state.js js/api.js js/map.js js/charts.js js/tabs.js js/ui.js
   ```
2. **Forzar reload del CDN:** hacer un commit vacío para invalidar caché:
   ```bash
   git commit --allow-empty -m "chore: force CDN cache invalidation" && git push
   ```
3. **Verificar en navegador:** hard refresh (Ctrl+Shift+R) o devtools → Network → Disable cache

**Regla:** Tras refactor modular, verificar SIEMPRE que las variables globales existen:
```javascript
// En consola del navegador:
typeof setTxt !== 'undefined' && typeof map !== 'undefined' && typeof charts !== 'undefined'
// Debe ser true, false → hay problema de scope o caché
```

## Caché del Navegador vs CDN — Diagnóstico Cruzado

**Fecha:** 2026-07-12 (actualizado 2026-07-13)
**Proyecto:** DataHub España

### El problema

El CDN sirve el archivo correcto (verificado con `curl`), pero el navegador ejecuta la versión cacheada. Esto hace que los fixes parezcan no funcionar.

**Síntomas:**
- `curl -s https://site.com/js/state.js | grep 'window.setTxt'` → muestra `window.setTxt = setTxt` ✅
- `typeof setTxt` en consola del navegador → `undefined` ❌
- `curl -s https://site.com/js/state.js | grep 'window.setTxt'` → muestra `window.setTxt = setTxt` ✅ (otra vez)
- `typeof setTxt` en consola → `undefined` ❌

**Diagnóstico:**
```javascript
// En consola del navegador:
var checks = {};
checks.CCAA = typeof CCAA_NAMES !== 'undefined';
checks.WMO = typeof WMO_CODES !== 'undefined';
checks.setTxt = typeof setTxt !== 'undefined';
checks.map = typeof map !== 'undefined';
checks.charts = typeof charts !== 'undefined';
checks.DataHub = typeof DataHub !== 'undefined';
console.log(checks);
// Si CCAA_NAMES y setTxt son false pero DataHub es true → state.js no se ejecutó correctamente
```

**Solución:**
1. Hard refresh: **Ctrl+Shift+R** (Chrome/Firefox) o **Cmd+Shift+R** (Mac)
2. DevTools → Network → marcar "Disable cache" → recargar
3. Si persiste, verificar que el archivo se ejecuta:
   ```javascript
   // Forzar recarga de state.js
   var oldScripts = document.querySelectorAll('script[src*="state.js"]');
   oldScripts.forEach(function(s) { s.remove(); });
   var script = document.createElement('script');
   script.src = '/js/state.js?v=' + Date.now();
   document.body.appendChild(script);
   ```

**Regla crítica:** Cuando `curl` muestra contenido correcto pero el browser no lo refleja → **primero verificar caché, luego diagnosticar código**. El 90% de los "bugs" tras un deploy son problemas de caché.

### Script-Level `?v=` Cache Busting (Lección 2026-07-13)

Añadir `?v=N` al HTML URL (`index.html?v=fix2`) NO invalida el caché de scripts JS. Cada `<script src="js/state.js?v=old">` se cachea independientemente.

**Solución:** Actualizar los `?v=` en TODOS los `<script src>` del index.html:
```bash
sed -i 's/v=20260712143834/v=202607131345/g' index.html
```

**Verificación:**
```bash
curl -s 'https://site.com/' | grep 'state.js'
# Debe mostrar: <script src="js/state.js?v=202607131345">
```

**Regla:** Si el HTML tiene cache-busting pero los scripts no, el browser cargará el HTML nuevo con los scripts viejos. SIEMPRE bumpear todos los `?v=` juntos.

## Geocodificación Masiva de Accidents/Entidades

**Problema:** Un dataset tiene coordenadas placeholder (ej: `48.0, 10.0` para todos) porque el pipeline de extracción no logró obtener lat/lon.

**Solución en 3 pasos:**
1. **Mapeo directo:** Crear un diccionario `{(pais, provincia): (lat, lon)}` con coords conocidas y aplicar con jitter basado en hash del ID
2. **Geocodificación Nominatim:** Para los que no están en el mapeo, usar `requests.get('https://nominatim.openstreetmap.org/search', params={'q': f'{provincia}, {pais}', 'format': 'json', 'limit': 1}, headers={'User-Agent': 'App/1.0'})` con delay de 1.1s entre peticiones
3. **Fallback:** Para los que no geocodifican, usar centro del país con jitter amplio

**Cuidados:**
- Nominatim requiere User-Agent y 1s entre peticiones
- El jitter debe ser determinista (basado en hash del ID) para que los datos no cambien entre regeneraciones
- Los nombres de provincia pueden estar corruptos (fragmentos del resumen del PDF) — en ese caso, geocodificar por municipio
